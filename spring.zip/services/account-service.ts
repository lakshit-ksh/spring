import { AccountRepository } from "@/repositories/account-repository";
import { AccountCreateDto } from "@/types";
import { Provider } from "@/lib/prisma";

export class AccountService {
    static async create(account: AccountCreateDto) {

        const existingAccount = await AccountRepository.findByProviderAccount(account.provider, account.providerAccountId);

        if (existingAccount) {
            throw new Error("Account with this provider and providerAccountId already exists.");
        }

        return AccountRepository.create(account);
    }

    static async findById(id: string) {
        return AccountRepository.findById(id);
    }

    static async findAllByUserId(userId: string) {
        return AccountRepository.findAllByUserId(userId);
    }

    static async findByProviderAccount(provider: Provider, providerAccountId: string) {
        return AccountRepository.findByProviderAccount(provider, providerAccountId);
    }
}