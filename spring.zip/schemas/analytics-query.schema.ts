import { z } from "zod";

export const DateOnlySchema = z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, "Date must be YYYY-MM-DD")
    .transform((val) => new Date(val + "T00:00:00.000Z"));

export const AnalyticsQuerySchema = z.object({
    from: DateOnlySchema,
    to: DateOnlySchema,
}).refine((d) => d.from <= d.to, {
    message: "'from' cannot be after 'to'",
});

export type AnalyticsQuery = z.infer<typeof AnalyticsQuerySchema>;