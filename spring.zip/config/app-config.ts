export const APP_CONFIG = {
    APP_BASE_URL: "http://192.168.0.102:3000",
    REDIRECT_ROUTE: "api/redirect",
    PAGINATION_LIMIT: 5,
    GEOIP_DB_PATH: "./data/GeoLite2-City.mmdb",
    DEV_MOCKED_GEOIP: process.env.NODE_ENV === 'development' ? {
        country: 'IN',
        countryName: 'India',
        city: 'Pune'
    } : null,
    MAX_PAST_DAYS: 90
}