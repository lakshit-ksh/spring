export const NEXT_CONFIG = {
    NEXTAUTH_SECRET: process.env.NEXTAUTH_SECRET,
    NEXTAUTH_MAX_AGE: 30 * 24 * 60 * 60, // 30 days
    NEXTAUTH_UPDATE_AGE: 24 * 60 * 60 // 24 hours
}