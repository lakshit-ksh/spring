import { prisma, Provider } from "@/lib/prisma";
import type { Account } from "@/lib/prisma";
import type { AccountCreateDto } from "@/types";

export class AccountRepository {

    static async create(account: AccountCreateDto): Promise<Account> {
        return prisma.account.create({
            data: account,
        });
    }

    static async findById(id: string): Promise<Account | null> {
        return prisma.account.findUnique({
            where: { id },
        });
    }

    static async findAllByUserId(userId: string): Promise<Account[]> {
        return prisma.account.findMany({
            where: { userId },
        });
    }

    static async findByProviderAccount(
        provider: Provider,
        providerAccountId: string
    ): Promise<Account | null> {
        return prisma.account.findUnique({
            where: {
                provider_providerAccountId: { provider, providerAccountId },
            },
        });
    }

}