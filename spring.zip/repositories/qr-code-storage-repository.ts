import { SUPABASE_CONFIG } from "@/config";
import { BadGatewayError } from "@/error";
import { supabase } from "@/lib/supabase";

export class QrCodeStorageRepository {
    static async uploadQrCode(buffer: Buffer | Uint8Array, filePath: string): Promise<void> {

        const { error: uploadError } = await supabase.storage
            .from(SUPABASE_CONFIG.SUPABASE_STORAGE_BUCKET_NAME)
            .upload(filePath, buffer, { contentType: "image/png", upsert: true });

        if (uploadError) throw new BadGatewayError(`Failed to upload QR Code: ${uploadError.message}`);

    }

    static async getSignedUrl(filePath: string, expiry: number = SUPABASE_CONFIG.SIGNED_URL_EXPIRY_SECONDS): Promise<string> {
        const { data, error } = await supabase.storage
            .from(SUPABASE_CONFIG.SUPABASE_STORAGE_BUCKET_NAME)
            .createSignedUrl(filePath, expiry);

        if (error || !data?.signedUrl)
            throw new BadGatewayError(`Failed to generate signed URL: ${error?.message}`);

        return data.signedUrl;
    }
}
