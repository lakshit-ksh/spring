import { prisma } from "@/lib/prisma";
import { AnalyticsQuery } from "@/schemas";
import { ScanDailyAnalyticsInsertDTO, ScanDailyAnalyticsResponseDto } from "@/types";

export class ScanDailyAnalyticsRepository {

    /**
     * Upsert / increment analytics for a given day.
     * Uses raw SQL for atomic increments and JSON updates.
     */
    static async upsertAnalytics(data: ScanDailyAnalyticsInsertDTO) {
        const { qrCodeId, ip, deviceType, browser, os, country, city } = data;

        const todayUTC = new Date(Date.UTC(
            new Date().getUTCFullYear(),
            new Date().getUTCMonth(),
            new Date().getUTCDate()
        ));

        await prisma.$executeRaw`
            SELECT upsert_scan_daily_analytics(
            ${qrCodeId},
            ${todayUTC},
            ${ip},
            ${deviceType},
            ${browser},
            ${os},
            ${country},
            ${city}
            );
        `;
    }

    static async getDailyAnalyticsForRange(qrCodeId: string, query: AnalyticsQuery): Promise<ScanDailyAnalyticsResponseDto[]> {
        const { from, to } = query;

        return prisma.scanDailyAnalytics.findMany({
            select: {
                date: true,
                totalScans: true,
                uniqueScans: true
            },
            where: {
                qrCodeId,
                date: {
                    gte: from,
                    lte: to
                }
            },
            orderBy: { date: 'asc' }
        })
    }

}