import { prisma } from "@/lib/prisma";
import { QrCodeCreateDto, QrCodeUpdateDto } from "@/schemas";
import type { QrCode } from "@/lib/prisma";
import { CursorPaginatedResult } from "@/types";

export class QrCodeRepository {
    static async create(qrcode: QrCodeCreateDto): Promise<QrCode> {
        return prisma.qrCode.create({
            data: {
                title: qrcode.title,
                targetUrl: qrcode.targetUrl,
                imagePath: qrcode.imagePath ?? "",
                ownerId: qrcode.ownerId
            }
        })
    }

    static async update(id: string, qrcode: QrCodeUpdateDto) {
        return prisma.qrCode.update({
            where: { id },
            data: qrcode
        })
    }

    static async softDelete(id: string): Promise<QrCode> {
        return prisma.qrCode.update({
            where: { id },
            data: {
                deletedAt: new Date(),
                isActive: false
            }
        })
    }

    static async hardDelete(id: string): Promise<QrCode> {
        return prisma.qrCode.delete(
            {
                where: { id }
            }

        );
    }

    static async findById(id: string): Promise<QrCode | null> {
        return prisma.qrCode.findUnique({ where: { id } });
    }

    static async findAllByOwnerId(ownerId: string, cursor: string | null, limit: number = 10,): Promise<CursorPaginatedResult<QrCode>> {
        const qrCodes = await prisma.qrCode.findMany({
            where: { ownerId, isActive: true, deletedAt: null },
            orderBy: { createdAt: 'desc' },
            take: limit + 1,
            cursor: cursor ? { id: cursor } : undefined
        });

        let nextCursor: string | null = null;

        if (qrCodes.length > limit) {
            const nextItem = qrCodes.pop();
            nextCursor = nextItem!.id;
        }

        return {
            items: qrCodes,
            nextCursor
        };
    }

}