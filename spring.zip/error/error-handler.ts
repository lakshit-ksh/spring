import { ApiResponse } from "@/types/api-response";
import { NextResponse } from "next/server";
import { AppError } from "@/error";

export function errorHandler(error: any): NextResponse<ApiResponse<any>> {
    // console.log("Error Handler Invoked");
    if (error instanceof AppError) {
        // console.error("Handled AppError:", error);
        return NextResponse.json(
            new ApiResponse<null>()
                .setStatus(error.statusCode)
                .setError(error.message),
            { status: error.statusCode }
        );
    }

    console.error("Unhandled error:", error);

    return NextResponse.json(
        new ApiResponse<null>()
            .setStatus(500)
            .setError("Internal Server Error"),
        { status: 500 }
    );
}