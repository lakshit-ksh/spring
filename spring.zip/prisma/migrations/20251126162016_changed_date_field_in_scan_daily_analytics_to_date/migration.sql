-- AlterTable
ALTER TABLE "scan_daily_analytics" ALTER COLUMN "date" SET DATA TYPE DATE;
