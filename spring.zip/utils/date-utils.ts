/**
 * Normalize a Date to UTC midnight (date-only)
 */
export function normalizeToUTCDate(date: Date): Date {
  return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
}

export function clampDatesToMaxAllowedRange(from: Date, to: Date, maxRange = 365 * 24 * 60 * 60 * 1000): { from: Date; to: Date } {
  const today = new Date();
  const maxFromDate = new Date(today.getTime() - maxRange);
  if (from < maxFromDate) {
    from = maxFromDate;
  }
  if (to > today) {
    to = today;
  }
  return { from, to };
}