import { Provider } from "@/lib/prisma";

export interface AccountCreateDto {
    userId: string,
    provider: Provider,
    providerAccountId: string,
}