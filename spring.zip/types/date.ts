export interface NormalizedDateRange {
  from: Date;
  analyticsTo: Date;     // for ScanDailyAnalytics (up to yesterday)
  includeToday: boolean; // whether to fetch raw scans for today
}