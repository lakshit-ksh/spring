export interface CursorPaginatedResult<T> {
    items: T[];
    nextCursor: string | null;
}
