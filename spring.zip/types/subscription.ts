import type { SUBSCRIPTION_STATUS } from "@/lib/prisma";

export interface SubscriptionCreateDto {
    userId: string,
    priceId: string,
    status: SUBSCRIPTION_STATUS,
    endDate: Date,
}