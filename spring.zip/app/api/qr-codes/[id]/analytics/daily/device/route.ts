import { NextRequest, NextResponse } from "next/server";

export function GET(req: NextRequest, { params }: { params: { id: string } }) {
    return NextResponse.json({ message: "Device daily analytics endpoint" });
}