import { BadRequestError, errorHandler } from "@/error";
import { AnalyticsQuery, AnalyticsQuerySchema } from "@/schemas";
import { ScanDailyAnalyticsService } from "@/services";
import { ApiResponse } from "@/types";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
    try {
        const { id } = await params;

        const url = new URL(req.url);
        const queryObj = {
            from: url.searchParams.get("from") || "",
            to: url.searchParams.get("to") || "",
        };

        const parsed = AnalyticsQuerySchema.safeParse(queryObj);
        if (!parsed.success) {
            throw new BadRequestError(`Invalid query parameters: ${parsed.error.message}`);
        }

        const query: AnalyticsQuery = parsed.data;
        // console.log(query);

        const analytics = await ScanDailyAnalyticsService.getDailyAnalytics(id, query);
        // console.log(analytics);

        return NextResponse.json(new ApiResponse().ok(analytics));


    } catch (error) {
        return errorHandler(error);
    }
}