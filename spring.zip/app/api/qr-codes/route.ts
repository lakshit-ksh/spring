import { BadRequestError, errorHandler } from "@/error";
import { QrCodeInputDto, QrCodeInputSchema } from "@/schemas";
import { QrCodeService } from "@/services/qr-code-service";
import { ApiResponse, HttpStatus } from "@/types";
import { getAuthSession } from "@/utils/auth-session-utils";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest, res: NextResponse) {
    try {
        const session = await getAuthSession();
        const user = session.user;

        const qrCodeInput: QrCodeInputDto = await req.json();
        const result = QrCodeInputSchema.safeParse(qrCodeInput);

        if (!result.success) {
            throw new BadRequestError("Invalid QR code data");
        }

        const signedUrl = await QrCodeService.generateAndUpload(qrCodeInput, user);
        return NextResponse.json(new ApiResponse<string>().setStatus(HttpStatus.CREATED).setData(signedUrl), { status: HttpStatus.CREATED });
    } catch (error) {
        return errorHandler(error);
    }
}

export async function GET(req: NextRequest, res: NextResponse) {
    try {
        const session = await getAuthSession();
        const user = session.user;

        //get cursor from query parameters
        const { searchParams } = new URL(req.url);
        const cursor = searchParams.get("cursor") ?? null;

        const qrCodes = await QrCodeService.getAllByOwnerId(user.id, cursor);

        return NextResponse.json(new ApiResponse().setStatus(HttpStatus.OK).setData(qrCodes), { status: HttpStatus.OK });

    } catch (error) {
        return errorHandler(error);
    }
}