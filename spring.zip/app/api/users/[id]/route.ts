import { errorHandler, ForbiddenError } from "@/error";
import { UserService } from "@/services/user-service";
import { ApiResponse, UserResponseDto } from "@/types";
import { NextRequest, NextResponse } from "next/server";
import { getAuthSession } from "@/utils/auth-session-utils";
import { UserMapper } from "@/mapper";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {

    try {

        const session = await getAuthSession();

        if (!session || !session?.user) {
            return NextResponse.json(
                new ApiResponse<null>().setStatus(401).setError("Unauthorized"),
                { status: 401 }
            );
        }

        // console.log("Session: ", session);

        const { id } = await params;

        // console.log("param id:", id);
        // console.log("session user id:", session.user.id);

        if (session.user.id !== id) {
            throw new ForbiddenError("You do not have permission to access this resource.");
        }

        const user = await UserService.getById(id);
        const userDto = UserMapper.toUserResponseDto(user);
        return NextResponse.json(new ApiResponse<UserResponseDto>().ok(userDto));

    } catch (error) {
        // console.error("Error fetching user:", error);
        return errorHandler(error);
    }
}