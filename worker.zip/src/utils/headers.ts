import Bowser from "bowser";

/**
 * Extracts the client's IP address from HTTP headers.
 * It first checks the 'X-Forwarded-For' header, and if not present,
 * it falls back to the 'Remote-Addr' header.
 * @param headers - An object representing HTTP headers.
 * @returns The client's IP address as a string, or null if not found.
 */
export function extractIP(headers: Record<string, string | string[] | undefined>): string | null {

    //cf-connecting ip
    const cfConnectingIp = headers['cf-connecting-ip'];
    if (cfConnectingIp) {
        if (Array.isArray(cfConnectingIp)) {
            return cfConnectingIp[0];
        } else {
            return cfConnectingIp;
        }
    }
    // console.log("Headers received for IP extraction:", headers);
    const xForwardedFor = headers['x-forwarded-for'];
    if (xForwardedFor) {
        if (Array.isArray(xForwardedFor)) {
            return xForwardedFor[0].split(',')[0].trim();
        } else {
            return xForwardedFor.split(',')[0].trim();
        }
    }

    const remoteAddr = headers['remote-addr'];
    if (remoteAddr) {
        if (Array.isArray(remoteAddr)) {
            return remoteAddr[0];
        } else {
            return remoteAddr;
        }
    }
    return null;
}

/**
 * Retrieves the 'User-Agent' string from HTTP headers.
 * @param headers - An object representing HTTP headers.
 * @returns The 'User-Agent' string, or null if not found.
 */
export function getUserAgent(headers: Record<string, string | string[] | undefined>): string | null {
    const userAgent = headers['user-agent'];
    if (userAgent) {
        if (Array.isArray(userAgent)) {
            return userAgent[0];
        } else {
            return userAgent;
        }
    }
    return null;
}

/**
 * Parses the 'User-Agent' string to extract detailed information about the client's browser, OS and device.
 * @param userAgentString - The 'User-Agent' string.
 * @returns An object containing parsed information about the client.
 */
export function parseUserAgent(userAgentString: string): { deviceType: string; browser: string; os: string } {
    const parser = Bowser.getParser(userAgentString);
    return {
        deviceType: parser.getPlatformType() || "Unknown",
        browser: parser.getBrowserName() || "Unknown",
        os: parser.getOSName() || "Unknown"
    };
}

