import { getTargetUrl } from "@/services";
import { logScan } from "@/services/scan-service";
import { HttpStatus } from "@/types";
import { extractIP, getUserAgent, parseUserAgent } from "@/utils";
import { Hono } from "hono";
import { sha256 } from "hono/utils/crypto";

const app = new Hono();

app.get('/:id', async (c) => {
    const qrCodeId = c.req.param('id');

    if (!qrCodeId) return c.json({ error: "ID is requried" }, HttpStatus.BAD_REQUEST);

    const targetUrl = await getTargetUrl(qrCodeId);

    // console.log(`targetUrl : ${targetUrl}`);
    console.log(c.req.raw.headers);

    const userAgent = getUserAgent(c.req.header());
    const { deviceType, browser, os } = userAgent ? parseUserAgent(userAgent) : { deviceType: "Unknown", browser: "Unknown", os: "Unknown" };
    const city = c.req.raw.cf?.city as string || "Unknown";
    const country = c.req.raw.cf?.country as string || "Unknown";

    let ip = extractIP(c.req.header());

    let uaIpHash = (await sha256(`${userAgent}-${ip}`)) ?? ip ?? undefined;

    c.executionCtx.waitUntil(
        (async () => {
            try {
                // await upsertAnalytics({ qrCodeId, ip, browser, os, deviceType, city, country });
                await logScan({ qrCodeId, uaIpHash, browser, os, deviceType, city, country });
            } catch (err) {
                console.error("Scan logging error:", err);
            }
        })()
    );

    return targetUrl ?
        c.redirect(targetUrl) :
        c.json({ error: "QR Code Not found!" }, HttpStatus.NOT_FOUND);
});

export default app;