import { getTargetUrl } from "@/services";
import { logScan, upsertAnalytics } from "@/services/analytics.service";
import { HttpStatus } from "@/types";
import { extractIP, getUserAgent, parseUserAgent } from "@/utils";
import { Hono } from "hono";

const app = new Hono();

app.get('/:id', async (c) => {
    const qrCodeId = c.req.param('id');

    if (!qrCodeId) return c.json({ error: "ID is requried" }, HttpStatus.BAD_REQUEST);

    const targetUrl = await getTargetUrl(qrCodeId);

    console.log(`targetUrl : ${targetUrl}`);

    //pass headers to extractIP()
    const ip = extractIP(c.req.header()) ?? "Unknown";
    const userAgent = getUserAgent(c.req.header());
    const { deviceType, browser, os } = userAgent ? parseUserAgent(userAgent) : { deviceType: "Unknown", browser: "Unknown", os: "Unknown" };
    const city = c.req.raw.cf?.city as string || "Unknown";
    const country = c.req.raw.cf?.country as string || "Unknown";

    c.executionCtx.waitUntil(
        (async () => {
            try {
                await logScan({ qrCodeId, ip, browser, os, deviceType, city, country });
                await upsertAnalytics({ qrCodeId, ip, browser, os, deviceType, city, country });
            } catch (err) {
                console.error("Scan logging error:", err);
            }
        })()
    );

    return targetUrl ?
        c.redirect(targetUrl) :
        c.json({ error: "QR Code Not found!" }, HttpStatus.NOT_FOUND);
});

export default app;