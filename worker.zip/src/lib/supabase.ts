
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { SUPABASE_CONFIG } from '../config';

let supabase: SupabaseClient | null = null;

export const getSupabaseInstance = () => {
    if (!supabase) {
        supabase = createClient(SUPABASE_CONFIG.PROJECT_URL, SUPABASE_CONFIG.API_KEY);
    }
    return supabase;
};
