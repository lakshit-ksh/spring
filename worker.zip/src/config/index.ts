import { env } from "cloudflare:workers"

export const APP_CONFIG = {
    TABLES: {
        QRCODE: 'qr_codes',
        USER: 'users',
        SCAN: 'scans'
    },
}

export const SUPABASE_CONFIG = {
    PROJECT_URL: env.SUPABASE_PROJECT_URL,
    API_KEY: env.SUPABASE_API_KEY
}

export * from "./tables";