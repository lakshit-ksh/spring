export const TABLES = {
    QR_CODES: {
        _name: 'qr_codes',
        ID: "id",
        TARGET_URL: "targetUrl"
    },
    USERS: {
        _name: 'users',
    },
    SCANS: {
        _name: 'scans',
    },
    SCAN_DAILY_ANALYTICS: {
        _name: 'scan_daily_analytics',
    }
}