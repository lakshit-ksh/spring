
export interface ScanCreateDto {
    qrCodeId: string,
    ip?: string,
    deviceType?: string,
    os?: string,
    browser?: string,
    country?: string,
    city?: string
}

export interface ScanDailyAnalyticsInsertDTO {
    qrCodeId: string;
    ip: string;

    deviceType?: string;
    browser?: string;
    os?: string;
    country?: string;
    city?: string;
}
