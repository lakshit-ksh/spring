import redirectRoute from "@/routes/redirect.route"
import { Hono } from "hono"
import { HttpStatus } from "./types";

const app = new Hono();

app.on('GET', ["/", '/r'], (c) => c.json({ error: "ID is required" }, HttpStatus.BAD_REQUEST));
app.route("/r", redirectRoute);

export default app;