import { getSupabaseInstance } from "@/lib/supabase";
import type { ScanCreateDto, ScanDailyAnalyticsInsertDTO } from "@/types";

export async function logScan(scan: ScanCreateDto) {
    const supabase = getSupabaseInstance();

    const { qrCodeId, ip, browser, os, deviceType, city, country } = scan;

    const { data, error } = await supabase
        .rpc('log_scan', {
            p_qr_code_id: qrCodeId,
            p_ip: ip,
            p_country: country,
            p_city: city,
            p_device_type: deviceType,
            p_browser: browser,
            p_os: os,
        });

    if (error) {
        console.error('Error logging scan:', error);
    } else {
        console.log('Scan logged successfully for QR:', qrCodeId);
    }
}

export async function upsertAnalytics(dto: ScanDailyAnalyticsInsertDTO) {
    const normalized: ScanDailyAnalyticsInsertDTO = {
        ...dto,
        ip: dto.ip?.trim(),
        // Optional fields trimmed, undefined if empty
        deviceType: dto.deviceType?.trim() || undefined,
        browser: dto.browser?.trim() || undefined,
        os: dto.os?.trim() || undefined,
        country: dto.country?.trim() || undefined,
        city: dto.city?.trim() || undefined,
    };

    const todayUTC = new Date(Date.UTC(
        new Date().getUTCFullYear(),
        new Date().getUTCMonth(),
        new Date().getUTCDate()
    ));

    const supabase = getSupabaseInstance();
    const { data, error } = await supabase
        .rpc('upsert_scan_daily_analytics', {
            p_qr_code_id: normalized.qrCodeId,
            p_date: todayUTC,
            p_ip: normalized.ip,
            p_device_type: normalized.deviceType,
            p_browser: normalized.browser,
            p_os: normalized.os,
            p_country: normalized.country,
            p_city: normalized.city,
        });
    if (error) {
        console.error('Error upserting analytics:', error);
    } else {
        console.log('Analytics upserted successfully for QR:', dto.qrCodeId);
    }
}