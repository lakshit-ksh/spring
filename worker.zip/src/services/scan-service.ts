import { getSupabaseInstance } from "@/lib/supabase";
import type { ScanCreateDto } from "@/types";

export async function logScan(scan: ScanCreateDto) {
    const supabase = getSupabaseInstance();

    const { qrCodeId, uaIpHash, browser, os, deviceType, city, country } = scan;

    const { data, error } = await supabase
        .rpc('log_scan', {
            p_qr_code_id: qrCodeId,
            p_ua_ip_hash: uaIpHash,
            p_country: country,
            p_city: city,
            p_browser: browser,
            p_device_type: deviceType,
            p_os: os,
        });

    if (error) {
        console.error('Error logging scan:', error);
    } else {
        console.log('Scan logged successfully for QR:', qrCodeId);
    }
}