import { TABLES } from "@/config";
import { getSupabaseInstance } from "@/lib/supabase";

export async function getTargetUrl(qrCodeId: string): Promise<string | null> {
    const supabase = getSupabaseInstance();

    const { data, error } = await supabase
        .from(TABLES.QR_CODES._name)
        .select(TABLES.QR_CODES.TARGET_URL)
        .eq(TABLES.QR_CODES.ID, qrCodeId)
        .single();

    if (error || !data) return null;

    const targetUrl = (data as Record<string, any>)[TABLES.QR_CODES.TARGET_URL] as string | null;
    return targetUrl || null;
}