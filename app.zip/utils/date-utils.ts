/**
 * Normalize a Date to UTC midnight (date-only)
 */
export function normalizeToUTCDate(date: Date): Date {
  return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
}