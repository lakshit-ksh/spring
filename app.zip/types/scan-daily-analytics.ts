export interface ScanDailyAnalyticsInsertDTO {
  qrCodeId: string;
  ip: string;

  deviceType?: string;
  browser?: string;
  os?: string;
  country?: string;
  city?: string;
}
