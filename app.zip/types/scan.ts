
export interface ScanCreateDto {
    qrCodeId: string,
    ip?: string,
    deviceType?: string,
    os?: string,
    browser?: string,
    country?: string,
    city?: string
}