
export interface QrCodeResponseDto {
    id: string;
    title: string;
    targetUrl: string;
    createdAt: Date;
    updatedAt: Date;
    signedUrl: string | null;
}
