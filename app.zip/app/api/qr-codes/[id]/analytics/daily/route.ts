import { BadRequestError, errorHandler } from "@/error";
import { AnalyticsQuery, AnalyticsQuerySchema } from "@/schemas";
import { NextRequest } from "next/server";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
    try {
        const { id } = await params;

        const url = new URL(req.url);
        const queryObj = {
            from: url.searchParams.get("from") || "",
            to: url.searchParams.get("to") || "",
        };

        const parsed = AnalyticsQuerySchema.safeParse(queryObj);
        if (!parsed.success) {
            throw new BadRequestError("Invalid query parameters");
        }

        const query: AnalyticsQuery = parsed.data;

        

    } catch (error) {
        return errorHandler(error);
    }
}