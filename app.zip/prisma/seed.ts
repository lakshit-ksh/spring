console.log("Seed script starting");

import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const plans = [
    {
        name: "Free",
        description: "Free plan with limited QR codes",
        qrCodesLimit: 3,
    },
    {
        name: "Pro",
        description: "Paid plan with more QR codes",
        qrCodesLimit: 10,
    }
]

async function main(){
    console.log("Starting seeding the database with initial data...");
    for(const plan of plans){
        await prisma.plan.create({
            data: plan
        })
    }
    console.log("Seeding complete!");
    
}

main()