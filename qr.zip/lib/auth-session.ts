import { getServerSession } from "next-auth";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import type { Session } from "next-auth";
import { UnauthorizedError } from "@/error";

export async function getAuthSession(): Promise<Session> {
  const session = (await getServerSession(authOptions)) as Session;

  if (!session) {
    throw new UnauthorizedError("Unauthorized");
  }

  return session as Session;
}
