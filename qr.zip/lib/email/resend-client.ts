import { Resend } from "resend";
import { IEmailClient } from "@/types";
import { APP_CONFIG } from "@/config";

export class ResendClient implements IEmailClient {
  private static instance: ResendClient;
  private client: Resend;

  private constructor() {
    this.client = new Resend(APP_CONFIG.RESEND_API_KEY);
  }

  static getInstance(): ResendClient {
    if (!ResendClient.instance) {
      ResendClient.instance = new ResendClient();
    }
    return ResendClient.instance;
  }

  async sendEmail({ to, subject, react }: Parameters<IEmailClient["sendEmail"]>[0]) {
    await this.client.emails.send({
      from: APP_CONFIG.EMAIL_FROM,
      to,
      subject,
      react,
    });
  }
}
