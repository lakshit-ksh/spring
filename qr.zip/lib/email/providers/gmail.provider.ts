
import nodemailer from "nodemailer";
import { EmailProvider, EmailPayload } from "@/types";
import { render } from "@react-email/render";
import { APP_CONFIG } from "@/config";

export class GmailProvider implements EmailProvider {

    private static instance: GmailProvider;
    private transporter: nodemailer.Transporter;

    constructor() {
        this.transporter = nodemailer.createTransport({
            host: "smtp.gmail.com",
            port: 587,
            secure: false,
            auth: {
                user: APP_CONFIG.EMAIL.PROVIDERS.GMAIL.USERNAME,
                pass: APP_CONFIG.EMAIL.PROVIDERS.GMAIL.PASSWORD,
            },
        });
    }

    public static getInstance(): GmailProvider {
        if (!GmailProvider.instance) {
            GmailProvider.instance = new GmailProvider();
        }
        return GmailProvider.instance;
    }

    async send(payload: EmailPayload) {
        try {
            const response = await this.transporter.sendMail({
                from: APP_CONFIG.EMAIL.EMAIL_FROM,
                to: payload.to,
                subject: payload.subject,

                html: "html" in payload
                    ? payload.html
                    : "react" in payload
                        ? await render(payload.react)
                        : undefined,

                text: "text" in payload ? payload.text : undefined,
            });
        } catch (error) {
            console.error(`Error sending email in ${this.constructor.name}: `, error);
        }
    }
}
