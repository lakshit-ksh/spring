
import nodemailer from "nodemailer";
import { EmailProvider, EmailPayload } from "@/types/email";
import { render } from "@react-email/render";

export class GmailProvider implements EmailProvider {

  private transporter: nodemailer.Transporter;

  constructor() {
    this.transporter = nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 587,
      secure: false,
      auth: {
        user: process.env.GMAIL_USER!,
        pass: process.env.GMAIL_APP_PASS!,
      },
    });
  }
  async send(payload: EmailPayload) {
    await this.transporter.sendMail({
      from: `"YourApp" <${process.env.GMAIL_USER}>`,
      to: payload.to,
      subject: payload.subject,

      html: "html" in payload
        ? payload.html
        : "react" in payload
          ? await render(payload.react)
          : undefined,

      text: "text" in payload ? payload.text : undefined,
    });
  }
}
