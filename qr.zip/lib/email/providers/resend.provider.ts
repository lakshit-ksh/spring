
import { Resend } from "resend";
import { EmailProvider, EmailPayload } from "@/types";
import { APP_CONFIG } from "@/config";

export class ResendProvider implements EmailProvider {
    private client: Resend;

    constructor() {
        this.client = new Resend(APP_CONFIG.RESEND_API_KEY);
    }

    async send(payload: EmailPayload) {
        await this.client.emails.send({
            from: APP_CONFIG.EMAIL_FROM,
            to: payload.to,
            subject: payload.subject,

            react: "react" in payload ? payload.react : undefined,
            html: "html" in payload ? payload.html : undefined,
            text: "text" in payload ? payload.text : undefined,
        });
    }
}
