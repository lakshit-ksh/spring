
import { Resend } from "resend";
import { EmailProvider, EmailPayload } from "@/types";
import { APP_CONFIG } from "@/config";

export class ResendProvider implements EmailProvider {
    private static instance: ResendProvider;
    private client: Resend;

    constructor() {
        this.client = new Resend(APP_CONFIG.EMAIL.PROVIDERS.RESEND.API_KEY);
    }

    public static getInstance(): ResendProvider {
        if (!ResendProvider.instance) {
            ResendProvider.instance = new ResendProvider();
        }
        return ResendProvider.instance;
    }

    async send(payload: EmailPayload) {
        try {
            await this.client.emails.send({
                from: APP_CONFIG.EMAIL.EMAIL_FROM,
                to: payload.to,
                subject: payload.subject,

                react: "react" in payload ? payload.react : undefined,
                html: "html" in payload ? payload.html : undefined,
                text: "text" in payload ? payload.text : undefined,
            });
        }
        catch (error) {
            console.error(`Error sending email in ${this.constructor.name}: `, error);
        }
    }
}
