// email-provider-factory.ts
import { EmailProvider } from "@/types/email";
import { APP_CONFIG } from "@/config";
import { GmailProvider } from "./gmail.provider";
import { ResendProvider } from "./resend.provider";
import { EmailProviderNotSupportedError } from "@/error";

export function createEmailProvider(): EmailProvider {
    switch (APP_CONFIG.EMAIL.DEFAULT_EMAIL_PROVIDER) {
        case "gmail":
            return GmailProvider.getInstance();
        case "resend":
            return ResendProvider.getInstance();
        default:
            throw new EmailProviderNotSupportedError(`Email provider ${APP_CONFIG.EMAIL.DEFAULT_EMAIL_PROVIDER} is not supported.`);
    }
}
