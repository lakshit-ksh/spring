import { SUPABASE_CONFIG } from "@/config";
import { createClient, SupabaseClient } from "@supabase/supabase-js";

export const supabase: SupabaseClient = createClient(
    SUPABASE_CONFIG.NEXT_PUBLIC_SUPABASE_URL,
    SUPABASE_CONFIG.SUPABASE_SECRET_API_KEY
)