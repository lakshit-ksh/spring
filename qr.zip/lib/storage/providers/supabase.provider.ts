import { STORAGE_CONFIG, SUPABASE_CONFIG } from "@/config";
import { HttpStatus } from "@/constants/http";
import { BadGatewayError, StorageFileNotFoundError } from "@/error";
import { StorageProvider } from "@/types/storage";
import { createClient, SupabaseClient } from "@supabase/supabase-js";

export class SupabaseProvider implements StorageProvider {
    private static instance: SupabaseProvider;
    private client: SupabaseClient;

    constructor() {
        this.client = createClient(
            SUPABASE_CONFIG.NEXT_PUBLIC_SUPABASE_URL,
            SUPABASE_CONFIG.SUPABASE_SECRET_API_KEY
        );
    }

    static getInstance(): SupabaseProvider {
        if (!SupabaseProvider.instance) {
            SupabaseProvider.instance = new SupabaseProvider();
        }
        return SupabaseProvider.instance;
    }

    async uploadFile(file: File, filePath: string): Promise<string> {
        const BUCKET_NAME = STORAGE_CONFIG.QRCODE_LOGOS_BUCKET_NAME;
        // console.log(BUCKET_NAME);
        const { data, error } = await this
            .client
            .storage
            .from(BUCKET_NAME)
            .upload(filePath, file);

        if (error) {
            throw new BadGatewayError(`Failed to upload file: ${error.message}`);
        }
        return data.path;
    }

    async deleteFile(filePath: string): Promise<void> {
        const { error } = await this
            .client
            .storage
            .from(STORAGE_CONFIG.QRCODE_LOGOS_BUCKET_NAME)
            .remove([filePath]);

        if (error) {
            if (error.status === HttpStatus.NOT_FOUND) {
                return;
            }
            throw new BadGatewayError(`Failed to delete file: ${error.message}`);
        }
    }

    async listFiles(path: string): Promise<string[]> {
        const { data, error } = await this
            .client
            .storage
            .from(STORAGE_CONFIG.QRCODE_LOGOS_BUCKET_NAME)
            .list(path);

        if (error) {
            if (error.status === HttpStatus.NOT_FOUND) {
                return [];
            }
            throw new BadGatewayError(`Failed to list files: ${error.message}`);
        }

        return data.map((item) => item.name);
    }

    async getFileUrl(filePath: string): Promise<string> {
        const { data } = this
            .client
            .storage
            .from(STORAGE_CONFIG.QRCODE_LOGOS_BUCKET_NAME)
            .getPublicUrl(filePath);

        if (!data?.publicUrl) {
            throw new StorageFileNotFoundError(`File not found: ${filePath}`);
        }
        return data.publicUrl;
    }

    async exists(filePath: string): Promise<boolean> {
        const { data, error } = await this
            .client
            .storage
            .from(STORAGE_CONFIG.QRCODE_LOGOS_BUCKET_NAME)
            .exists(filePath);
        if (error && error.status !== HttpStatus.NOT_FOUND) {
            throw new BadGatewayError(`Failed to check file existence: ${error.message}`);
        }
        return data;
    }
}