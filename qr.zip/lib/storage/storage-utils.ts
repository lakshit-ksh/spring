import { createStorageProvider } from "@/lib/storage/storage-provider-factory";

/**
 * Options for batch URL fetching
 */
export interface BatchUrlFetchOptions {
    /** Whether to log warnings for failed fetches (default: true) */
    logWarnings?: boolean;
    /** Custom warning logger function */
    warningLogger?: (message: string, data: unknown) => void;
}

/**
 * Fetches public URLs for multiple file paths with error handling
 * 
 * @param filePaths - Array of file paths to fetch URLs for
 * @param options - Configuration options
 * @returns Object containing successful URLs and failed paths
 * 
 * @example
 * ```typescript
 * const result = await batchFetchFileUrls([
 *   'user123/logo1.png',
 *   'user123/logo2.png'
 * ]);
 * 
 * console.log(result.successful); // [{ filePath: '...', url: '...' }]
 * console.log(result.failed); // [{ filePath: '...', error: ... }]
 * ```
 */
export async function batchFetchFileUrls(
    filePaths: string[],
    options: BatchUrlFetchOptions = {}
): Promise<{
    successful: Array<{ filePath: string; url: string }>;
    failed: Array<{ filePath: string; error: unknown }>;
}> {
    const { logWarnings = true, warningLogger = console.warn } = options;

    const storageProvider = createStorageProvider();

    const results = await Promise.allSettled(
        filePaths.map(async (filePath) => {
            try {
                const url = await storageProvider.getFileUrl(filePath);
                return { filePath, url };
            } catch (error) {
                return { filePath, error };
            }
        })
    );

    const successful = results
        .filter((result): result is PromiseFulfilledResult<{ filePath: string; url: string }> =>
            result.status === "fulfilled"
        )
        .map((result) => result.value);

    const failed = results
        .filter((result): result is PromiseRejectedResult =>
            result.status === "rejected"
        )
        .map((result) => result.reason as { filePath: string; error: unknown });

    // Log warnings if enabled and there are failures
    if (logWarnings && failed.length > 0) {
        warningLogger(
            `Failed to fetch URLs for ${failed.length} file(s):`,
            failed.map(({ filePath, error }) => ({ filePath, error }))
        );
    }

    return { successful, failed };
}

/**
 * Maps items with their corresponding file URLs, handling missing URLs gracefully
 * 
 * @param items - Array of items to map
 * @param getFilePath - Function to extract file path from an item
 * @param mapItem - Function to map item with its URL (or undefined if fetch failed)
 * @param options - Configuration options
 * @returns Array of mapped items
 * 
 * @example
 * ```typescript
 * const qrCodesWithLogos = await mapItemsWithFileUrls(
 *   qrCodes,
 *   (qr) => qr.designConfig.image,
 *   (qr, url) => ({
 *     ...qr,
 *     designConfig: { ...qr.designConfig, image: url }
 *   })
 * );
 * ```
 */
export async function mapItemsWithFileUrls<T, R>(
    items: T[],
    getFilePath: (item: T) => string | null | undefined,
    mapItem: (item: T, url: string | undefined) => R,
    options: BatchUrlFetchOptions = {}
): Promise<R[]> {
    // Extract file paths and track indices
    const pathsWithIndices = items
        .map((item, index) => ({ path: getFilePath(item), index }))
        .filter((entry): entry is { path: string; index: number } =>
            entry.path != null && entry.path !== ""
        );

    // Fetch URLs for all valid paths
    const { successful } = await batchFetchFileUrls(
        pathsWithIndices.map((entry) => entry.path),
        options
    );

    // Create a map of filePath -> url for quick lookup
    const urlMap = new Map(successful.map(({ filePath, url }) => [filePath, url]));

    // Map items with their URLs
    return items.map((item, index) => {
        const filePath = getFilePath(item);
        const url = filePath ? urlMap.get(filePath) : undefined;
        return mapItem(item, url);
    });
}