import { STORAGE_CONFIG } from "@/config";
import { SupabaseProvider } from "./providers/supabase.provider";
import { StorageProvider } from "@/types/storage";
import { StorageProviderNotSupportedError } from "@/error";

/**
 * Creates a storage provider based on the default provider configured in the application (STORAGE_CONFIG.DEFAULT_PROVIDER).
 * @returns An instance of the default storage provider.
 * @throws {StorageProviderNotSupportedError} If the default provider is not supported.
 */
export function createStorageProvider(): StorageProvider {
    switch (STORAGE_CONFIG.DEFAULT_PROVIDER) {
        case 'supabase':
            return SupabaseProvider.getInstance();
        default:
            throw new StorageProviderNotSupportedError();
    }
}