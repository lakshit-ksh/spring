import type { QrCode, Scan, User, Subscription, UserToken } from "./prisma/generated/client";
import { PrismaPg } from '@prisma/adapter-pg';
import { PrismaClient, SUBSCRIPTION_STATUS, TokenType } from "./prisma/generated/client";

const globalForPrisma = globalThis as unknown as {
    prisma: PrismaClient | undefined;
    adapter: PrismaPg | undefined;
};

// Create adapter (singleton)
const adapter = globalForPrisma.adapter ?? new PrismaPg({
    connectionString: process.env.DATABASE_URL!,
});

// Create Prisma Client (singleton)
const prisma = globalForPrisma.prisma ?? new PrismaClient({ adapter });

if (process.env.NODE_ENV !== "production") {
    globalForPrisma.prisma = prisma;
    globalForPrisma.adapter = adapter;
}
export { prisma, SUBSCRIPTION_STATUS, TokenType }
export type { QrCode, Scan, User, Subscription, UserToken };