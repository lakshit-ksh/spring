import { QrCode } from "@/lib/prisma";
import { QrCodeDesignConfig } from "@/schemas";
import { QrCodeResponseDto } from "@/types";

export class QrCodeMapper {
    static toQrCodeResponseDto(qrCode: QrCode): QrCodeResponseDto {
        return {
            id: qrCode.id,
            title: qrCode.title,
            targetUrl: qrCode.targetUrl,
            designConfig: qrCode.designConfig as QrCodeDesignConfig,
            createdAt: qrCode.createdAt,
            updatedAt: qrCode.updatedAt,
        }
    }
}