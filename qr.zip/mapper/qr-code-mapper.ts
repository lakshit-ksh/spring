import { QrCode } from "@/lib/prisma";
import { QrCodeResponseDto } from "@/types";

export class QrCodeMapper {
    static toQrCodeResponseDto(qrCode: QrCode & { signedUrl: string | null }): QrCodeResponseDto {
        return {
            id: qrCode.id,
            title: qrCode.title,
            targetUrl: qrCode.targetUrl,
            createdAt: qrCode.createdAt,
            updatedAt: qrCode.updatedAt,
            signedUrl: qrCode.signedUrl
        }
    }
}