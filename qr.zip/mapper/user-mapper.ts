import { User } from "@/lib/prisma";
import { UserResponseDto } from "@/types";

export class UserMapper {
    static toUserResponseDto(user: User): UserResponseDto {
        return {
            id: user.id,
            name: user.name ?? null,
            email: user.email,
            image: user.image ?? null,
            emailVerified: user.emailVerified,
            createdAt: user.createdAt,
            lastLoginAt: user.lastLoginAt ?? null,
        }
    }
}