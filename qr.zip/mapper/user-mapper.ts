import { User } from "@/lib/prisma";
import { UserResponseDto } from "@/types";

export class UserMapper {
    static toUserResponseDto(user: User): UserResponseDto {
        return {
            id: user.id,
            name: user.name ?? null,
            email: user.email,
            emailVerifiedAt: user.emailVerifiedAt,
            createdAt: user.createdAt,
            lastLoginAt: user.lastLoginAt ?? null,
        }
    }
}