import { getToken } from "next-auth/jwt";
import { NextRequest, NextResponse } from "next/server";
import { NEXT_CONFIG } from "@/config/next-config";
import { ApiResponse } from "./types";

export async function middleware(req: NextRequest) {
  // console.log("MIDDLEWARE PATHNAME:", req.nextUrl.pathname);

  const token = await getToken({ req, secret: NEXT_CONFIG.NEXTAUTH_SECRET });
  const { pathname } = req.nextUrl;

  const isApiRoute = pathname.startsWith("/api");
  const isAuthRoute = pathname.startsWith("/api/auth");
  const isRedirectRoute = pathname.startsWith("/api/redirect");

  // 🧩 Skip internal NextAuth routes
  if (isAuthRoute || isRedirectRoute) {
    return NextResponse.next();
  }

  if (!token) {
    if (isApiRoute) {
      return NextResponse.json(
        new ApiResponse().setStatus(401).setError("Unauthorized"),
        { status: 401 }
      );
    }

    // For normal pages → redirect to signin
    return NextResponse.redirect(new URL("/api/auth/signin", req.url));
  }

  // ✅ Authenticated
  return NextResponse.next();
}


export const config = {
  matcher: [
    "/((?!api/auth|api/redirect/.*|_next/static|_next/image|favicon.ico).*)",
  ],
};
