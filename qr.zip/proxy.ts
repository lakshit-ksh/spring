import { getToken } from "next-auth/jwt";
import { NextRequest, NextResponse } from "next/server";
import { NEXT_CONFIG } from "@/config/next-config";
import { ApiResponse } from "./types";
import { HttpStatus } from "./constants/http";

export async function proxy(req: NextRequest) {

  const token = await getToken({ req, secret: NEXT_CONFIG.NEXTAUTH_SECRET });
  const { pathname } = req.nextUrl;

  const isApiRoute = pathname.startsWith("/api");
  const isServerAction = req.headers.get("Next-Action") !== null;

  if (!token) {
    if (isApiRoute || isServerAction) {
      return NextResponse.json(
        new ApiResponse().setStatus(HttpStatus.UNAUTHORIZED).setError("Unauthorized"),
        { status: HttpStatus.UNAUTHORIZED }
      );
    }

    // For normal pages → redirect to signin
    return NextResponse.redirect(new URL("/auth/signin", req.url));
  }

  // ✅ Authenticated
  return NextResponse.next();
}


export const config = {
  matcher: [
    "/((?!api/auth|api/redirect|_next/static|_next/image|favicon.ico|auth|$).*)",
  ],
};
