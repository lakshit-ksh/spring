import { prisma } from "@/lib/prisma";
import { QrCodeCreateDto, QrCodeUpdateDto } from "@/schemas";
import type { QrCode } from "@/lib/prisma";
import { CursorPaginatedResult } from "@/types";

export class QrCodeRepository {
    static async create(qrcode: QrCodeCreateDto): Promise<QrCode> {
        return prisma.qrCode.create({
            data: {
                title: qrcode.title,
                targetUrl: qrcode.targetUrl,
                designConfig: qrcode.designConfig ?? {},
                ownerId: qrcode.ownerId
            }
        })
    }

    static async update(qrCodeId: string, qrcode: QrCodeUpdateDto) {
        return prisma.qrCode.update({
            where: { id: qrCodeId },
            data: qrcode
        })
    }

    static async softDelete(qrCodeId: string): Promise<QrCode> {
        return prisma.qrCode.update({
            where: { id: qrCodeId },
            data: {
                deletedAt: new Date(),
                isActive: false
            }
        })
    }

    static async hardDelete(qrCodeId: string): Promise<QrCode> {
        return prisma.qrCode.delete(
            {
                where: { id: qrCodeId }
            }

        );
    }

    static async findById(qrCodeId: string): Promise<QrCode | null> {
        return prisma.qrCode.findUnique({ where: { id: qrCodeId } });
    }

    static async findAllByOwnerId(ownerId: string, cursor: string | null, limit: number = 10,): Promise<CursorPaginatedResult<QrCode>> {
        const qrCodes = await prisma.qrCode.findMany({
            where: { ownerId, isActive: true, deletedAt: null },
            orderBy: { createdAt: 'desc' },
            take: limit + 1,
            cursor: cursor ? { id: cursor } : undefined
        });

        let nextCursor: string | null = null;

        if (qrCodes.length > limit) {
            const nextItem = qrCodes.pop();
            nextCursor = nextItem!.id;
        }

        return {
            items: qrCodes,
            nextCursor
        };
    }

    static async searchAllByOwnerId(ownerId: string, query: string, cursor: string | null, limit: number = 10): Promise<CursorPaginatedResult<QrCode>> {
        const qrCodes = await prisma.qrCode.findMany({
            where: {
                ownerId,
                isActive: true,
                deletedAt: null,
                OR: [
                    { title: { contains: query, mode: 'insensitive' } },
                    { targetUrl: { contains: query, mode: 'insensitive' } }
                ]
            },
            orderBy: { createdAt: 'desc' },
            take: limit + 1,
            cursor: cursor ? { id: cursor } : undefined
        });

        let nextCursor: string | null = null;

        if (qrCodes.length > limit) {
            const nextItem = qrCodes.pop();
            nextCursor = nextItem!.id;
        }

        return {
            items: qrCodes,
            nextCursor
        };
    }

    static async countByOwnerId(ownerId: string): Promise<number> {
        return prisma.qrCode.count({ where: { ownerId, isActive: true, deletedAt: null } });
    }
}