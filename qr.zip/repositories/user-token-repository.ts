import { UserTokenCreateDto } from "@/types";
import { prisma, TokenType } from "@/lib/prisma";
import crypto from "node:crypto";

export class UserTokenRepository {
    static async create(tokenCreateDto: UserTokenCreateDto) {
        return prisma.userToken.create({
            data: tokenCreateDto,
        });
    }

    static async findValidByHash(tokenHash: string, type: TokenType) {
        return prisma.userToken.findFirst({
            where: {
                tokenHash,
                type,
                expiresAt: { gt: new Date() },
            },
        });
    }

    static async deleteById(id: string) {
        return prisma.userToken.delete({
            where: { id },
        });
    }

    static async deleteByUserIdAndType(userId: string, type: TokenType) {
        return prisma.userToken.deleteMany({
            where: {
                userId,
                type,
            },
        });
    }

}