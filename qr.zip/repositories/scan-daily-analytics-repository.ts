import { prisma } from "@/lib/prisma";
import { AnalyticsQuery } from "@/schemas";
import { JsonbResult, ScanDailyAnalyticsInsertDTO, ScanDailyAnalyticsResponseDto } from "@/types";

export class ScanDailyAnalyticsRepository {

    /**
     * Upsert / increment analytics for a given day.
     * Uses raw SQL for atomic increments and JSON updates.
     */
    static async upsertAnalytics(data: ScanDailyAnalyticsInsertDTO) {
        const { qrCodeId, ip, deviceType, browser, os, country, city } = data;

        const todayUTC = new Date(Date.UTC(
            new Date().getUTCFullYear(),
            new Date().getUTCMonth(),
            new Date().getUTCDate()
        ));

        await prisma.$executeRaw`
            SELECT upsert_scan_daily_analytics(
            ${qrCodeId},
            ${todayUTC},
            ${ip},
            ${deviceType},
            ${browser},
            ${os},
            ${country},
            ${city}
            );
        `;
    }

    static async getDailyAnalyticsForRange(qrCodeId: string, query: AnalyticsQuery): Promise<ScanDailyAnalyticsResponseDto[]> {
        const { from, to } = query;

        const dailyAnalytics = await prisma.scanDailyAnalytics.findMany({
            select: {
                date: true,
                totalScans: true,
                uniqueScans: true
            },
            where: {
                qrCodeId,
                date: {
                    gte: from,
                    lte: to
                }
            },
            orderBy: { date: 'asc' }
        })

        // console.log('Daily Analytics:', dailyAnalytics);
        return dailyAnalytics;
    }

    static async getJsonbAnalytics(qrCodeId: string, field: string, query: AnalyticsQuery) {
        const { from, to } = query;

        const deviceTypeAnalytics = await prisma.$queryRaw<JsonbResult[]>`SELECT get_jsonb_analytics(${qrCodeId}, ${field}, ${from}, ${to}) AS data;`;
        // console.log('Device Type Analytics:', deviceTypeAnalytics);
        return deviceTypeAnalytics[0]?.data || {};
    }

    static async getAggregatedAnalytics(qrCodeId: string, query: AnalyticsQuery) {
        const { from, to } = query;

        const result = await prisma.scanDailyAnalytics.aggregate({
            _sum: {
                totalScans: true,
                uniqueScans: true,
            },
            where: {
                qrCodeId,
                date: {
                    gte: from,
                    lte: to,
                }
            }
        });

        return {
            totalScans: result._sum.totalScans || 0,
            uniqueScans: result._sum.uniqueScans || 0,
        };
    }

}