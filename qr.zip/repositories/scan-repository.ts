import { prisma } from "@/lib/prisma";
import type { Scan } from "@/lib/prisma";
import type { ScanCreateDto } from "@/types";

export class ScanRepository {
    static async create(scan: ScanCreateDto): Promise<Scan> {
        return prisma.scan.create({
            data: {
                qrCodeId: scan.qrCodeId,
                ip: scan.ip ?? null,
                deviceType: scan.deviceType ?? null,
                os: scan.os ?? null,
                browser: scan.browser ?? null,
                country: scan.country ?? null,
                city: scan.city ?? null
            }
        });
    }

    // Total scans for a QR code
    static async countByQrCodeId(qrCodeId: string): Promise<number> {
        return prisma.scan.count({ where: { qrCodeId } });
    }

    // Count scans per country
    static async countByCountry(qrCodeId: string): Promise<{ country: string; count: number }[]> {
        const result = await prisma.scan.groupBy({
            by: ['country'],
            where: { qrCodeId },
            _count: { country: true }
        });

        return result.map(r => ({
            country: r.country ?? 'Unknown', // handle nulls
            count: r._count.country
        }));
    }

    static async countByDate(qrCodeId: string): Promise<{ date: string; count: number }[]> {
        const result = await prisma.$queryRaw<{ date: string; count: number }[]>`
            SELECT 
                DATE("scannedAt") AS date,
                COUNT(*) AS count
            FROM "Scan"
            WHERE "qrCodeId" = ${qrCodeId}
            GROUP BY DATE("scannedAt")
            ORDER BY DATE("scannedAt") DESC;
        `;
        return result;
    }

}