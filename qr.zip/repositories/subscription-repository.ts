import { prisma } from "@/lib/prisma";
import { Subscription, SUBSCRIPTION_STATUS } from "@/lib/prisma";
import type { SubscriptionCreateDto } from "@/types";

export class SubscriptionRepository {
    static async create(subscription: SubscriptionCreateDto): Promise<Subscription> {
        return prisma.subscription.create({
            data: subscription
        });
    }

    static async findActiveByUserId(userId: string): Promise<Subscription | null> {
        return prisma.subscription.findFirst({
            where: {
                userId,
                status: SUBSCRIPTION_STATUS.ACTIVE
            }
        });
    }

    static async findById(id: string): Promise<Subscription | null> {
        return prisma.subscription.findUnique({
            where: { id }
        });
    }

    static async findAllByUserId(userId: string): Promise<Subscription[]> {
        return prisma.subscription.findMany({
            where: { userId }
        });
    }
}