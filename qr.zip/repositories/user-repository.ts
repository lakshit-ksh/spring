import { prisma } from "@/lib/prisma";
import type { User } from "@/lib/prisma";
import type { UserCreateDto, UserUpdateDto } from "@/schemas/user.schema";

export class UserRepository {
    static async create(user: UserCreateDto): Promise<User> {
        return prisma.user.create({ data: user });
    }

    static async update(id: string, updateData: UserUpdateDto): Promise<User> {

        const user = await this.findById(id);
        if (!user) throw new Error(`User not found with ID: ${id}`);

        return prisma.user.update({
            where: { id },
            data: updateData
        })
    }

    static async softDelete(id: string): Promise<User> {

        const user = await this.findById(id);
        if (!user) throw new Error(`User not found with ID: ${id}`);

        return prisma.user.update({
            where: { id },
            data: {
                isActive: false,
                deletedAt: new Date()
            }
        })
    }

    static async findByEmail(email: string): Promise<User | null> {
        return prisma.user.findUnique({ where: { email } });
    }

    static async findById(id: string): Promise<User | null> {
        return prisma.user.findUnique({ where: { id } });
    }

}