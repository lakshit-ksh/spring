import { supabase } from "@/lib/storage/providers/supabase.provider";
import { SUPABASE_CONFIG } from "@/config/supabase-config";

const LOGO_BUCKET = SUPABASE_CONFIG.SUPABASE_STORAGE_QR_LOGO_BUCKET_NAME;

export class LogoRepository {
    // List directly from userId folder
    static async list(userId: string, limit: number) {
        const path = `${userId}/`; // Ensure trailing slash to list folder contents
        return supabase.storage
            .from(LOGO_BUCKET)
            .list(path, {
                limit,
                sortBy: { column: "created_at", order: "desc" }
            });
    }

    static async upload(path: string, file: File) {
        return supabase.storage
            .from(LOGO_BUCKET)
            .upload(path, file, { upsert: false });
    }

    static async delete(path: string) {
        return supabase.storage
            .from(LOGO_BUCKET)
            .remove([path]);
    }

    static getPublicUrl(path: string) {
        return supabase.storage
            .from(LOGO_BUCKET)
            .getPublicUrl(path);
    }
}