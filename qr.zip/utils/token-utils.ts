import crypto from "node:crypto";

/**
 * Generates a random token of specified byte size and returns it as a hexadecimal string.
 * @param size - The size in bytes of the token to generate. Default is 32 bytes.
 * @returns A hexadecimal string representation of the random token.
 */
export function generateRandomToken(size: number = 32): string {
    return crypto.randomBytes(size).toString("hex");
}

/**
 * Hashes the given token using SHA-256 and returns the hexadecimal string representation of the hash.
 * @param token - The token string to hash.
 * @returns A hexadecimal string representation of the hashed token.
 */
export function hashToken(token: string): string {
    return crypto.createHash("sha256").update(token).digest("hex");
}