import { STORAGE_CONFIG } from "@/config";
import { ALLOWED_IMAGE_TYPES } from "@/constants/file";

export async function computeFileHash(file: File): Promise<string> {
    const buffer = await file.arrayBuffer();
    const hashBuffer = await crypto.subtle.digest("SHA-256", buffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
    return hashHex.slice(0, 16);
}

export function isFileValid(file: File): boolean {
    if (file.size === 0) return false;

    if (file.size > STORAGE_CONFIG.MAX_FILE_SIZE) return false;

    if (!ALLOWED_IMAGE_TYPES.has(file.type)) return false;

    return true;
}