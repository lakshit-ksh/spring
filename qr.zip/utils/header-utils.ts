import Bowser from "bowser";

export interface ParsedUA {
    deviceType: string; // e.g., "desktop", "mobile", "tablet"
    os: string;         // e.g., "Windows", "iOS"
    browser: string;    // e.g., "Chrome", "Firefox"
}

/**
 * Parse a User-Agent string into device, OS, and browser info.
 * Provides sensible defaults if parsing fails.
 */
export function parseUserAgent(userAgent: string): ParsedUA {
    const parsed = Bowser.parse(userAgent || "");

    return {
        deviceType: parsed.platform.type ?? "desktop",
        os: parsed.os.name ?? "Unknown",
        browser: parsed.browser.name ?? "Unknown",
    };
}

/**
 * Extract client IP from headers (x-forwarded-for)
 * Supports comma-separated header values and arrays.
 */
export function extractClientIP(headers: Record<string, string | string[] | undefined>): string {
    const xff = headers["x-forwarded-for"];
    if (Array.isArray(xff)) return xff[0].trim();
    if (typeof xff === "string") return xff.split(",")[0].trim();
    return "";
}
