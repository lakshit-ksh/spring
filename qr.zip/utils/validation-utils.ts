export interface ValidationErrors {
  [key: string]: string;
}

export function validateEmail(email: string | null): string | null {
  if (!email) return "Email is required";
  if (!/^\S+@\S+\.\S+$/.test(email)) return "Enter a valid email";
  return null;
}

export function validatePassword(password: string | null, minLength: number = 8): string | null {
  if (!password) return "Password is required";
  if (password.length < minLength) return `Password must be at least ${minLength} characters`;
  return null;
}

export function validateName(name: string | null, minLength: number = 2): string | null {
  if (!name) return "Name is required";
  if (name.length < minLength) return `Name must be at least ${minLength} characters`;
  return null;
}

export function validateSignInForm(formData: FormData): ValidationErrors {
  const email = (formData.get("email") as string)?.trim();
  const password = formData.get("password") as string;

  const errors: ValidationErrors = {};

  const emailError = validateEmail(email);
  if (emailError) errors.email = emailError;

  const passwordError = validatePassword(password, 1);
  if (passwordError) errors.password = passwordError;

  return errors;
}

export function validateSignUpForm(formData: FormData): ValidationErrors {
  const name = (formData.get("name") as string)?.trim();
  const email = (formData.get("email") as string)?.trim();
  const password = formData.get("password") as string;

  const errors: ValidationErrors = {};

  const nameError = validateName(name);
  if (nameError) errors.name = nameError;

  const emailError = validateEmail(email);
  if (emailError) errors.email = emailError;

  const passwordError = validatePassword(password);
  if (passwordError) errors.password = passwordError;

  return errors;
}

