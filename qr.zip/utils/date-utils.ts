/**
 * Normalize a Date to UTC midnight (date-only)
 */
export function normalizeToUTCDate(date: Date): Date {
  return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
}

/**
 * Clamp the given date range to a maximum allowed range.
 * If the 'from' date is older than the maximum allowed range from today,
 * it will be adjusted to that maximum allowed date.
 * If the 'to' date is in the future, it will be adjusted to today.
 * @param from The start date of the range
 * @param to The end date of the range
 * @param maxRange The maximum allowed range in milliseconds (default is 1 year)
 * @returns An object containing the clamped 'from' and 'to' dates
 */
export function clampDatesToMaxAllowedRange(from: Date, to: Date, maxRange = 365 * 24 * 60 * 60 * 1000): { from: Date; to: Date } {
  const today = new Date();
  const maxFromDate = new Date(today.getTime() - maxRange);
  if (from < maxFromDate) {
    from = maxFromDate;
  }
  if (to > today) {
    to = today;
  }
  return { from, to };
}