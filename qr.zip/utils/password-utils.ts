import bcrypt from 'bcryptjs';

const SALT_ROUNDS = 10;
/**
 * 
 * @param password The plain text password to be hashed
 * @returns The hashed password
 */
export async function hashPassword(password: string): Promise<string> {
    return bcrypt.hash(password, SALT_ROUNDS);
}

/**
 * 
 * @param password The plain text password to be verified
 * @param hashedPassword The hashed password to compare against
 * @returns True if the password matches the hashed password, false otherwise
 */
export async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
    if (!password || !hashedPassword) return false;
    return bcrypt.compare(password, hashedPassword);
}