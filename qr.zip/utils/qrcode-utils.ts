import QrCode from "qrcode";

export async function generateQrCode(url: string): Promise<Buffer> {
    return QrCode.toBuffer(url, { type: "png" });
}

