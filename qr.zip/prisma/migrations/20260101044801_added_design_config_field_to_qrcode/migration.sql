/*
  Warnings:

  - You are about to drop the column `imagePath` on the `qr_codes` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "qr_codes" DROP COLUMN "imagePath",
ADD COLUMN     "designConfig" JSONB DEFAULT '{}';
