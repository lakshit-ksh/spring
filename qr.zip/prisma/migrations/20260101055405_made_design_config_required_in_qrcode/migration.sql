/*
  Warnings:

  - Made the column `designConfig` on table `qr_codes` required. This step will fail if there are existing NULL values in that column.

*/
-- AlterTable
ALTER TABLE "qr_codes" ALTER COLUMN "designConfig" SET NOT NULL,
ALTER COLUMN "designConfig" DROP DEFAULT;
