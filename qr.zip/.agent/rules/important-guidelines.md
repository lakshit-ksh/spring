---
trigger: always_on
---

# Project AI Coding Guidelines

## 🛑 MANDATORY PROTOCOLS (STRICT ENFORCEMENT)

### 🔑 Interaction: Explicit Permission Required
- **NO AUTOMATIC ACTIONS:** You MUST ask for my explicit permission before running ANY terminal command or applying ANY file changes.
- **WAIT FOR APPROVAL:** State exactly what you intend to do and wait for my approval before proceeding.

### 🚨 Backend Protection: STRICT "DO NOT TOUCH"
**Everything is considered Backend/System-level except for specific UI directories.**
- **OFF-LIMITS:** `/app/api/**`, `/lib/**`, database schemas, environment variables, and root configuration files.
- **FORBIDDEN:** You MUST NOT modify, create, delete, or suggest changes to any of the above.
- **PERMISSION:** If a task appears to require touching these files, **STOP** and request human confirmation.

---

## 🏗️ Scope & Tech Stack (Frontend Only)

### 📂 Allowed Workspace
You are ONLY permitted to work within:
- `/components/**`
- `/features/**` (UI layer only)
- `/app/**` (Layouts, Pages, and Loading UI only — NO API routes)

### ⚙️ Authoritative Tech Stack
- **Framework:** Next.js (App Router + TypeScript)
- **Styling:** Tailwind CSS + shadcn/ui.
- **Prohibitions:** NO raw CSS, CSS modules, or styled-components.

---

## 🚀 Modularity, Scalability & Industry Standards

### 📐 Architectural Patterns
- **Feature-Based Architecture:** Organize code by business domain (e.g., `/features/auth`, `/features/billing`) rather than generic types. This ensures horizontal scalability.
- **Separation of Concerns:** Use the **Container/Presenter** pattern or **Headless UI** patterns. Components should handle UI; business logic should be abstracted.
- **Atomic Design Principles:** Maintain a clear hierarchy between small UI atoms (shadcn) and complex organisms (features).
- - **Shared Components:** Keep resuable shared components in components/shared folder

### ⚡ Next.js 2025 Best Practices
- **Server Components (RSC) by Default:** Keep components as Server Components unless they require interactivity (`use client`).
- **Granular Client Components:** Move `use client` directives as far down the component tree as possible to minimize client-side JS.
- **Composition Pattern:** Use `children` props to nest Server Components inside Client Components to maintain server-rendering benefits.
- **Streaming & Suspense:** Always implement `loading.tsx` or `<Suspense>` boundaries for data-heavy UI modules to ensure perceived performance.

---

## 📝 Naming & Coding Standards
- **Filenames:** Use **kebab-case** for ALL files and folders (e.g., `user-profile.tsx`).
- **Components:** Use **PascalCase** for component names (e.g., `export const UserProfile = ...`).
- **Exports:** Prefer **named exports** over default exports for better IDE intellisense and tree-shaking.
- **TypeScript:** Use `interface` for props. Strictly avoid `any`. Avoid @ts-ignore

---

## 🎨 UI & Quality Expectations
- **Accessibility:** Use semantic HTML (`<main>`, `<section>`, `<nav>`). ARIA labels and keyboard focus states are mandatory.
- **Cleanliness:** Remove dead code and unused imports immediately.
- **DRY vs AHA:** Avoid premature abstraction, but if a UI pattern is used three times, extract it into a shared component.

---

## ❓ Uncertainty Protocol
**IF UNSURE OR IF THE WORK BORDERS ON BACKEND LOGIC:**
### ASK FOR CLARIFICATION INSTEAD OF GUESSING.