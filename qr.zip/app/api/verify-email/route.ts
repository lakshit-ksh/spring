import { NextRequest } from "next/server";

export async function GET(req: NextRequest) {
    const token = req.nextUrl.searchParams.get('token');
    return new Response(`Token received: ${token}`);
}