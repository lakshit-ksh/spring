import { UserService } from "@/services/user-service";
import NextAuth, { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { BadRequestError, UnauthorizedError } from "@/error";
import { verifyPassword } from "@/utils/password-utils";
import { NEXT_CONFIG } from "@/config/next-config";

export const authOptions: NextAuthOptions = {
    providers: [
        CredentialsProvider({
            name: "Credentials",
            credentials: {
                email: { label: "Email", type: "email", placeholder: "jsmith@example.com" },
                password: { label: "Password", type: "password" }
            },
            async authorize(credentials) {
                try {
                    if (!credentials?.email || !credentials?.password) {
                        throw new BadRequestError("Email and password are required");
                    }
                    const user = await UserService.getByEmail(credentials.email);

                    if (!user || !user?.password) {
                        throw new BadRequestError("Invalid Credentials");
                    }

                    const isPasswordValid = await verifyPassword(credentials.password, user.password);

                    if (!isPasswordValid) {
                        throw new UnauthorizedError("Invalid Credentials");
                    }

                    return {
                        id: user.id,
                        email: user.email
                    }

                } catch (error) {
                    return null;
                }
            }
        })
    ],
    session: {
        strategy: "jwt",
        maxAge: NEXT_CONFIG.NEXTAUTH_MAX_AGE,
        updateAge: NEXT_CONFIG.NEXTAUTH_UPDATE_AGE
    },
    callbacks: {
        async jwt({ token, user }) {
            if (user) {
                token.id = user.id;
                token.email = user.email;
            }
            return token;
        },
        async session({ session, token }) {
            if (session.user) {
                session.user.id = token.id;
                session.user.email = token.email;
            }
            return session;
        }
    },
    pages: {
        signIn: '/auth/signin',
    }
};

const handler = NextAuth(authOptions);

export { handler as GET, handler as POST };