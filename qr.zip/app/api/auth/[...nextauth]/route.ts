import { UserService } from "@/services/user-service";
import NextAuth, { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { BadRequestError, UnauthorizedError } from "@/error";
import { verifyPassword } from "@/utils/password-utils";
import { NEXT_CONFIG } from "@/config/next-config";

export const authOptions: NextAuthOptions = {
    providers: [
        CredentialsProvider({
            name: "Credentials",
            credentials: {
                email: { label: "Email", type: "email", placeholder: "jsmith@example.com" },
                password: { label: "Password", type: "password" }
            },
            async authorize(credentials) {
                console.log("Authorize called with credentials:", credentials);
                try {
                    if (!credentials?.email || !credentials?.password) {
                        throw new BadRequestError("Email and password are required");
                    }
                    const user = await UserService.getByEmail(credentials.email);

                    if (!user || !user?.password) {
                        throw new BadRequestError("Invalid Credentials");
                    }

                    const isPasswordValid = await verifyPassword(credentials.password, user.password);

                    if (!isPasswordValid) {
                        throw new UnauthorizedError("Invalid Credentials");
                    }

                    return {
                        id: user.id,
                        email: user.email ?? undefined,
                        name: user.name ?? undefined,
                        image: user.image ?? undefined
                    }

                } catch (error) {
                    console.error("Error in authorize:", error);
                    return null;
                }
            }
        })
    ],
    session: {
        strategy: "jwt",
        maxAge: NEXT_CONFIG.NEXTAUTH_MAX_AGE,
        updateAge: NEXT_CONFIG.NEXTAUTH_UPDATE_AGE
    },
    callbacks: {
        async jwt({ token, user }) {
            // console.log("JWT callback:", { token, user });
            if (user) {
                token.id = user.id;
                token.email = user.email;
                token.name = user.name;
                token.image = user.image;
            }
            return token;
        },
        async session({ session, token }) {
            // console.log("Session callback:", { session, token });
            if (session.user) {
                session.user.id = token.id as string;
                session.user.email = token.email as string | undefined;
                session.user.name = token.name as string | undefined;
                session.user.image = token.image as string | undefined;
            }
            // console.log("Session callback result:", session);
            return session;
        }
    }
};

const handler = NextAuth(authOptions);

export { handler as GET, handler as POST };