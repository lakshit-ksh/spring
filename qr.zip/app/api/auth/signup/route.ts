import { BadRequestError, errorHandler } from "@/error";
import { UserCreateDto, UserCreateSchema } from "@/schemas";
import { UserService } from "@/services/user-service";
import { ApiResponse, UserResponseDto } from "@/types";
import { NextRequest, NextResponse } from "next/server";
import { UserMapper } from "@/mapper";
import { HttpStatus } from "@/constants/http";
import { createEmailProvider } from "@/lib/email/email-provider-factory";
import { EmailService } from "@/services/email-service";
import { UserTokenService } from "@/services/user-token-service";

export async function POST(req: NextRequest) {
    try {
        const user: UserCreateDto = await req.json();

        const result = UserCreateSchema.safeParse(user);

        if (!result.success) {
            throw new BadRequestError('Invalid user data!',);
        }

        const createdUser = await UserService.create(user);
        const userResponse = UserMapper.toUserResponseDto(createdUser);

        const emailProvider = createEmailProvider();
        const emailService = new EmailService(emailProvider);
        const token = await UserTokenService.createEmailVerificationToken(createdUser.id);
        emailService.sendVerificationEmail(user.email, token);

        return NextResponse.json(new ApiResponse<UserResponseDto>()
            .setStatus(HttpStatus.CREATED)
            .setData(userResponse));

    } catch (error: any) {
        return errorHandler(error);
    }
}