import { BadRequestError, errorHandler } from "@/error";
import { UserCreateDto, UserCreateSchema } from "@/schemas";
import { UserService } from "@/services/user-service";
import { ApiResponse, HttpStatus, UserResponseDto } from "@/types";
import { NextRequest, NextResponse } from "next/server";
import { UserMapper } from "@/mapper";

export async function POST(req: NextRequest) {
    try {
        const user: UserCreateDto = await req.json();

        const result = UserCreateSchema.safeParse(user);

        if (!result.success) {
            throw new BadRequestError('Invalid user data!',);
        }

        const createdUser = await UserService.create(user);
        const userResponse = UserMapper.toUserResponseDto(createdUser);
        return NextResponse.json(new ApiResponse<UserResponseDto>()
            .setStatus(HttpStatus.CREATED)
            .setData(userResponse));

    } catch (error: any) {
        return errorHandler(error);
    }
}