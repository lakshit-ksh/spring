import { APP_CONFIG } from "@/config";
import { BadRequestError, errorHandler } from "@/error";
import { AnalyticsQuerySchema } from "@/schemas";
import { ScanDailyAnalyticsService } from "@/services";
import { ApiResponse } from "@/types";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
    try {
        const { id } = await params;

        const url = new URL(req.url);
        const queryObj = {
            from: url.searchParams.get("from") || "",
            to: url.searchParams.get("to") || "",
        };

        const parsed = AnalyticsQuerySchema.safeParse(queryObj);
        if (!parsed.success) {
            const messages: { code: string, path: string, message: string }[] = JSON.parse(parsed.error.message);
            throw new BadRequestError(`Invalid query parameters: ${messages.map(m => `${m.path}- ${m.message}`).join(", ")}`);
        }

        const query = parsed.data;

        const analytics = await ScanDailyAnalyticsService.getAggregatedAnalytics(id, query);

        return NextResponse.json(new ApiResponse().ok(analytics));
    } catch (error) {
        return errorHandler(error);
    }
}