export const dynamic = "force-dynamic";

import { errorHandler } from "@/error";
import { QrCodeService } from "@/services/qr-code-service";
import { ScanService } from "@/services/scan-service";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {

    try {
        // console.log("headers: ", req.headers);
        const { id: qrCodeId } = await params;
        
        ScanService.logScan(qrCodeId, Object.fromEntries(req.headers.entries()));

        console.log("Redirecting for QR Code ID:", qrCodeId);
        const qrCode = await QrCodeService.getById(qrCodeId);
        return NextResponse.redirect(qrCode?.targetUrl ?? "/404")

    } catch (error) {
        return errorHandler(error);
    }


}