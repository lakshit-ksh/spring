import { Metadata } from "next";
import { AuthSplitLayout } from "@/features/auth/components/auth-split-layout";
import { SignUpForm } from "@/features/auth/components/sign-up-form";

export const metadata: Metadata = {
	title: "Sign Up - QR Generator",
	description: "Create a new account to start generating QR codes.",
};

export default function SignupPage() {
	return (
		<AuthSplitLayout>
			<SignUpForm />
		</AuthSplitLayout>
	);
}
