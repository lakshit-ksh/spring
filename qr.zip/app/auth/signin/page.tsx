import { Metadata } from "next";
import { AuthSplitLayout } from "@/features/auth/components/auth-split-layout";
import { SignInForm } from "@/features/auth/components/sign-in-form";

export const metadata: Metadata = {
	title: "Sign In - QR Generator",
	description: "Sign in to your account to manage your QR codes.",
};

export default function SignInPage() {
	return (
		<AuthSplitLayout>
			<SignInForm />
		</AuthSplitLayout>
	);
}