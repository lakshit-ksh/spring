import { Card, CardContent } from "@/components/ui/card";

export default function AnalyticsLoading() {
    return (
        <div className="space-y-8">
            {/* Header skeleton */}
            <div className="space-y-6">
                <div className="flex items-center gap-4">
                    <div className="h-9 w-9 rounded-md bg-muted animate-pulse" />
                    <div className="space-y-2">
                        <div className="h-6 w-48 bg-muted animate-pulse rounded" />
                        <div className="h-4 w-32 bg-muted animate-pulse rounded" />
                    </div>
                </div>

                {/* Stats cards skeleton */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center justify-between">
                                <div className="space-y-2">
                                    <div className="h-4 w-24 bg-muted animate-pulse rounded" />
                                    <div className="h-8 w-16 bg-muted animate-pulse rounded" />
                                </div>
                                <div className="h-12 w-12 rounded-full bg-muted animate-pulse" />
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center justify-between">
                                <div className="space-y-2">
                                    <div className="h-4 w-24 bg-muted animate-pulse rounded" />
                                    <div className="h-8 w-16 bg-muted animate-pulse rounded" />
                                </div>
                                <div className="h-12 w-12 rounded-full bg-muted animate-pulse" />
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>

            {/* Accordion skeleton */}
            <div className="space-y-4">
                <div className="h-6 w-40 bg-muted animate-pulse rounded" />
                <div className="space-y-3">
                    {[1, 2, 3, 4, 5].map((i) => (
                        <div
                            key={i}
                            className="h-16 rounded-lg bg-muted/50 animate-pulse"
                        />
                    ))}
                </div>
            </div>
        </div>
    );
}
