import { notFound } from "next/navigation";
import { getAuthSession } from "@/lib/auth-session";
import { QrCodeService } from "@/services/qr-code-service";
import { QrCodeNotFoundError } from "@/error/qr-code-error";
import { AnalyticsPageHeader } from "@/features/analytics/components/analytics-page-header";
import { AnalyticsAccordion } from "@/features/analytics/components/analytics-accordion";
import { ScanDailyAnalyticsService } from "@/services";

interface AnalyticsPageProps {
    params: Promise<{ id: string }>;
}

// Get default date range (last 30 days)
function getDefaultDateRange() {
    const to = new Date();
    const from = new Date();
    from.setDate(from.getDate() - 30);

    return {
        from: from.toISOString().split("T")[0],
        to: to.toISOString().split("T")[0],
    };
}

export default async function AnalyticsPage({ params }: AnalyticsPageProps) {
    const { id } = await params;
    const session = await getAuthSession();

    if (!session.user?.id) {
        notFound();
    }

    try {
        // Get QR code - service handles ownership validation
        const qrCode = await QrCodeService.getById(id, session.user.id);

        const dateRange = getDefaultDateRange();

        // Fetch initial scan counts
        const scansCount = await ScanDailyAnalyticsService.getScansCount(id, {
            from: new Date(dateRange.from + "T00:00:00.000Z"),
            to: new Date(dateRange.to + "T00:00:00.000Z"),
        });

        return (
            <div className="space-y-8">
                <AnalyticsPageHeader
                    title={qrCode.title || "QR Code Analytics"}
                    totalScans={scansCount.totalScans}
                    uniqueScans={scansCount.uniqueScans}
                    dateRange={dateRange}
                    backUrl="/dashboard"
                />

                <div>
                    <h2 className="text-lg font-semibold mb-4">Analytics Breakdown</h2>
                    <AnalyticsAccordion qrCodeId={id} dateRange={dateRange} />
                </div>
            </div>
        );
    } catch (error) {
        if (error instanceof QrCodeNotFoundError) {
            notFound();
        }
        throw error;
    }
}
