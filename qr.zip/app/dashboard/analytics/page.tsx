import { getAuthSession } from "@/lib/auth-session";
import { notFound } from "next/navigation";
import { Card, CardContent } from "@/components/ui/card";
import { Activity, Users, BarChart3, AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export const metadata = {
    title: "Analytics Overview - QRlytics",
};

// Get default date range (last 30 days)
function getDefaultDateRange() {
    const to = new Date();
    const from = new Date();
    from.setDate(from.getDate() - 30);

    return {
        from: from.toISOString().split("T")[0],
        to: to.toISOString().split("T")[0],
    };
}

export default async function AggregatedAnalyticsPage() {
    const session = await getAuthSession();

    if (!session.user?.id) {
        notFound();
    }

    const dateRange = getDefaultDateRange();

    const formatDate = (dateStr: string) => {
        return new Date(dateStr).toLocaleDateString("en-US", {
            month: "short",
            day: "numeric",
            year: "numeric",
        });
    };

    // TODO: Implement backend methods for aggregated analytics across all QR codes
    // - getAggregatedScansCount(userId, dateRange) - total scans across all QRs
    // - getAggregatedFieldAnalytics(userId, field, dateRange) - combined analytics by field

    return (
        <div className="space-y-8">
            {/* Header */}
            <div>
                <h1 className="text-2xl font-bold tracking-tight">Analytics Overview</h1>
                <p className="text-sm text-muted-foreground">
                    {formatDate(dateRange.from)} - {formatDate(dateRange.to)}
                </p>
            </div>

            {/* Stats cards placeholder */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <Card className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 border-blue-500/20">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm font-medium text-muted-foreground">
                                    Total Scans
                                </p>
                                <p className="text-3xl font-bold mt-1 text-muted-foreground">
                                    --
                                </p>
                            </div>
                            <div className="p-3 rounded-full bg-blue-500/20">
                                <Activity className="h-6 w-6 text-blue-500" />
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border-emerald-500/20">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm font-medium text-muted-foreground">
                                    Unique Scans
                                </p>
                                <p className="text-3xl font-bold mt-1 text-muted-foreground">
                                    --
                                </p>
                            </div>
                            <div className="p-3 rounded-full bg-emerald-500/20">
                                <Users className="h-6 w-6 text-emerald-500" />
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-orange-500/10 to-amber-500/10 border-orange-500/20">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm font-medium text-muted-foreground">
                                    Active QR Codes
                                </p>
                                <p className="text-3xl font-bold mt-1 text-muted-foreground">
                                    --
                                </p>
                            </div>
                            <div className="p-3 rounded-full bg-orange-500/20">
                                <BarChart3 className="h-6 w-6 text-orange-500" />
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* TODO Notice */}
            <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Coming Soon</AlertTitle>
                <AlertDescription>
                    Aggregated analytics across all your QR codes will be available here soon.
                    For now, view analytics for individual QR codes from the dashboard.
                </AlertDescription>
            </Alert>

            {/* Placeholder for aggregated charts */}
            <div className="space-y-4">
                <h2 className="text-lg font-semibold">Analytics Breakdown</h2>
                <div className="grid gap-4">
                    {["Device Type", "Operating System", "Browser", "Country", "City"].map((label) => (
                        <Card key={label} className="bg-muted/30">
                            <CardContent className="p-6">
                                <div className="flex items-center justify-between">
                                    <span className="font-medium">{label}</span>
                                    <span className="text-sm text-muted-foreground">Coming soon</span>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            </div>
        </div>
    );
}
