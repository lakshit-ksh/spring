import { getServerSession } from "next-auth";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { redirect } from "next/navigation";
import { getQRCodes } from "@/features/dashboard/actions/get-qr-codes";
import { getQrUsage } from "@/features/dashboard/actions/qr-code-actions";
import { QrCodeGrid } from "@/features/dashboard/components/qr-code-grid";

export const metadata = {
    title: "Dashboard - QRlytics",
};

export default async function DashboardPage() {
    const session = await getServerSession(authOptions);

    if (!session) {
        redirect("/auth/signin?callbackUrl=/dashboard");
    }

    // Fetch initial data and usage info in parallel
    const [qrCodesResponse, usageResponse] = await Promise.all([
        getQRCodes(null),
        getQrUsage(),
    ]);

    const initialData = (qrCodesResponse.success && qrCodesResponse.data)
        ? qrCodesResponse.data
        : { items: [], nextCursor: null };

    const initialUsageInfo = (usageResponse.success && usageResponse.data)
        ? usageResponse.data
        : undefined;

    return (
        <div className="space-y-6">
            <div className="flex flex-col gap-2">
                <h1 className="text-3xl font-bold tracking-tight">My QR Codes</h1>
                <p className="text-muted-foreground">
                    Manage and track your generated QR codes.
                </p>
            </div>

            <QrCodeGrid initialData={initialData} initialUsageInfo={initialUsageInfo} />
        </div>
    );
}

