import { notFound } from "next/navigation";
import { BuilderLayout } from "@/features/qr-builder/components/builder-layout";
import { getAuthSession } from "@/lib/auth-session";
import { QrCodeService } from "@/services/qr-code-service";
import { createStorageProvider } from "@/lib/storage/storage-provider-factory";
import { QrCodeNotFoundError } from "@/error/qr-code-error";

interface EditQrPageProps {
    params: Promise<{ id: string }>;
}

export default async function EditQrPage({ params }: EditQrPageProps) {
    const { id } = await params;
    const session = await getAuthSession();

    if (!session.user?.id) {
        notFound();
    }

    try {
        // Get QR code - service handles ownership validation
        const qrCode = await QrCodeService.getById(id, session.user.id);

        // Store original image path before resolving to URL
        const originalImagePath = qrCode.designConfig.image;

        // Resolve logo URL for display if present
        if (qrCode.designConfig.image) {
            try {
                const storageProvider = createStorageProvider();
                const logoExists = await storageProvider.exists(qrCode.designConfig.image);
                if (logoExists) {
                    const logoUrl = await storageProvider.getFileUrl(qrCode.designConfig.image);
                    qrCode.designConfig.image = logoUrl;
                } else {
                    qrCode.designConfig.image = undefined;
                }
            } catch (error) {
                console.warn(`Failed to resolve logo URL for QR ${id}:`, error);
                qrCode.designConfig.image = undefined;
            }
        }

        return <BuilderLayout initialData={qrCode} originalImagePath={originalImagePath} />;
    } catch (error) {
        if (error instanceof QrCodeNotFoundError) {
            notFound();
        }
        throw error;
    }
}


