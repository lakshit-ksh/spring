import { BuilderLayout } from "@/features/qr-builder/components/builder-layout";

export default function CreateQrPage() {
    return <BuilderLayout />;
}
