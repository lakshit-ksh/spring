import { z } from "zod";

export const QrCodeCreateSchema = z.object({
  targetUrl: z.url(),
  imagePath: z.string().min(1).optional(),
  title: z.string().min(1),
  ownerId: z.string().min(1),
})
export const QrCodeInputSchema = z.object({
  targetUrl: z.url(),
  title: z.string().min(1),
});

export const QrCodeUpdateSchema = z.object({
  targetUrl: z.url().optional(),
  title: z.string().min(1).optional(),
  imagePath: z.string().min(1).optional(),
  isActive: z.boolean().optional(),
});

export type QrCodeInputDto = z.infer<typeof QrCodeInputSchema>;

export type QrCodeCreateDto = z.infer<typeof QrCodeCreateSchema>;

export type QrCodeUpdateDto = z.infer<typeof QrCodeUpdateSchema>;