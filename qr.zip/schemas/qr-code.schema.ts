import { z } from "zod";
import type { TypeNumber, Mode, ErrorCorrectionLevel } from "qr-code-styling";
import {
	QR_DOT_STYLES,
	QR_CORNER_SQUARE_STYLES,
	QR_CORNER_DOT_STYLES,
	QR_MODES,
	QR_ERROR_CORRECTION_LEVELS
} from "@/constants/qr-styles";

const QrDesignSchema = z.strictObject({
	width: z.number().default(300),
	height: z.number().default(300),
	data: z.url(),
	margin: z.number().default(0),
	qrOptions: z.object({
		typeNumber: z.number().int().min(0).max(40) as z.ZodType<TypeNumber>,
		mode: z.enum(QR_MODES) as z.ZodType<Mode>,
		errorCorrectionLevel: z.enum(QR_ERROR_CORRECTION_LEVELS) as z.ZodType<ErrorCorrectionLevel>,
	}).optional(),
	imageOptions: z.object({
		hideBackgroundDots: z.boolean(),
		imageSize: z.number(),
		margin: z.number(),
	}).optional(),
	dotsOptions: z.object({
		type: z.enum(QR_DOT_STYLES),
		color: z.string(),
	}),
	backgroundOptions: z.object({
		color: z.string(),
	}),
	cornersSquareOptions: z.object({
		type: z.enum(QR_CORNER_SQUARE_STYLES),
		color: z.string(),
	}).optional(),
	cornersDotOptions: z.object({
		type: z.enum(QR_CORNER_DOT_STYLES),
		color: z.string(),
	}).optional(),
	image: z.string().max(2048).optional(),
});

export const QrCodeCreateSchema = z.strictObject({
	targetUrl: z.url(),
	title: z.string().min(1).max(255),
	ownerId: z.string().min(1),
	designConfig: QrDesignSchema,
});

export const QrCodeInputSchema = z.strictObject({
	targetUrl: z.url(),
	title: z.string().min(1).max(255),
	designConfig: QrDesignSchema,
});

export const QrCodeUpdateSchema = z.strictObject({
	targetUrl: z.url().optional(),
	title: z.string().min(1).max(255).optional(),
	isActive: z.boolean().optional(),
	designConfig: QrDesignSchema.optional(),
});


export type QrCodeInputDto = z.infer<typeof QrCodeInputSchema>;
export type QrCodeCreateDto = z.infer<typeof QrCodeCreateSchema>;
export type QrCodeUpdateDto = z.infer<typeof QrCodeUpdateSchema>;
export type QrCodeDesignConfig = z.infer<typeof QrDesignSchema>;
