import { z } from "zod";

export const UserCreateSchema = z.strictObject({
    name: z.string().min(2).max(100),
    email: z.email(),
    password: z.string().min(8).max(100),
})

export const UserUpdateSchema = z.strictObject({
    name: z.string().min(2).max(100).optional(),
    password: z.string().min(8).max(100).optional(),
    emailVerified: z.boolean().optional(),
})

export type UserCreateDto = z.infer<typeof UserCreateSchema>;
export type UserUpdateDto = z.infer<typeof UserUpdateSchema>;