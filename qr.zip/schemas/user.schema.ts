import { z } from "zod";

export const UserCreateSchema = z.object({
    name: z.string().min(2).max(100),
    email: z.email(),
    password: z.string().min(8).max(100),
    image: z.url().optional(),
    // lastLoginat: z.date().optional().default(new Date()),
})

export const UserUpdateSchema = z.object({
    name: z.string().min(2).max(100).optional(),
    password: z.string().min(8).max(100).optional(),
    emailVerified: z.boolean().optional(),
    image: z.url().optional(),
    // lastLoginat: z.date().optional(),
})

export type UserCreateDto = z.infer<typeof UserCreateSchema>;
export type UserUpdateDto = z.infer<typeof UserUpdateSchema>;