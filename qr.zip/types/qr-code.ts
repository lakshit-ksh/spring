import { type QrCodeDesignConfig } from "@/schemas";

export interface QrCodeResponseDto {
    id: string;
    title: string;
    targetUrl: string;
    designConfig: QrCodeDesignConfig;
    createdAt: Date;
    updatedAt: Date;
}

export interface Logo {
    id: string;
    url: string;
}