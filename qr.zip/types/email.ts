import { ReactElement } from "react";

type ReactEmail = {
  react: ReactElement;
  html?: never;
  text?: never;
};

type HtmlEmail = {
  html: string;
  react?: never;
  text?: never;
};

type TextEmail = {
  text: string;
  react?: never;
  html?: never;
};

/**
 * Public payload used by EmailService
 */
export type EmailPayload = {
  to: string;
  subject: string;
} & (ReactEmail | HtmlEmail | TextEmail);

/**
 * Provider contract (Resend, Gmail, etc.)
 */
export interface EmailProvider {
  send(payload: EmailPayload): Promise<void>;
}
