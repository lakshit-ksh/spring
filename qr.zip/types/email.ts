import React from "react";

export interface IEmailClient {
    sendEmail(props: {
        to: string;
        subject: string;
        react: React.ReactElement;
    }): Promise<void>;
}
