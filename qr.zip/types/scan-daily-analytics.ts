export interface ScanDailyAnalyticsInsertDTO {
  qrCodeId: string;
  ip: string;

  deviceType?: string;
  browser?: string;
  os?: string;
  country?: string;
  city?: string;
}


export interface ScanDailyAnalyticsResponseDto {
  date: Date; // ISO date
  totalScans: number;
  uniqueScans: number;
}

export interface JsonbResult {
    data: Record<string, number> | null;
}