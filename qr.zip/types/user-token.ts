import { TokenType } from "@/lib/prisma";

export interface UserTokenCreateDto {
    userId: string;
    type: TokenType;
    tokenHash: string;
    expiresAt: Date;
}