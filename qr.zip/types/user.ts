
export interface UserCreateDto {
    email: string,
    password?: string,
    name?: string,
    image?: string,
    lastLoginAt?: Date,
}

export interface UserUpdateDto {
    name?: string,
    email?: string,
    password?: string,
    emailVerified?: boolean,
    image?: string,
    lastLoginAt?: Date,
}

export interface UserResponseDto {
    id: string,
    email: string,
    name?: string | null,
    emailVerifiedAt: Date | null,
    createdAt: Date,
    lastLoginAt?: Date | null,
}