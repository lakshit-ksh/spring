export interface StorageProvider {
    uploadFile(file: File, filePath: string): Promise<string>
    deleteFile(filePath: string): Promise<void>
    listFiles(path: string): Promise<string[]>
    getFileUrl(filePath: string): Promise<string>
    exists(filePath: string): Promise<boolean>
}