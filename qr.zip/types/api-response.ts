export interface ResponseDto<T> {
    status: number;
    success?: boolean;
    data?: T | null;
    error?: string | null;
}

export class ApiResponse<T> implements ResponseDto<T> {
    status: number = 200;
    success?: boolean = true;
    data?: T | null = null;
    error?: string | null = null;

    constructor() {
    }

    /**
     * 
     * @param status HTTP status code
     * @returns {ApiResponse<T>}
     */
    setStatus(status: number): this {
        this.status = status;
        return this;
    }

    /**
     * 
     * @param success boolean indicating success or failure
     * @returns {ApiResponse<T>}
     */
    setSuccess(success: boolean): this {
        this.success = success;
        return this;
    }

    /**
     * 
     * @param data The response data
     * @returns {ApiResponse<T>}
     */
    setData(data: T): this {
        this.data = data;
        this.error = null;
        this.success = true;
        return this;
    }

    /**
     * 
     * @param message Error message
     * @param code Error code
     * @returns {ApiResponse<T>}
     */
    setError(message: string): this {
        this.error = message;
        this.data = null;
        this.success = false;
        return this;
    }

    /**
     * Shortcut method to create a successful response with data
     * @param data The response data
     * @returns {ApiResponse<T>}
     */
    ok(data: T): this {
        this.status = 200;
        this.success = true;
        this.data = data;
        this.error = null;
        return this;
    }
}