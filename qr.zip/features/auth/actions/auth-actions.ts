"use server"

import { HttpStatus } from "@/constants/http";
import { BadRequestError, serverActionErrorHandler } from "@/error";
import { createEmailProvider } from "@/lib/email/providers";
import { UserMapper } from "@/mapper";
import { UserCreateDto, UserCreateSchema } from "@/schemas";
import { UserService } from "@/services";
import { EmailService } from "@/services/email-service";
import { UserTokenService } from "@/services/user-token-service";
import { UserResponseDto } from "@/types";
import { ApiResponse, IApiResponse } from "@/types/api-response";

export async function signup(formData: FormData): Promise<IApiResponse<UserResponseDto | null>> {
    try {
        const user: UserCreateDto = {
            name: formData.get('name') as string,
            email: formData.get('email') as string,
            password: formData.get('password') as string,
        };

        const result = UserCreateSchema.safeParse(user);

        if (!result.success) {
            throw new BadRequestError('Invalid user data!',);
        }

        const createdUser = await UserService.create(user);
        const userResponse = UserMapper.toUserResponseDto(createdUser);

        // const emailProvider = createEmailProvider();
        // const emailService = new EmailService(emailProvider);
        // const token = await UserTokenService.createEmailVerificationToken(createdUser.id);

        // emailService.sendVerificationEmail(createdUser.email, token); // fire and forget

        return new ApiResponse<UserResponseDto>()
            .setStatus(HttpStatus.CREATED)
            .setData(userResponse)
            .toJSON();

    } catch (error: any) {
        return serverActionErrorHandler(error);
    }
}