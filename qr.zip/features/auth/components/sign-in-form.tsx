"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { validateSignInForm } from "@/utils/validation-utils";
import { Mail, Lock, AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { LoadingButton } from "@/components/shared/loading-button";
import { IconInput } from "@/components/shared/icon-input";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import clsx from "clsx";

export function SignInForm() {
    const [formError, setFormError] = useState<string | null>(null);
    const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
    const [loading, setLoading] = useState(false);

    const searchParams = useSearchParams();
    const router = useRouter();
    const callbackUrl = searchParams.get("callbackUrl") || "/";

    async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
        e.preventDefault();

        setFormError(null);
        setFieldErrors({});

        const formData = new FormData(e.currentTarget);
        const errors = validateSignInForm(formData);

        if (Object.keys(errors).length > 0) {
            setFieldErrors(errors);
            return;
        }

        setLoading(true);

        try {
            const email = formData.get("email") as string;
            const password = formData.get("password") as string;

            const result = await signIn("credentials", {
                email,
                password,
                redirect: false,
            });

            if (result?.error) {
                setFormError("Invalid email or password. Please try again.");
                setLoading(false);
                return;
            }

            if (result?.ok) {
                router.push(callbackUrl);
                router.refresh();
            }
        } catch (error) {
            setFormError("Something went wrong. Please try again.");
            setLoading(false);
        }
    }

    return (
        <div className="space-y-6">
            <div className="space-y-2 text-center lg:text-left">
                <h1 className="text-3xl font-bold tracking-tight">Welcome back</h1>
                <p className="text-muted-foreground">
                    Enter your credentials to access your account
                </p>
            </div>

            {formError && (
                <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Error</AlertTitle>
                    <AlertDescription>{formError}</AlertDescription>
                </Alert>
            )}

            <form className="space-y-4" onSubmit={onSubmit} noValidate>
                <IconInput
                    id="email"
                    name="email"
                    type="email"
                    label="Email"
                    icon={Mail}
                    placeholder="name@example.com"
                    autoComplete="email"
                    error={fieldErrors.email}
                />

                <div className="space-y-2">
                    <div className="flex items-center justify-between">
                        <Label htmlFor="password">Password</Label>
                        <Link
                            href="/auth/reset-password"
                            className="text-sm font-medium text-primary hover:underline"
                        >
                            Forgot password?
                        </Link>
                    </div>
                    <div className="relative">
                        <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                        <Input
                            id="password"
                            name="password"
                            type="password"
                            autoComplete="current-password"
                            className={clsx("pl-10", {
                                "border-red-500 focus-visible:ring-red-500": fieldErrors.password
                            })}
                        />
                    </div>
                    {fieldErrors.password && (
                        <p className="text-sm text-destructive font-medium">{fieldErrors.password}</p>
                    )}
                </div>

                <LoadingButton
                    isLoading={loading}
                    loadingText="Signing in..."
                    className="w-full"
                    type="submit"
                >
                    Sign In
                </LoadingButton>

            </form>

            <div className="relative">
            </div>

            <p className="text-center text-sm text-muted-foreground">
                Don&apos;t have an account?{" "}
                <Link
                    href="/auth/signup"
                    className="font-medium text-primary hover:underline underline-offset-4"
                >
                    Sign up
                </Link>
            </p>
        </div>
    );
}
