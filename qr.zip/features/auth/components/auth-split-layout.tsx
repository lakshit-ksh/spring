import { Zap } from "lucide-react";

interface AuthSplitLayoutProps {
    children: React.ReactNode;
}

export function AuthSplitLayout({ children }: AuthSplitLayoutProps) {
    return (
        <div className="min-h-screen w-full lg:grid lg:min-h-screen lg:grid-cols-2">
            <div className="flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 bg-background">
                <div className="mx-auto w-full max-w-[450px] space-y-6">
                    {children}
                </div>
            </div>
            <div className="hidden bg-muted lg:block relative overflow-hidden">
                <div className="absolute inset-0 bg-zinc-900 dark:bg-zinc-950">
                    {/* Abstract Gradient Background */}
                    <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/20 via-purple-500/20 to-pink-500/20 blur-3xl opacity-60" />
                    <div className="absolute -top-24 -left-24 w-96 h-96 bg-blue-600/30 rounded-full blur-[100px]" />
                    <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-indigo-600/20 rounded-full blur-[120px]" />

                    <div className="relative h-full flex flex-col items-center justify-center p-8 text-center text-white z-10">
                        <div className="mb-6 rounded-full bg-white/10 p-4 ring-1 ring-white/20 backdrop-blur-md">
                            <Zap className="h-10 w-10 text-white" />
                        </div>
                        <blockquote className="space-y-2 max-w-lg">
                            <p className="text-2xl font-medium leading-relaxed tracking-tight">
                                "This platform has completely transformed how we manage our digital touchpoints. It's not just a tool; it's a game changer."
                            </p>
                            <footer className="text-sm text-zinc-400 mt-4 font-medium">
                                Sofia Davis, CEO at TechFlow
                            </footer>
                        </blockquote>
                    </div>
                </div>
            </div>
        </div>
    );
}
