"use client";

import { useState } from "react";
import { signup } from "@/features/auth/actions/auth-actions";
import Link from "next/link";
import { validateSignUpForm } from "@/utils/validation-utils";
import { CheckCircle, User, Mail, Lock, AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { LoadingButton } from "@/components/shared/loading-button";
import { IconInput } from "@/components/shared/icon-input";
import { Button } from "@/components/ui/button"; // Still needed for the Success State "Go to Sign In" button

export function SignUpForm() {
    const [formError, setFormError] = useState<string | null>(null);
    const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
    const [success, setSuccess] = useState(false);
    const [loading, setLoading] = useState(false);

    async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
        e.preventDefault();
        const form = e.currentTarget;

        setFormError(null);
        setFieldErrors({});
        setSuccess(false);

        const formData = new FormData(form);
        const errors = validateSignUpForm(formData);

        if (Object.keys(errors).length > 0) {
            setFieldErrors(errors);
            return;
        }

        setLoading(true);
        const response = await signup(formData);
        setLoading(false);

        if (!response.success) {
            setFormError(response.error ?? "Something went wrong.");
            return;
        }

        setSuccess(true);
        form.reset();
    }

    if (success) {
        return (
            <div className="flex flex-col items-center justify-center space-y-6 text-center animate-in fade-in-50 slide-in-from-bottom-5 duration-500">
                <div className="rounded-full bg-green-100 p-4 text-green-600 dark:bg-green-900/30 dark:text-green-400">
                    <CheckCircle className="h-12 w-12" />
                </div>
                <div className="space-y-2">
                    <h2 className="text-2xl font-bold tracking-tight">Account Created</h2>
                    <p className="text-muted-foreground max-w-sm mx-auto">
                        Your account has been created successfully. Please check your email to verify your account before signing in.
                    </p>
                </div>
                <Link href="/auth/signin" className="w-full">
                    <Button className="w-full" size="lg">
                        Go to Sign In
                    </Button>
                </Link>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div className="space-y-2 text-center lg:text-left">
                <h1 className="text-3xl font-bold tracking-tight">Create an account</h1>
                <p className="text-muted-foreground">
                    Enter your information to get started
                </p>
            </div>

            {formError && (
                <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Error</AlertTitle>
                    <AlertDescription>{formError}</AlertDescription>
                </Alert>
            )}

            <form className="space-y-4" onSubmit={onSubmit} noValidate>
                <IconInput
                    id="name"
                    name="name"
                    label="Name"
                    icon={User}
                    placeholder="Your name"
                    error={fieldErrors.name}
                />

                <IconInput
                    id="email"
                    name="email"
                    type="email"
                    label="Email"
                    icon={Mail}
                    placeholder="name@example.com"
                    error={fieldErrors.email}
                />

                <IconInput
                    id="password"
                    name="password"
                    type="password"
                    label="Password"
                    icon={Lock}
                    placeholder="Create a password"
                    error={fieldErrors.password}
                />

                <LoadingButton
                    type="submit"
                    className="w-full"
                    size="lg"
                    isLoading={loading}
                    loadingText="Creating account..."
                >
                    Sign Up
                </LoadingButton>
            </form>

            <p className="text-center text-sm text-muted-foreground">
                Already have an account?{" "}
                <Link
                    href="/auth/signin"
                    className="font-medium text-primary hover:underline underline-offset-4"
                >
                    Sign in
                </Link>
            </p>
        </div>
    );
}
