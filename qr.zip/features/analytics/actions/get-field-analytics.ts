"use server";

import { AnalyticsField } from "@/constants/analytics";
import { serverActionErrorHandler } from "@/error/error-handler";
import { getAuthSession } from "@/lib/auth-session";
import { ScanDailyAnalyticsService } from "@/services";
import { QrCodeService } from "@/services/qr-code-service";
import { ApiResponse, IApiResponse } from "@/types/api-response";

interface GetFieldAnalyticsParams {
    qrCodeId: string;
    field: AnalyticsField;
    from: string; // YYYY-MM-DD
    to: string;   // YYYY-MM-DD
}

export async function getFieldAnalytics(
    params: GetFieldAnalyticsParams
): Promise<IApiResponse<Record<string, number> | null>> {
    try {
        const session = await getAuthSession();

        // Verify QR code ownership
        await QrCodeService.getById(params.qrCodeId, session.user!.id);

        const query = {
            from: new Date(params.from + "T00:00:00.000Z"),
            to: new Date(params.to + "T00:00:00.000Z"),
        };

        const data = await ScanDailyAnalyticsService.getJsonbAnalytics(
            params.qrCodeId,
            params.field,
            query
        );

        return new ApiResponse<Record<string, number>>().ok(data as Record<string, number>).toJSON();
    } catch (error) {
        return serverActionErrorHandler(error);
    }
}
