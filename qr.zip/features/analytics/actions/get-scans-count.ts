"use server";

import { serverActionErrorHandler } from "@/error/error-handler";
import { getAuthSession } from "@/lib/auth-session";
import { ScanDailyAnalyticsService } from "@/services";
import { QrCodeService } from "@/services/qr-code-service";
import { ApiResponse, IApiResponse } from "@/types/api-response";

interface ScansCountResult {
    totalScans: number;
    uniqueScans: number;
}

interface GetScansCountParams {
    qrCodeId: string;
    from: string; // YYYY-MM-DD
    to: string;   // YYYY-MM-DD
}

export async function getScansCount(
    params: GetScansCountParams
): Promise<IApiResponse<ScansCountResult | null>> {
    try {
        const session = await getAuthSession();

        // Verify QR code ownership
        await QrCodeService.getById(params.qrCodeId, session.user!.id);

        const query = {
            from: new Date(params.from + "T00:00:00.000Z"),
            to: new Date(params.to + "T00:00:00.000Z"),
        };

        const data = await ScanDailyAnalyticsService.getScansCount(
            params.qrCodeId,
            query
        );

        return new ApiResponse<ScansCountResult>().ok(data).toJSON();
    } catch (error) {
        return serverActionErrorHandler(error);
    }
}
