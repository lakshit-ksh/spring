"use client";

import { Bar, BarChart, XAxis, YAxis, Cell } from "recharts";
import {
    ChartConfig,
    ChartContainer,
    ChartTooltip,
    ChartTooltipContent,
} from "@/components/ui/chart";

interface AnalyticsBarChartProps {
    data: Record<string, number>;
    label?: string;
}

// Premium color palette with gradients
const CHART_COLORS = [
    "hsl(217, 91%, 60%)",  // Blue
    "hsl(262, 83%, 58%)",  // Purple  
    "hsl(330, 81%, 60%)",  // Pink
    "hsl(24, 94%, 53%)",   // Orange
    "hsl(142, 71%, 45%)",  // Green
    "hsl(47, 96%, 53%)",   // Yellow
    "hsl(199, 89%, 48%)",  // Cyan
    "hsl(346, 84%, 61%)",  // Rose
];

export function AnalyticsBarChart({ data, label = "count" }: AnalyticsBarChartProps) {
    // Transform data and sort by value descending
    const chartData = Object.entries(data)
        .map(([name, value]) => ({ name, value }))
        .sort((a, b) => b.value - a.value)
        .slice(0, 10); // Top 10 items

    if (chartData.length === 0) {
        return (
            <div className="flex items-center justify-center h-[200px] text-muted-foreground">
                No data available
            </div>
        );
    }

    const chartConfig = {
        value: {
            label: label,
            color: CHART_COLORS[0],
        },
    } satisfies ChartConfig;

    return (
        <ChartContainer config={chartConfig} className="h-[300px] w-full">
            <BarChart
                data={chartData}
                layout="vertical"
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
            >
                <XAxis
                    type="number"
                    tickLine={false}
                    axisLine={false}
                    tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
                />
                <YAxis
                    type="category"
                    dataKey="name"
                    tickLine={false}
                    axisLine={false}
                    tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
                    width={100}
                />
                <ChartTooltip
                    cursor={{ fill: "hsl(var(--muted)/0.3)" }}
                    content={<ChartTooltipContent />}
                />
                <Bar
                    dataKey="value"
                    radius={[0, 6, 6, 0]}
                    className="transition-all duration-300"
                >
                    {chartData.map((_, index) => (
                        <Cell
                            key={`cell-${index}`}
                            fill={CHART_COLORS[index % CHART_COLORS.length]}
                        />
                    ))}
                </Bar>
            </BarChart>
        </ChartContainer>
    );
}
