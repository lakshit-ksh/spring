"use client";

import { Card, CardContent } from "@/components/ui/card";
import { Activity, Users, ArrowLeft, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

interface AnalyticsPageHeaderProps {
    title: string;
    totalScans: number;
    uniqueScans: number;
    dateRange: { from: string; to: string };
    backUrl?: string;
}

export function AnalyticsPageHeader({
    title,
    totalScans,
    uniqueScans,
    dateRange,
    backUrl = "/dashboard",
}: AnalyticsPageHeaderProps) {
    const formatDate = (dateStr: string) => {
        return new Date(dateStr).toLocaleDateString("en-US", {
            month: "short",
            day: "numeric",
            year: "numeric",
        });
    };

    return (
        <div className="space-y-6">
            {/* Back button and title */}
            <div className="flex items-center gap-4">
                <Link href={backUrl}>
                    <Button variant="ghost" size="icon" className="h-9 w-9">
                        <ArrowLeft className="h-5 w-5" />
                    </Button>
                </Link>
                <div>
                    <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
                    <p className="text-sm text-muted-foreground">
                        {formatDate(dateRange.from)} - {formatDate(dateRange.to)}
                    </p>
                </div>
            </div>

            {/* Stats cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Card className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 border-blue-500/20">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm font-medium text-muted-foreground">
                                    Total Scans
                                </p>
                                <p className="text-3xl font-bold mt-1">
                                    {totalScans.toLocaleString()}
                                </p>
                            </div>
                            <div className="p-3 rounded-full bg-blue-500/20">
                                <Activity className="h-6 w-6 text-blue-500" />
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border-emerald-500/20">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm font-medium text-muted-foreground">
                                    Unique Scans
                                </p>
                                <p className="text-3xl font-bold mt-1">
                                    {uniqueScans.toLocaleString()}
                                </p>
                            </div>
                            <div className="p-3 rounded-full bg-emerald-500/20">
                                <Users className="h-6 w-6 text-emerald-500" />
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
