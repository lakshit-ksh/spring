"use client";

import { useState, useEffect } from "react";
import { AnalyticsField } from "@/constants/analytics";
import { getFieldAnalytics } from "../actions/get-field-analytics";
import { AnalyticsBarChart } from "./analytics-bar-chart";
import {
    AccordionContent,
    AccordionItem,
    AccordionTrigger,
} from "@/components/ui/accordion";
import { Loader2 } from "lucide-react";

interface AnalyticsAccordionItemProps {
    qrCodeId: string;
    field: AnalyticsField;
    title: string;
    icon: React.ReactNode;
    dateRange: { from: string; to: string };
    isOpen: boolean;
}

export function AnalyticsAccordionItem({
    qrCodeId,
    field,
    title,
    icon,
    dateRange,
    isOpen,
}: AnalyticsAccordionItemProps) {
    const [data, setData] = useState<Record<string, number> | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [hasFetched, setHasFetched] = useState(false);

    // Fetch data only when accordion is opened and hasn't been fetched
    useEffect(() => {
        if (isOpen && !hasFetched) {
            const fetchData = async () => {
                setIsLoading(true);
                setError(null);
                try {
                    const response = await getFieldAnalytics({
                        qrCodeId,
                        field,
                        from: dateRange.from,
                        to: dateRange.to,
                    });

                    if (response.success && response.data) {
                        setData(response.data);
                    } else {
                        setError(response.error || "Failed to fetch data");
                    }
                } catch {
                    setError("An unexpected error occurred");
                } finally {
                    setIsLoading(false);
                    setHasFetched(true);
                }
            };
            fetchData();
        }
    }, [isOpen, hasFetched, qrCodeId, field, dateRange]);

    return (
        <AccordionItem value={field} className="border rounded-lg px-4 mb-3 bg-card/50 backdrop-blur-sm">
            <AccordionTrigger className="hover:no-underline py-4">
                <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-primary/10 text-primary">
                        {icon}
                    </div>
                    <span className="font-semibold text-base">{title}</span>
                </div>
            </AccordionTrigger>
            <AccordionContent className="pt-2 pb-4">
                {isLoading && (
                    <div className="flex items-center justify-center h-[200px]">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    </div>
                )}
                {error && (
                    <div className="flex items-center justify-center h-[200px] text-destructive">
                        {error}
                    </div>
                )}
                {!isLoading && !error && data && (
                    <AnalyticsBarChart data={data} label={title} />
                )}
                {!isLoading && !error && !data && hasFetched && (
                    <div className="flex items-center justify-center h-[200px] text-muted-foreground">
                        No data available for this period
                    </div>
                )}
            </AccordionContent>
        </AccordionItem>
    );
}
