"use client";

import { useState } from "react";
import { ANALYTICS_FIELDS } from "@/constants/analytics";
import { Accordion } from "@/components/ui/accordion";
import { AnalyticsAccordionItem } from "./analytics-accordion-item";
import {
    Smartphone,
    Globe,
    Monitor,
    MapPin,
    Building2
} from "lucide-react";

interface AnalyticsAccordionProps {
    qrCodeId: string;
    dateRange: { from: string; to: string };
}

const ANALYTICS_CATEGORIES = [
    {
        field: ANALYTICS_FIELDS.DEVICE_TYPE,
        title: "Device Type",
        icon: <Smartphone className="h-5 w-5" />,
    },
    {
        field: ANALYTICS_FIELDS.OS,
        title: "Operating System",
        icon: <Monitor className="h-5 w-5" />,
    },
    {
        field: ANALYTICS_FIELDS.BROWSER,
        title: "Browser",
        icon: <Globe className="h-5 w-5" />,
    },
    {
        field: ANALYTICS_FIELDS.COUNTRY,
        title: "Country",
        icon: <MapPin className="h-5 w-5" />,
    },
    {
        field: ANALYTICS_FIELDS.CITY,
        title: "City",
        icon: <Building2 className="h-5 w-5" />,
    },
];

export function AnalyticsAccordion({ qrCodeId, dateRange }: AnalyticsAccordionProps) {
    const [openItems, setOpenItems] = useState<string[]>([]);

    return (
        <Accordion
            type="multiple"
            value={openItems}
            onValueChange={setOpenItems}
            className="space-y-2"
        >
            {ANALYTICS_CATEGORIES.map((category) => (
                <AnalyticsAccordionItem
                    key={category.field}
                    qrCodeId={qrCodeId}
                    field={category.field}
                    title={category.title}
                    icon={category.icon}
                    dateRange={dateRange}
                    isOpen={openItems.includes(category.field)}
                />
            ))}
        </Accordion>
    );
}
