"use server";

import { createStorageProvider } from "@/lib/storage/storage-provider-factory";
import { getAuthSession } from "@/lib/auth-session";
import { BadRequestError, ForbiddenError, serverActionErrorHandler, StorageFileNotFoundError, UnauthorizedError } from "@/error";
import { computeFileHash, isFileValid } from "@/utils/file-utils";
import { ApiResponse, IApiResponse, Logo, StorageProvider } from "@/types";
import { APP_CONFIG } from "@/config";

export async function uploadLogo(file: File): Promise<IApiResponse<Logo | null>> {
    try {
        const session = await getAuthSession();

        if (!session.user) {
            throw new UnauthorizedError("User not authenticated");
        }
        const storageProvider = createStorageProvider();

        if (await logoUploadLimitReached(session.user.id, storageProvider)) {
            throw new ForbiddenError("Logo upload limit reached");
        }

        const isValid = isFileValid(file);

        if (!isValid) {
            throw new BadRequestError("Invalid file");
        }

        const fileHash = await computeFileHash(file);
        const fileType = file.type.split("/")[1];
        const filePath = `${session.user.id}/${fileHash}.${fileType}`;

        // same file = same hash = safe to overwrite
        const path = await storageProvider.uploadFile(file, filePath);
        const url = await storageProvider.getFileUrl(filePath);
        return new ApiResponse<Logo>().created({ id: fileHash, url }).toJSON();
    } catch (error) {
        console.error(error);
        return serverActionErrorHandler(error);
    }
}

export async function deleteLogo(fileName: string): Promise<IApiResponse<void | null>> {
    try {
        const session = await getAuthSession();

        if (!session.user) {
            throw new UnauthorizedError("User not authenticated");
        }

        const provider = createStorageProvider();
        const filePath = `${session.user.id}/${fileName}`;

        const exists = await provider.exists(filePath);

        if (!exists) {
            throw new StorageFileNotFoundError(`File not found: ${filePath}`);
        }

        await provider.deleteFile(filePath);

        return new ApiResponse<void>().noContent().toJSON();
    } catch (error) {
        console.error(error);
        return serverActionErrorHandler(error);
    }
}

export async function getAllQrCodeLogos(): Promise<IApiResponse<Logo[] | null>> {
    try {
        const session = await getAuthSession();

        if (!session.user) {
            throw new UnauthorizedError("User not authenticated");
        }

        const provider = createStorageProvider();

        const logos = await provider.listFiles(`${session.user.id}/`);

        const logoResults = await Promise.allSettled(
            logos.map(logo => provider.getFileUrl(`${session.user.id}/${logo}`))
        );

        // Extract only successful URLs and optionally log failures
        const fulfilled = logoResults
            .map((result, index) => ({ result, id: logos[index] }))
            .filter((r): r is { result: PromiseFulfilledResult<string>; id: string } =>
                r.result.status === "fulfilled");

        const logoPublicUrls = fulfilled.map(({ id, result }) => ({
            id,
            url: result.value
        }));

        // Optional: Log failed files for debugging
        const failedLogos = logoResults
            .map((result, index) => ({ result, logo: logos[index] }))
            .filter(({ result }) => result.status === 'rejected');

        if (failedLogos.length > 0) {
            console.warn('Failed to get URLs for some logos:',
                failedLogos.map(({ logo, result }) => ({
                    logoId: logo,
                    error: result.status === 'rejected' ? result.reason : null
                }))
            );
        }

        return new ApiResponse<Logo[]>().ok(logoPublicUrls).toJSON();
    } catch (error) {
        console.error(error);
        return serverActionErrorHandler(error);
    }
}

async function logoUploadLimitReached(userId: string, storageProvider: StorageProvider): Promise<boolean> {
    const logos = await storageProvider.listFiles(`${userId}/`);
    return logos.length >= APP_CONFIG.QR_CODE_LOGO_UPLOADS_LIMIT;
}