"use server";

import { getAuthSession } from "@/lib/auth-session";
import { QrCodeService } from "@/services/qr-code-service";
import { QrCodeInputDto, QrCodeInputSchema } from "@/schemas";
import { ApiResponse, IApiResponse } from "@/types/api-response";
import { serverActionErrorHandler } from "@/error/error-handler";
import { BadRequestError, ForbiddenError, UnauthorizedError } from "@/error";
import { createStorageProvider } from "@/lib/storage/storage-provider-factory";
import { QrCodeMapper } from "@/mapper/qr-code-mapper";
import { QrCodeResponseDto } from "@/types";

export async function createQrCode(inputDto: QrCodeInputDto): Promise<IApiResponse<QrCodeResponseDto | null>> {
    try {
        const session = await getAuthSession();

        if (!session.user?.id) {
            throw new UnauthorizedError("Unauthorized");
        }

        if (await QrCodeService.creationLimitReached(session.user.id)) {
            throw new ForbiddenError("QR Code creation limit reached");
        }

        const parseResult = QrCodeInputSchema.safeParse(inputDto);
        if (!parseResult.success) throw new BadRequestError("Invalid QR Data")

        const fileName = parseResult.data.designConfig.image;

        if (fileName && !fileName.startsWith("http") && !fileName.startsWith("blob:")) {
            const logoPath = await sanitizeAndConstructLogoPath(session.user.id, fileName);
            const storageProvider = createStorageProvider();
            const logoExists = await storageProvider.exists(logoPath);
            if (!logoExists) throw new BadRequestError("Logo not found")
            parseResult.data.designConfig.image = logoPath;
        }

        const createdQrDto = await QrCodeService.create(parseResult.data, session.user.id);
        return new ApiResponse<QrCodeResponseDto>().created(createdQrDto).toJSON();

    } catch (error) {
        return serverActionErrorHandler(error);
    }
}

async function sanitizeAndConstructLogoPath(
    userId: string,
    logoId: string
): Promise<string> {
    const sanitizedLogoId = logoId.replace(/[^a-zA-Z0-9._-]/g, '');
    const expectedPath = `${userId}/${sanitizedLogoId}`;
    return expectedPath;
}