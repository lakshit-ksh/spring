import { create } from 'zustand';
import { QrCodeDesignConfig } from '@/schemas';
import { QrCodeResponseDto } from '@/types/qr-code';

// Define the steps enum for clarity (now 2 steps: Content + Design)
export enum QrBuilderSteps {
    CONTENT = 0,
    DESIGN = 1,
}

interface QrBuilderState {
    activeStep: number;
    targetUrl: string;
    title: string;
    logoId: string | undefined;
    qrDesign: QrCodeDesignConfig;
    errors: Record<string, string>;

    // Edit mode
    editMode: boolean;
    editingQrCodeId: string | undefined;
    // Original image path from DB (for preserving unchanged logos)
    originalImagePath: string | undefined;

    // Actions
    setStep: (step: number) => void;
    setTargetUrl: (url: string) => void;
    setTitle: (title: string) => void;
    setErrors: (errors: Record<string, string>) => void;
    updateQrDesign: (design: Partial<QrCodeDesignConfig>) => void;
    setLogoId: (id: string | undefined) => void;
    initializeForEdit: (qrCode: QrCodeResponseDto, originalImagePath?: string) => void;
    reset: () => void;
}

const initialDesign: QrCodeDesignConfig = {
    width: 300,
    height: 300,
    data: 'https://example.com',
    margin: 10,
    dotsOptions: {
        color: '#000000',
        type: 'rounded'
    },
    backgroundOptions: {
        color: '#ffffff',
    },
    cornersSquareOptions: {
        color: '#000000',
        type: 'extra-rounded',
    },
    cornersDotOptions: {
        color: '#000000',
        type: 'dot',
    },
    imageOptions: {
        hideBackgroundDots: true,
        imageSize: 0.4,
        margin: 5,
    }
};

export const useQrBuilderStore = create<QrBuilderState>((set) => ({
    activeStep: QrBuilderSteps.CONTENT,
    targetUrl: '',
    title: '',
    logoId: undefined,
    qrDesign: initialDesign,
    errors: {},
    editMode: false,
    editingQrCodeId: undefined,
    originalImagePath: undefined,

    setStep: (step) => set({ activeStep: step }),
    setTargetUrl: (url) => set((state) => ({ targetUrl: url, errors: { ...state.errors, targetUrl: '' } })),
    setTitle: (title) => set((state) => ({ title, errors: { ...state.errors, title: '' } })),
    setErrors: (errors) => set({ errors }),
    setLogoId: (id) => set({ logoId: id }),
    updateQrDesign: (design) =>
        set((state) => ({
            qrDesign: { ...state.qrDesign, ...design } as QrCodeDesignConfig
        })),
    initializeForEdit: (qrCode, originalImagePath) => set({
        editMode: true,
        editingQrCodeId: qrCode.id,
        activeStep: QrBuilderSteps.CONTENT,
        targetUrl: qrCode.targetUrl,
        title: qrCode.title,
        qrDesign: {
            ...qrCode.designConfig,
            imageOptions: qrCode.designConfig.imageOptions || initialDesign.imageOptions
        },
        logoId: undefined, // Will be matched in StepDesignCustomizer via image URL
        originalImagePath: originalImagePath,
        errors: {}
    }),
    reset: () => set({
        activeStep: QrBuilderSteps.CONTENT,
        targetUrl: '',
        title: '',
        logoId: undefined,
        qrDesign: initialDesign,
        errors: {},
        editMode: false,
        editingQrCodeId: undefined,
        originalImagePath: undefined
    }),
}));
