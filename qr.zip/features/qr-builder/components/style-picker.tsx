"use client";

import clsx from "clsx";
import Image from "next/image";

interface StyleOption {
    value: string;
    label: string;
    imagePath: string;
}

interface StylePickerProps {
    options: StyleOption[];
    value: string | undefined;
    onChange: (value: string) => void;
    columns?: 3 | 4 | 6;
    compact?: boolean;
}

export function StylePicker({ options, value, onChange, columns = 3, compact = false }: StylePickerProps) {
    const gridColsClass = {
        3: "grid-cols-3",
        4: "grid-cols-4",
        6: "grid-cols-6",
    };

    return (
        <div className={clsx("grid gap-2", gridColsClass[columns])}>
            {options.map((option) => (
                <button
                    key={option.value}
                    type="button"
                    onClick={() => onChange(option.value)}
                    className={clsx(
                        "group relative flex flex-col items-center gap-1.5 rounded-lg border-2 transition-all duration-200",
                        compact ? "p-2" : "p-3",
                        "hover:border-primary/50 hover:bg-primary/5",
                        value === option.value
                            ? "border-primary bg-primary/10 shadow-sm"
                            : "border-muted bg-background"
                    )}
                >
                    <div className={clsx(
                        "relative rounded-md overflow-hidden bg-muted/50",
                        compact ? "w-10 h-10" : "w-full aspect-square"
                    )}>
                        <Image
                            src={option.imagePath}
                            alt={option.label}
                            fill
                            className="object-contain p-1.5 dark:invert dark:brightness-90"
                        />
                    </div>
                    <span
                        className={clsx(
                            "font-medium capitalize transition-colors",
                            compact ? "text-[10px]" : "text-xs",
                            value === option.value
                                ? "text-primary"
                                : "text-muted-foreground group-hover:text-foreground"
                        )}
                    >
                        {option.label}
                    </span>
                    {value === option.value && (
                        <div className={clsx(
                            "absolute bg-primary rounded-full flex items-center justify-center",
                            compact ? "-top-0.5 -right-0.5 w-4 h-4" : "-top-1 -right-1 w-5 h-5"
                        )}>
                            <svg
                                className={clsx("text-primary-foreground", compact ? "w-2.5 h-2.5" : "w-3 h-3")}
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                                strokeWidth={3}
                            >
                                <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    d="M5 13l4 4L19 7"
                                />
                            </svg>
                        </div>
                    )}
                </button>
            ))}
        </div>
    );
}

import { QR_DOT_STYLES, QR_CORNER_SQUARE_STYLES, QR_CORNER_DOT_STYLES } from "@/constants/qr-styles";

// Helper to Create Options
const createOptions = (values: readonly string[], path: string) =>
    values.map(value => ({
        value,
        label: value.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '),
        imagePath: `/images/styles/${path}/${value}.svg`
    }));

export const DOT_STYLE_OPTIONS: StyleOption[] = createOptions(QR_DOT_STYLES, 'dots');
export const CORNER_SQUARE_OPTIONS: StyleOption[] = createOptions(QR_CORNER_SQUARE_STYLES, 'corners');
export const CORNER_DOT_OPTIONS: StyleOption[] = createOptions(QR_CORNER_DOT_STYLES, 'corner-dots');
