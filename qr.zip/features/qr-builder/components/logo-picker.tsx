"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import { Loader2, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getAllQrCodeLogos, uploadLogo, deleteLogo } from "../actions/logo-actions";
import { cn } from "@/lib/utils";
import { APP_CONFIG, STORAGE_CONFIG } from "@/config";
import { Logo } from "@/types";

const LOGO_LIMIT = APP_CONFIG.QR_CODE_LOGO_UPLOADS_LIMIT;

interface LogoPickerProps {
    value: string | undefined;
    onChange: (logoId: string | undefined, logoUrl?: string) => void;
}

export function LogoPicker({ value, onChange }: LogoPickerProps) {
    const [logos, setLogos] = useState<Logo[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isUploading, setIsUploading] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [totalLogos, setTotalLogos] = useState(0);

    const limitReached = totalLogos >= LOGO_LIMIT;

    useEffect(() => {
        loadLogos();
    }, []);

    const loadLogos = async () => {
        try {
            const response = await getAllQrCodeLogos();
            if (response.success && response.data) {
                setLogos(response.data);
                setTotalLogos(response.data.length);
            }
        } catch (error) {
            console.error("Failed to load logos:", error);
        } finally {
            setIsLoading(false);
        }
    };

    const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        // Validation
        if (!file.type.startsWith("image/")) {
            alert("Please upload an image file");
            return;
        }
        if (file.size > STORAGE_CONFIG.MAX_FILE_SIZE) {
            alert(`Image size should be less than ${STORAGE_CONFIG.MAX_FILE_SIZE}KB`);
            return;
        }

        setIsUploading(true);
        try {
            const result = await uploadLogo(file);

            if (result.success && result.data) {
                // Select the new logo directly using the response
                onChange(result.data.id, result.data.url);

                // Refresh logos list in background
                await loadLogos();
            } else {
                console.error("Upload failed:", result.error);
                alert(result.error || "Failed to upload logo");
            }
        } catch (error) {
            console.error("Upload error:", error);
            alert("Failed to upload logo");
        } finally {
            setIsUploading(false);
            if (fileInputRef.current) fileInputRef.current.value = "";
        }
    };

    const handleDelete = async (e: React.MouseEvent, fileName: string) => {
        e.stopPropagation();
        if (!confirm("Delete this logo? Any QR codes that use this logo will be affected.")) return;

        try {
            const result = await deleteLogo(fileName);
            if (result.success) {
                // Clear selection if deleted logo was selected
                const deletedLogo = logos.find((l) => l.id === fileName);
                if (deletedLogo && value === deletedLogo.id) {
                    onChange(undefined);
                }
                await loadLogos();
            } else {
                alert(result.error || "Failed to delete logo");
            }
        } catch (error) {
            console.error("Delete error:", error);
            alert("Failed to delete logo");
        }
    };

    if (isLoading) {
        return (
            <div className="flex items-center justify-center h-24 border rounded-lg bg-muted/10">
                <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
            </div>
        );
    }

    return (
        <div className="space-y-3">
            <div className="grid grid-cols-4 gap-3">
                {/* Upload Button */}
                <button
                    type="button"
                    onClick={() => !limitReached && fileInputRef.current?.click()}
                    disabled={limitReached || isUploading}
                    className={cn(
                        "relative flex flex-col items-center justify-center aspect-square rounded-lg border-2 border-dashed transition-all",
                        limitReached
                            ? "border-muted bg-muted/20 cursor-not-allowed opacity-50"
                            : "border-muted hover:border-primary/50 hover:bg-primary/5 cursor-pointer"
                    )}
                >
                    {isUploading ? (
                        <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
                    ) : (
                        <Plus className="w-5 h-5 text-muted-foreground" />
                    )}
                    <span className="text-[10px] mt-1 text-muted-foreground font-medium">Add New</span>
                </button>

                <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleUpload}
                    className="hidden"
                />

                {/* None Option */}
                <button
                    type="button"
                    onClick={() => onChange(undefined)}
                    className={cn(
                        "relative flex flex-col items-center justify-center aspect-square rounded-lg border-2 transition-all",
                        !value
                            ? "border-primary bg-primary/5 ring-2 ring-primary/20"
                            : "border-muted hover:border-primary/50 hover:bg-muted/10 cursor-pointer"
                    )}
                >
                    <div className="w-5 h-5 rounded-full border-2 border-muted-foreground/30 flex items-center justify-center">
                        <div className="w-3 h-0.5 bg-muted-foreground/30 rotate-45" />
                    </div>
                    <span className="text-[10px] mt-1 text-muted-foreground font-medium">None</span>
                    {!value && (
                        <div className="absolute top-1 left-1 w-4 h-4 bg-primary rounded-full flex items-center justify-center shadow-sm">
                            <svg
                                className="w-2.5 h-2.5 text-white"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                                strokeWidth={3}
                            >
                                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                            </svg>
                        </div>
                    )}
                </button>

                {/* Logo Grid */}
                {logos.map((logo) => (
                    <div
                        key={logo.id}
                        onClick={() => onChange(logo.id, logo.url)}
                        className={cn(
                            "group relative aspect-square rounded-lg border-2 overflow-hidden cursor-pointer bg-white dark:bg-muted/10 transition-all",
                            value === logo.id
                                ? "border-primary ring-2 ring-primary/20"
                                : "border-muted hover:border-primary/50"
                        )}
                    >
                        <Image
                            src={logo.url}
                            alt="Logo"
                            fill
                            className="object-contain p-2"
                        />

                        {/* Delete Button (visible on hover) */}
                        <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <Button
                                variant="destructive"
                                size="icon"
                                className="h-6 w-6 rounded-full shadow-md"
                                onClick={(e) => handleDelete(e, logo.id)}
                            >
                                <Trash2 className="w-3 h-3" />
                            </Button>
                        </div>

                        {/* Selected Indicator */}
                        {value === logo.id && (
                            <div className="absolute top-1 left-1 w-4 h-4 bg-primary rounded-full flex items-center justify-center shadow-sm">
                                <svg
                                    className="w-2.5 h-2.5 text-white"
                                    fill="none"
                                    viewBox="0 0 24 24"
                                    stroke="currentColor"
                                    strokeWidth={3}
                                >
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                                </svg>
                            </div>
                        )}
                    </div>
                ))}
            </div>

            <div className="flex justify-between items-center text-xs text-muted-foreground">
                <span>
                    {limitReached ? "Limit reached" : `${totalLogos}/${LOGO_LIMIT} used`}
                </span>
                {limitReached && (
                    <span className="text-destructive">Delete items to upload more</span>
                )}
            </div>
        </div>
    );
}
