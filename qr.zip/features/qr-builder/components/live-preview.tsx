"use client";

import { useEffect, useRef } from "react";
import QRCodeStyling from "qr-code-styling";
import { useQrBuilderStore } from "../stores/qr-builder-store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";

export function LivePreview() {
    const { qrDesign, targetUrl } = useQrBuilderStore();
    const ref = useRef<HTMLDivElement>(null);
    const qrCode = useRef<QRCodeStyling>(null);

    useEffect(() => {
        const options = {
            ...qrDesign,
            data: targetUrl || 'https://example.com',
            width: 300,
            height: 300,
            type: 'svg' as const,
        };

        if (!qrCode.current) {
            qrCode.current = new QRCodeStyling(options);
            if (ref.current) {
                qrCode.current.append(ref.current);
            }
        } else {
            qrCode.current.update(options);
        }
    }, [qrDesign, targetUrl]);

    const handleDownload = () => {
        if (qrCode.current) {
            qrCode.current.download({ name: "my-qr-code", extension: "png" });
        }
    };

    return (
        <div className="sticky top-8 space-y-4">
            <Card className="p-8 flex items-center justify-center bg-white shadow-sm border-2 border-muted/20">
                <div ref={ref} className="bg-white rounded-lg overflow-hidden" />
            </Card>

            <Button
                className="w-full"
                size="lg"
                onClick={handleDownload}
                variant="outline"
            >
                <Download className="mr-2 h-4 w-4" />
                Download PNG
            </Button>
        </div>
    );
}
