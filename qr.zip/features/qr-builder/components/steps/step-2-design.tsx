"use client";

import { useQrBuilderStore } from "../../stores/qr-builder-store";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import {
    StylePicker,
    DOT_STYLE_OPTIONS,
    CORNER_SQUARE_OPTIONS,
    CORNER_DOT_OPTIONS,
} from "../style-picker";
import { LogoPicker } from "../logo-picker";
import { QrCodeDesignConfig } from "@/schemas";

type QrDesignCategory = keyof Pick<QrCodeDesignConfig, 'dotsOptions' | 'backgroundOptions' | 'cornersSquareOptions' | 'cornersDotOptions'>;

export function StepDesignCustomizer() {
    const { qrDesign, updateQrDesign, logoId, setLogoId } = useQrBuilderStore();

    const handleDeepChange = <T extends QrDesignCategory>(
        category: T,
        key: keyof NonNullable<QrCodeDesignConfig[T]>,
        value: string
    ) => {
        const categoryOptions = qrDesign[category];
        updateQrDesign({
            [category]: {
                ...categoryOptions,
                [key]: value
            }
        });
    };

    const handleLogoSelect = (id: string | undefined, url?: string) => {
        // Update store logic:
        // 1. logoId -> For selection state in LogoPicker
        // 2. image -> For live preview (needs URL)
        setLogoId(id);

        updateQrDesign({
            image: url, // Use URL for preview
            imageOptions: {
                ...qrDesign.imageOptions,
                hideBackgroundDots: url ? true : (qrDesign.imageOptions?.hideBackgroundDots ?? true),
                imageSize: qrDesign.imageOptions?.imageSize ?? 0.4,
                margin: qrDesign.imageOptions?.margin ?? 5,
            }
        });
    };

    return (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {/* Logo Section */}
            <div className="space-y-4">
                <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Logo</h3>
                <Separator />
                <div className="space-y-2">
                    <p className="text-sm text-muted-foreground pb-2">
                        Choose from your library or upload a new logo.
                    </p>
                    {/* LogoPicker uses logoId for selection state */}
                    <LogoPicker value={logoId} onChange={handleLogoSelect} />
                </div>
            </div>

            {/* Colors Section */}
            <div className="space-y-4">
                <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Colors</h3>
                <Separator />
                <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <Label>Foreground Color</Label>
                        <div className="flex items-center gap-2">
                            <Input
                                type="color"
                                className="w-12 h-12 p-1 cursor-pointer"
                                value={qrDesign.dotsOptions?.color}
                                onChange={(e) => handleDeepChange('dotsOptions', 'color', e.target.value)}
                            />
                            <span className="text-xs text-muted-foreground font-mono">{qrDesign.dotsOptions?.color}</span>
                        </div>
                    </div>
                    <div className="space-y-2">
                        <Label>Background Color</Label>
                        <div className="flex items-center gap-2">
                            <Input
                                type="color"
                                className="w-12 h-12 p-1 cursor-pointer"
                                value={qrDesign.backgroundOptions?.color}
                                onChange={(e) => handleDeepChange('backgroundOptions', 'color', e.target.value)}
                            />
                            <span className="text-xs text-muted-foreground font-mono">{qrDesign.backgroundOptions?.color}</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Pattern Style Section */}
            <div className="space-y-4">
                <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Pattern Style</h3>
                <Separator />
                <StylePicker
                    options={DOT_STYLE_OPTIONS}
                    value={qrDesign.dotsOptions?.type}
                    onChange={(val) => handleDeepChange('dotsOptions', 'type', val)}
                    columns={6}
                />
            </div>

            {/* Corners Section */}
            <div className="space-y-4">
                <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Corner Style</h3>
                <Separator />

                <div className="space-y-6">
                    <div className="space-y-3">
                        <Label className="text-sm">Corner Squares (outer border)</Label>
                        <StylePicker
                            options={CORNER_SQUARE_OPTIONS}
                            value={qrDesign.cornersSquareOptions?.type}
                            onChange={(val) => handleDeepChange('cornersSquareOptions', 'type', val)}
                            columns={3}
                            compact
                        />
                    </div>

                    <div className="space-y-3">
                        <Label className="text-sm">Corner Dots (inner shape)</Label>
                        <StylePicker
                            options={CORNER_DOT_OPTIONS}
                            value={qrDesign.cornersDotOptions?.type}
                            onChange={(val) => handleDeepChange('cornersDotOptions', 'type', val)}
                            columns={3}
                            compact
                        />
                    </div>

                    <div className="space-y-2">
                        <Label>Corner Color</Label>
                        <div className="flex items-center gap-2">
                            <Input
                                type="color"
                                className="w-12 h-12 p-1 cursor-pointer"
                                value={qrDesign.cornersSquareOptions?.color}
                                onChange={(e) => {
                                    handleDeepChange('cornersSquareOptions', 'color', e.target.value);
                                    handleDeepChange('cornersDotOptions', 'color', e.target.value);
                                }}
                            />
                            <span className="text-xs text-muted-foreground font-mono">{qrDesign.cornersSquareOptions?.color}</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
