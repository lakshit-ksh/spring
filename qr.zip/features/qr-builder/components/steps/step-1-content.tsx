"use client";

import { useQrBuilderStore } from "../../stores/qr-builder-store";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";

export function StepContentForm() {
    const { targetUrl, title, setTargetUrl, setTitle, errors } = useQrBuilderStore();

    return (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="space-y-4">
                <div className="space-y-2">
                    <Label htmlFor="title" className={errors.title ? "text-destructive" : ""}>
                        QR Code Name
                    </Label>
                    <Input
                        id="title"
                        placeholder="My Website QR"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        className={errors.title ? "border-destructive focus-visible:ring-destructive" : ""}
                    />
                    {errors.title ? (
                        <p className="text-xs text-destructive font-medium">{errors.title}</p>
                    ) : (
                        <p className="text-xs text-muted-foreground">A friendly name to identify this QR code.</p>
                    )}
                </div>

                <div className="space-y-2">
                    <Label htmlFor="url" className={errors.targetUrl ? "text-destructive" : ""}>
                        Destination URL
                    </Label>
                    <Input
                        id="url"
                        type="url"
                        placeholder="https://your-website.com"
                        value={targetUrl}
                        onChange={(e) => setTargetUrl(e.target.value)}
                        className={errors.targetUrl ? "border-destructive focus-visible:ring-destructive" : ""}
                    />
                    {errors.targetUrl ? (
                        <p className="text-xs text-destructive font-medium">{errors.targetUrl}</p>
                    ) : (
                        <p className="text-xs text-muted-foreground">Enter the link you want to direct users to.</p>
                    )}
                </div>
            </div>
        </div>
    );
}
