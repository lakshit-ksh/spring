"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, ArrowRight, Check, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQrBuilderStore, QrBuilderSteps } from "../stores/qr-builder-store";
import { StepContentForm } from "./steps/step-1-content";
import { StepDesignCustomizer } from "./steps/step-2-design";
import { LivePreview } from "./live-preview";
import { createQrCode } from "../actions/create-qr-code";
import { updateQrCode } from "@/features/dashboard/actions/qr-code-actions";
import { QrCodeResponseDto } from "@/types/qr-code";
import { useQrCodeCacheStore } from "@/features/dashboard/stores/qr-code-cache-store";

const STEP_TITLES = ["Content", "Design"];

interface BuilderLayoutProps {
    initialData?: QrCodeResponseDto;
    originalImagePath?: string;
}

export function BuilderLayout({ initialData, originalImagePath }: BuilderLayoutProps) {
    const router = useRouter();
    const [isSubmitting, setIsSubmitting] = useState(false);
    const {
        activeStep,
        setStep,
        targetUrl,
        title,
        logoId,
        qrDesign,
        setErrors,
        reset,
        editMode,
        editingQrCodeId,
        initializeForEdit,
        originalImagePath: storeOriginalPath,
    } = useQrBuilderStore();

    // Initialize store with existing data when editing
    useEffect(() => {
        if (initialData) {
            initializeForEdit(initialData, originalImagePath);
        }
        // Cleanup on unmount
        return () => {
            reset();
        };
    }, [initialData, initializeForEdit, reset]);

    const validateStep = (): boolean => {
        const errors: Record<string, string> = {};

        if (activeStep === QrBuilderSteps.CONTENT) {
            if (!title.trim()) {
                errors.title = "Please enter a name for your QR code";
            }
            if (!targetUrl.trim()) {
                errors.targetUrl = "Please enter a destination URL";
            } else {
                try {
                    new URL(targetUrl);
                } catch {
                    errors.targetUrl = "Please enter a valid URL";
                }
            }
        }

        setErrors(errors);
        return Object.keys(errors).length === 0;
    };

    const handleNext = () => {
        if (!validateStep()) return;

        if (activeStep < QrBuilderSteps.DESIGN) {
            setStep(activeStep + 1);
        }
    };

    const handleBack = () => {
        if (activeStep > QrBuilderSteps.CONTENT) {
            setStep(activeStep - 1);
        }
    };

    const handleSave = async () => {
        if (!validateStep()) return;

        setIsSubmitting(true);
        try {
            // Determine the image to send to the backend
            let imageToSave = logoId || qrDesign.image;

            // If we are in edit mode and no new logo was uploaded (logoId is undefined),
            // and the current design image is a URL (starts with http),
            // we should send the original image path instead to avoid corrupting it.
            if (editMode && !logoId && qrDesign.image?.startsWith('http') && storeOriginalPath) {
                imageToSave = storeOriginalPath;
            }

            const finalDesign = {
                ...qrDesign,
                data: targetUrl,
                image: imageToSave,
            };

            if (editMode && editingQrCodeId) {
                // Update existing QR code
                const result = await updateQrCode(editingQrCodeId, {
                    targetUrl,
                    title,
                    designConfig: finalDesign,
                });

                if (result.success && result.data) {
                    // Update local cache before redirecting
                    useQrCodeCacheStore.getState().updateQrCode(editingQrCodeId, result.data);

                    reset();
                    router.push("/dashboard");
                } else {
                    alert(result.error || "Failed to update QR code");
                }
            } else {
                // Create new QR code
                const result = await createQrCode({
                    targetUrl,
                    title,
                    designConfig: finalDesign,
                });

                if (result.success) {
                    reset();
                    router.push("/dashboard");
                } else {
                    alert(result.error || "Failed to create QR code");
                }
            }
        } catch (error) {
            console.error("Save error:", error);
            alert(editMode ? "Failed to update QR code" : "Failed to create QR code");
        } finally {
            setIsSubmitting(false);
        }
    };

    const renderStepContent = () => {
        switch (activeStep) {
            case QrBuilderSteps.CONTENT:
                return <StepContentForm />;
            case QrBuilderSteps.DESIGN:
                return <StepDesignCustomizer />;
            default:
                return null;
        }
    };

    return (
        <div className="container max-w-6xl py-8">
            {/* Step Indicator */}
            <div className="mb-8">
                <div className="flex items-center justify-center gap-4">
                    {STEP_TITLES.map((stepTitle, index) => (
                        <div key={stepTitle} className="flex items-center">
                            <button
                                onClick={() => {
                                    // In edit mode, allow navigation to any step
                                    // In create mode, only allow going back
                                    if (editMode || index < activeStep) {
                                        if (index < activeStep || validateStep()) {
                                            setStep(index);
                                        }
                                    }
                                }}
                                disabled={!editMode && index > activeStep}
                                className={`flex items-center gap-2 px-4 py-2 rounded-full font-medium text-sm transition-all ${index === activeStep
                                    ? "bg-primary text-primary-foreground shadow-sm"
                                    : index < activeStep || editMode
                                        ? "bg-primary/20 text-primary hover:bg-primary/30 cursor-pointer"
                                        : "bg-muted text-muted-foreground cursor-not-allowed"
                                    }`}
                            >
                                <span
                                    className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${index < activeStep
                                        ? "bg-primary text-primary-foreground"
                                        : index === activeStep
                                            ? "bg-primary-foreground text-primary"
                                            : "bg-muted-foreground/30"
                                        }`}
                                >
                                    {index < activeStep ? (
                                        <Check className="w-3.5 h-3.5" />
                                    ) : (
                                        index + 1
                                    )}
                                </span>
                                {stepTitle}
                            </button>
                            {index < STEP_TITLES.length - 1 && (
                                <div
                                    className={`w-16 h-0.5 mx-2 ${index < activeStep ? "bg-primary" : "bg-muted"
                                        }`}
                                />
                            )}
                        </div>
                    ))}
                </div>
            </div>

            {/* Main Content */}
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
                {/* Left: Step Form */}
                <div className="lg:col-span-3">
                    <Card className="shadow-sm">
                        <CardHeader>
                            <CardTitle className="text-xl">
                                {activeStep === QrBuilderSteps.CONTENT
                                    ? editMode ? "Edit QR code details" : "What's your QR code for?"
                                    : "Customize your design"}
                            </CardTitle>
                        </CardHeader>
                        <CardContent>{renderStepContent()}</CardContent>
                    </Card>

                    {/* Navigation Buttons */}
                    <div className="flex justify-between mt-6">
                        <Button
                            variant="outline"
                            onClick={handleBack}
                            disabled={activeStep === QrBuilderSteps.CONTENT}
                        >
                            <ArrowLeft className="mr-2 h-4 w-4" />
                            Back
                        </Button>

                        {activeStep === QrBuilderSteps.DESIGN ? (
                            <Button onClick={handleSave} disabled={isSubmitting}>
                                {isSubmitting ? (
                                    <>
                                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                        Saving...
                                    </>
                                ) : (
                                    <>
                                        <Check className="mr-2 h-4 w-4" />
                                        {editMode ? "Update QR Code" : "Save QR Code"}
                                    </>
                                )}
                            </Button>
                        ) : (
                            <Button onClick={handleNext}>
                                Next
                                <ArrowRight className="ml-2 h-4 w-4" />
                            </Button>
                        )}
                    </div>
                </div>

                {/* Right: Live Preview */}
                <div className="lg:col-span-2">
                    <LivePreview />
                </div>
            </div>
        </div>
    );
}

