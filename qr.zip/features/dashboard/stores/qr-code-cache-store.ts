"use client";

import { create } from "zustand";
import { QrCodeResponseDto } from "@/types/qr-code";
import { getQRCodes, searchQRCodes } from "../actions/get-qr-codes";

interface UsageInfo {
    count: number;
    limit: number;
}

interface QrCodeCacheState {
    // Data
    qrCodes: QrCodeResponseDto[];
    cursor: string | null;
    searchQuery: string;
    isLoading: boolean;
    isInitialized: boolean;
    usageInfo: UsageInfo | null;

    // Cache for original (non-searched) list
    originalQrCodes: QrCodeResponseDto[];
    originalCursor: string | null;

    // Actions
    initialize: (items: QrCodeResponseDto[], nextCursor: string | null, usageInfo?: UsageInfo) => void;
    loadMore: () => Promise<void>;
    search: (query: string) => void;
    reset: () => void;
    setUsageInfo: (info: UsageInfo) => void;
    updateQrCode: (id: string, updates: Partial<QrCodeResponseDto>) => void;
    removeQrCode: (id: string) => void;
}

export const useQrCodeCacheStore = create<QrCodeCacheState>((set, get) => ({
    qrCodes: [],
    cursor: null,
    searchQuery: "",
    isLoading: false,
    isInitialized: false,
    usageInfo: null,
    originalQrCodes: [],
    originalCursor: null,

    initialize: (items, nextCursor, usageInfo) => {
        const state = get();
        // Only initialize if not already initialized (prevents duplicate on remount)
        if (!state.isInitialized) {
            set({
                qrCodes: items,
                cursor: nextCursor,
                isInitialized: true,
                originalQrCodes: items,
                originalCursor: nextCursor,
                usageInfo: usageInfo ?? null,
            });
        }
    },

    loadMore: async () => {
        const state = get();
        if (state.isLoading || !state.cursor) return;

        set({ isLoading: true });

        try {
            const response = state.searchQuery
                ? await searchQRCodes(state.searchQuery, state.cursor)
                : await getQRCodes(state.cursor);

            if (response.success && response.data) {
                const { items, nextCursor } = response.data;
                set((s) => {
                    const newQrCodes = [...s.qrCodes, ...items];
                    // If not searching, also update the original cache
                    if (!s.searchQuery) {
                        return {
                            qrCodes: newQrCodes,
                            cursor: nextCursor,
                            originalQrCodes: newQrCodes,
                            originalCursor: nextCursor,
                        };
                    }
                    return {
                        qrCodes: newQrCodes,
                        cursor: nextCursor,
                    };
                });
            } else if (response.status === 401) {
                window.location.href = "/auth/signin";
            }
        } catch (error) {
            console.error("Failed to load more QR codes:", error);
        } finally {
            set({ isLoading: false });
        }
    },

    search: (query: string) => {
        const state = get();
        if (state.searchQuery === query) return;

        // If clearing search, restore from original cache
        if (!query) {
            set({
                searchQuery: "",
                qrCodes: state.originalQrCodes,
                cursor: state.originalCursor,
            });
            return;
        }

        // Start new search
        set({ searchQuery: query, isLoading: true, qrCodes: [], cursor: null });

        const fetchSearch = async () => {
            try {
                const response = await searchQRCodes(query, null);

                if (response.success && response.data) {
                    set({
                        qrCodes: response.data.items,
                        cursor: response.data.nextCursor,
                    });
                }
            } catch (error) {
                console.error("Search failed:", error);
            } finally {
                set({ isLoading: false });
            }
        };

        fetchSearch();
    },

    reset: () => {
        set({
            qrCodes: [],
            cursor: null,
            searchQuery: "",
            isLoading: false,
            isInitialized: false,
            usageInfo: null,
            originalQrCodes: [],
            originalCursor: null,
        });
    },

    setUsageInfo: (info) => {
        set({ usageInfo: info });
    },

    updateQrCode: (id, updates) => {
        set((state) => {
            const updateList = (list: QrCodeResponseDto[]) =>
                list.map((qr) => (qr.id === id ? { ...qr, ...updates } : qr));

            return {
                qrCodes: updateList(state.qrCodes),
                originalQrCodes: updateList(state.originalQrCodes),
            };
        });
    },

    removeQrCode: (id) => {
        set((state) => {
            const filterList = (list: QrCodeResponseDto[]) =>
                list.filter((qr) => qr.id !== id);

            const newUsageInfo = state.usageInfo
                ? { ...state.usageInfo, count: Math.max(0, state.usageInfo.count - 1) }
                : null;

            return {
                qrCodes: filterList(state.qrCodes),
                originalQrCodes: filterList(state.originalQrCodes),
                usageInfo: newUsageInfo,
            };
        });
    },
}));
