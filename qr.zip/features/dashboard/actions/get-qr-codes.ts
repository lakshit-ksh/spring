"use server";

import { getAuthSession } from "@/lib/auth-session";
import { QrCodeService } from "@/services/qr-code-service";
import { ApiResponse, IApiResponse } from "@/types/api-response";
import { QrCodeResponseDto } from "@/types/qr-code";
import { serverActionErrorHandler } from "@/error/error-handler";
import { CursorPaginatedResult } from "@/types";
import { createStorageProvider } from "@/lib/storage/storage-provider-factory";
import { HttpStatus } from "@/constants/http";

export async function getQRCodes(cursor: string | null = null): Promise<IApiResponse<CursorPaginatedResult<QrCodeResponseDto> | null>> {
	let session;
	try {
		session = await getAuthSession();
	} catch (error) {
		return serverActionErrorHandler(error);
	}

	if (!session.user?.id) {
		return new ApiResponse<CursorPaginatedResult<QrCodeResponseDto>>().setStatus(HttpStatus.UNAUTHORIZED).setError("Unauthorized").toJSON();
	}

	try {
		const { items, nextCursor } = await QrCodeService.getAllByOwnerId(
			session.user.id,
			cursor
		);

		const storageProvider = createStorageProvider();
		const promiseSettledLogoUrls = await Promise.allSettled(
			items.map(async (qr) => {
				if (!qr.designConfig.image) {
					return undefined;
				}

				try {
					const logoExists = await storageProvider.exists(qr.designConfig.image);
					if (!logoExists) {
						return undefined;
					}
					const logoUrl = await storageProvider.getFileUrl(qr.designConfig.image);
					return logoUrl;
				} catch (error) {
					console.warn(`Failed to fetch logo URL for QR ${qr.id}: `, error);
					return undefined;
				}
			}));
		const logoUrls = promiseSettledLogoUrls.map((logoUrl) => logoUrl.status === "fulfilled" ? logoUrl.value : undefined);
		const itemsWithLogoUrls = items.map((qr, index) => {
			return {
				...qr,
				designConfig: {
					...qr.designConfig,
					image: logoUrls[index]
				}
			}
		})
		// console.log(itemsWithLogoUrls);
		return new ApiResponse<CursorPaginatedResult<QrCodeResponseDto>>().ok({ items: itemsWithLogoUrls, nextCursor }).toJSON();

	} catch (error) {
		return serverActionErrorHandler(error);
	}
}

export async function searchQRCodes(query: string, cursor: string | null = null): Promise<IApiResponse<CursorPaginatedResult<QrCodeResponseDto> | null>> {
	let session;
	try {
		session = await getAuthSession();
	} catch (error) {
		return serverActionErrorHandler(error);
	}

	if (!session.user?.id) {
		return new ApiResponse<CursorPaginatedResult<QrCodeResponseDto>>().setStatus(HttpStatus.UNAUTHORIZED).setError("Unauthorized").toJSON();
	}

	try {
		const { items, nextCursor } = await QrCodeService.searchAllByOwnerId(
			session.user.id,
			query,
			cursor
		);

		return new ApiResponse<CursorPaginatedResult<QrCodeResponseDto>>().ok({ items, nextCursor }).toJSON();

	} catch (error) {
		return serverActionErrorHandler(error);
	}
}