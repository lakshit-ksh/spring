"use server";

import { QrCodeService } from "@/services/qr-code-service";
import { getAuthSession } from "@/lib/auth-session";
import { UnauthorizedError, BadRequestError } from "@/error";
import { ApiResponse, IApiResponse } from "@/types/api-response";
import { serverActionErrorHandler } from "@/error/error-handler";
import { CursorPaginatedResult, QrCodeResponseDto } from "@/types";
import { QrCodeUpdateDto, QrCodeUpdateSchema } from "@/schemas";
import { createStorageProvider } from "@/lib/storage/storage-provider-factory";
import { HttpStatus } from "@/constants/http";

export interface QrUsageInfo {
    count: number;
    limit: number;
}

async function sanitizeAndConstructLogoPath(userId: string, logoId: string): Promise<string> {
    const sanitizedLogoId = logoId.replace(/[^a-zA-Z0-9._-]/g, "");
    return `${userId}/${sanitizedLogoId}`;
}

export async function updateQrCode(
    qrCodeId: string,
    updateDto: QrCodeUpdateDto
): Promise<IApiResponse<QrCodeResponseDto | null>> {
    try {
        const session = await getAuthSession();

        if (!session.user?.id) {
            throw new UnauthorizedError("Unauthorized");
        }

        const parseResult = QrCodeUpdateSchema.safeParse(updateDto);
        if (!parseResult.success) {
            throw new BadRequestError("Invalid update data");
        }

        // Sync designConfig.data with targetUrl if both are being updated
        if (parseResult.data.targetUrl && parseResult.data.designConfig) {
            parseResult.data.designConfig.data = parseResult.data.targetUrl;
        }

        // Handle logo path if designConfig includes image
        const logoId = parseResult.data.designConfig?.image;
        if (logoId && !logoId.startsWith("http") && !logoId.startsWith("blob:")) {
            const logoPath = await sanitizeAndConstructLogoPath(session.user.id, logoId);
            const storageProvider = createStorageProvider();
            const logoExists = await storageProvider.exists(logoPath);
            if (!logoExists) {
                throw new BadRequestError("Logo not found");
            }
            parseResult.data.designConfig!.image = logoPath;
        }

        const updatedQrCode = await QrCodeService.update(
            qrCodeId,
            session.user.id,
            parseResult.data
        );

        return new ApiResponse<QrCodeResponseDto>().ok(updatedQrCode).toJSON();
    } catch (error) {
        return serverActionErrorHandler(error);
    }
}

export async function deleteQrCode(
    qrCodeId: string
): Promise<IApiResponse<QrCodeResponseDto | null>> {
    try {
        const session = await getAuthSession();

        if (!session.user?.id) {
            throw new UnauthorizedError("Unauthorized");
        }

        const deletedQrCode = await QrCodeService.hardDelete(qrCodeId, session.user.id);

        return new ApiResponse<QrCodeResponseDto>().ok(deletedQrCode).toJSON();
    } catch (error) {
        return serverActionErrorHandler(error);
    }
}

export async function getQRCodes(cursor: string | null = null): Promise<IApiResponse<CursorPaginatedResult<QrCodeResponseDto> | null>> {
    try {
        const session = await getAuthSession();

        if (!session.user?.id) {
            throw new UnauthorizedError("Unauthorized");
        }

        const { items, nextCursor } = await QrCodeService.getAllByOwnerId(
            session.user.id,
            cursor
        );

        const storageProvider = createStorageProvider();
        const promiseSettledLogoUrls = await Promise.allSettled(
            items.map(async (qr) => {
                if (!qr.designConfig.image) {
                    return undefined;
                }

                try {
                    const logoExists = await storageProvider.exists(qr.designConfig.image);
                    if (!logoExists) {
                        return undefined;
                    }
                    const logoUrl = await storageProvider.getFileUrl(qr.designConfig.image);
                    return logoUrl;
                } catch (error) {
                    console.warn(`Failed to fetch logo URL for QR ${qr.id}: `, error);
                    return undefined;
                }
            }));
        const logoUrls = promiseSettledLogoUrls.map((logoUrl) => logoUrl.status === "fulfilled" ? logoUrl.value : undefined);
        const itemsWithLogoUrls = items.map((qr, index) => {
            return {
                ...qr,
                designConfig: {
                    ...qr.designConfig,
                    image: logoUrls[index]
                }
            }
        })
        return new ApiResponse<CursorPaginatedResult<QrCodeResponseDto>>().ok({ items: itemsWithLogoUrls, nextCursor }).toJSON();

    } catch (error) {
        return serverActionErrorHandler(error);
    }
}

export async function searchQRCodes(query: string, cursor: string | null = null): Promise<IApiResponse<CursorPaginatedResult<QrCodeResponseDto> | null>> {
    try {
        const session = await getAuthSession();

        if (!session.user?.id) {
            throw new UnauthorizedError("Unauthorized");
        }

        const { items, nextCursor } = await QrCodeService.searchAllByOwnerId(
            session.user.id,
            query,
            cursor
        );

        return new ApiResponse<CursorPaginatedResult<QrCodeResponseDto>>().ok({ items, nextCursor }).toJSON();

    } catch (error) {
        return serverActionErrorHandler(error);
    }
}
export async function getQrUsage(): Promise<IApiResponse<QrUsageInfo | null>> {
    try {
        const session = await getAuthSession();

        if (!session.user?.id) {
            throw new UnauthorizedError("Unauthorized");
        }

        const usageInfo = await QrCodeService.getUsageInfo(session.user.id);

        return new ApiResponse<QrUsageInfo>().ok(usageInfo).toJSON();
    } catch (error) {
        return serverActionErrorHandler(error);
    }
}
