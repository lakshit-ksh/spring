"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Loader2 } from "lucide-react";
import {
    StylePicker,
    DOT_STYLE_OPTIONS,
    CORNER_SQUARE_OPTIONS,
    CORNER_DOT_OPTIONS,
} from "@/features/qr-builder/components/style-picker";
import { LogoPicker } from "@/features/qr-builder/components/logo-picker";
import { QrCodeResponseDto } from "@/types/qr-code";
import { QrCodeDesignConfig } from "@/schemas";
import QRCodeStyling from "qr-code-styling";

interface QrDesignEditDialogProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    qrcode: QrCodeResponseDto;
    onSave: (designConfig: QrCodeDesignConfig, logoId?: string) => Promise<void>;
}

export function QrDesignEditDialog({
    open,
    onOpenChange,
    qrcode,
    onSave,
}: QrDesignEditDialogProps) {
    const [designConfig, setDesignConfig] = useState<QrCodeDesignConfig>(qrcode.designConfig);
    const [logoId, setLogoId] = useState<string | undefined>(undefined);
    const [isLoading, setIsLoading] = useState(false);

    const previewRef = useRef<HTMLDivElement>(null);
    const qrCodeInstance = useRef<QRCodeStyling | null>(null);

    // Reset state when dialog opens with new QR code
    useEffect(() => {
        if (open) {
            setDesignConfig(qrcode.designConfig);
            setLogoId(undefined);
        }
    }, [open, qrcode.designConfig]);

    // Initialize and update QR preview
    useEffect(() => {
        if (!open) return;

        const options = {
            ...designConfig,
            data: qrcode.targetUrl,
            width: 200,
            height: 200,
            type: "svg" as const,
        };

        if (!qrCodeInstance.current) {
            qrCodeInstance.current = new QRCodeStyling(options);
            if (previewRef.current) {
                previewRef.current.innerHTML = "";
                qrCodeInstance.current.append(previewRef.current);
            }
        } else {
            qrCodeInstance.current.update(options);
        }
    }, [designConfig, qrcode.targetUrl, open]);

    // Cleanup QR instance when dialog closes
    useEffect(() => {
        if (!open) {
            qrCodeInstance.current = null;
        }
    }, [open]);

    const handleDeepChange = useCallback((
        category: "dotsOptions" | "backgroundOptions" | "cornersSquareOptions" | "cornersDotOptions",
        key: string,
        value: string
    ) => {
        setDesignConfig((prev) => ({
            ...prev,
            [category]: {
                ...prev[category],
                [key]: value,
            },
        }));
    }, []);

    const handleLogoSelect = useCallback((id: string | undefined, url?: string) => {
        setLogoId(id);
        setDesignConfig((prev) => ({
            ...prev,
            image: url,
            imageOptions: url
                ? {
                    hideBackgroundDots: true,
                    imageSize: 0.4,
                    margin: 5,
                }
                : undefined,
        }));
    }, []);

    const handleSave = async () => {
        setIsLoading(true);
        try {
            await onSave(designConfig, logoId);
            onOpenChange(false);
        } catch (error) {
            console.error("Failed to save design:", error);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
                <DialogHeader>
                    <DialogTitle>Edit QR Code Design</DialogTitle>
                </DialogHeader>

                <div className="flex-1 overflow-y-auto">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 p-1">
                        {/* Left: Design Options */}
                        <div className="space-y-6 overflow-y-auto max-h-[60vh] pr-2">
                            {/* Logo Section */}
                            <div className="space-y-3">
                                <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">
                                    Logo
                                </h3>
                                <Separator />
                                <p className="text-sm text-muted-foreground">
                                    Choose from your library or upload a new logo.
                                </p>
                                <LogoPicker value={logoId} onChange={handleLogoSelect} />
                            </div>

                            {/* Colors Section */}
                            <div className="space-y-3">
                                <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">
                                    Colors
                                </h3>
                                <Separator />
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <Label>Foreground Color</Label>
                                        <div className="flex items-center gap-2">
                                            <Input
                                                type="color"
                                                className="w-10 h-10 p-1 cursor-pointer"
                                                value={designConfig.dotsOptions?.color || "#000000"}
                                                onChange={(e) =>
                                                    handleDeepChange("dotsOptions", "color", e.target.value)
                                                }
                                            />
                                            <span className="text-xs text-muted-foreground font-mono">
                                                {designConfig.dotsOptions?.color}
                                            </span>
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Background Color</Label>
                                        <div className="flex items-center gap-2">
                                            <Input
                                                type="color"
                                                className="w-10 h-10 p-1 cursor-pointer"
                                                value={designConfig.backgroundOptions?.color || "#ffffff"}
                                                onChange={(e) =>
                                                    handleDeepChange("backgroundOptions", "color", e.target.value)
                                                }
                                            />
                                            <span className="text-xs text-muted-foreground font-mono">
                                                {designConfig.backgroundOptions?.color}
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Pattern Style Section */}
                            <div className="space-y-3">
                                <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">
                                    Pattern Style
                                </h3>
                                <Separator />
                                <StylePicker
                                    options={DOT_STYLE_OPTIONS}
                                    value={designConfig.dotsOptions?.type}
                                    onChange={(val) => handleDeepChange("dotsOptions", "type", val)}
                                    columns={6}
                                />
                            </div>

                            {/* Corners Section */}
                            <div className="space-y-3">
                                <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">
                                    Corner Style
                                </h3>
                                <Separator />
                                <div className="space-y-4">
                                    <div className="space-y-2">
                                        <Label className="text-sm">Corner Squares</Label>
                                        <StylePicker
                                            options={CORNER_SQUARE_OPTIONS}
                                            value={designConfig.cornersSquareOptions?.type}
                                            onChange={(val) =>
                                                handleDeepChange("cornersSquareOptions", "type", val)
                                            }
                                            columns={3}
                                            compact
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label className="text-sm">Corner Dots</Label>
                                        <StylePicker
                                            options={CORNER_DOT_OPTIONS}
                                            value={designConfig.cornersDotOptions?.type}
                                            onChange={(val) =>
                                                handleDeepChange("cornersDotOptions", "type", val)
                                            }
                                            columns={3}
                                            compact
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Corner Color</Label>
                                        <div className="flex items-center gap-2">
                                            <Input
                                                type="color"
                                                className="w-10 h-10 p-1 cursor-pointer"
                                                value={designConfig.cornersSquareOptions?.color || "#000000"}
                                                onChange={(e) => {
                                                    handleDeepChange("cornersSquareOptions", "color", e.target.value);
                                                    handleDeepChange("cornersDotOptions", "color", e.target.value);
                                                }}
                                            />
                                            <span className="text-xs text-muted-foreground font-mono">
                                                {designConfig.cornersSquareOptions?.color}
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Right: Live Preview */}
                        <div className="flex flex-col items-center justify-start lg:sticky lg:top-0">
                            <div className="space-y-3">
                                <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground text-center">
                                    Preview
                                </h3>
                                <div className="bg-white p-6 rounded-xl border-2 border-muted/20 shadow-sm">
                                    <div ref={previewRef} className="overflow-hidden" />
                                </div>
                                <p className="text-xs text-muted-foreground text-center">
                                    Changes are previewed in real-time
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <DialogFooter className="mt-4">
                    <Button
                        variant="outline"
                        onClick={() => onOpenChange(false)}
                        disabled={isLoading}
                    >
                        Cancel
                    </Button>
                    <Button onClick={handleSave} disabled={isLoading}>
                        {isLoading ? (
                            <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Saving...
                            </>
                        ) : (
                            "Save Changes"
                        )}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}
