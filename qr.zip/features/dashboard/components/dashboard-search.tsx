"use client";

import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useEffect, useState } from "react";

interface DashboardSearchProps {
    onSearch: (query: string) => void;
}

export function DashboardSearch({ onSearch }: DashboardSearchProps) {
    const [value, setValue] = useState("");

    useEffect(() => {
        const timeoutId = setTimeout(() => {
            onSearch(value);
        }, 500);

        return () => clearTimeout(timeoutId);
    }, [value, onSearch]);

    return (
        <div className="relative w-full md:w-[300px]">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
                type="search"
                placeholder="Search filtered QR codes..."
                className="pl-9 w-full"
                value={value}
                onChange={(e) => setValue(e.target.value)}
            />
        </div>
    );
}
