"use client";

import { QrCode } from "lucide-react";
import { cn } from "@/lib/utils";

interface QrUsageBadgeProps {
    count: number;
    limit: number;
    className?: string;
}

export function QrUsageBadge({ count, limit, className }: QrUsageBadgeProps) {
    const percentage = (count / limit) * 100;
    const isNearLimit = percentage >= 80;
    const isAtLimit = count >= limit;

    return (
        <div
            className={cn(
                "flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium",
                isAtLimit
                    ? "bg-destructive/10 text-destructive"
                    : isNearLimit
                        ? "bg-yellow-500/10 text-yellow-600 dark:text-yellow-500"
                        : "bg-primary/10 text-primary",
                className
            )}
        >
            <QrCode className="h-4 w-4" />
            <span>
                {count} / {limit} QR Codes
            </span>
        </div>
    );
}
