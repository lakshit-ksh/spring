"use client";

import { useCallback, useEffect, useRef } from "react";
import { QrCodeResponseDto } from "@/types/qr-code";
import { QrCodeCard } from "./qr-code-card";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { DashboardSearch } from "./dashboard-search";
import { QrUsageBadge } from "./qr-usage-badge";
import { useQrCodeCacheStore } from "../stores/qr-code-cache-store";

interface UsageInfo {
    count: number;
    limit: number;
}

interface QrCodeGridProps {
    initialData: {
        items: QrCodeResponseDto[];
        nextCursor: string | null;
    };
    initialUsageInfo?: UsageInfo;
}

export function QrCodeGrid({ initialData, initialUsageInfo }: QrCodeGridProps) {
    const {
        qrCodes,
        cursor,
        isLoading,
        searchQuery,
        isInitialized,
        usageInfo,
        initialize,
        loadMore,
        search,
        updateQrCode,
        removeQrCode,
    } = useQrCodeCacheStore();

    const observerTarget = useRef<HTMLDivElement>(null);

    // Initialize store with server data (only once)
    useEffect(() => {
        initialize(initialData.items, initialData.nextCursor, initialUsageInfo);
    }, [initialize, initialData, initialUsageInfo]);

    // Keep a ref for isLoading to avoid recreating observer on state change
    const isLoadingRef = useRef(isLoading);
    useEffect(() => {
        isLoadingRef.current = isLoading;
    }, [isLoading]);

    // Infinite scroll observer
    useEffect(() => {
        if (!isInitialized) return;

        const observer = new IntersectionObserver(
            (entries) => {
                if (entries[0].isIntersecting && cursor && !isLoadingRef.current) {
                    loadMore();
                }
            },
            { threshold: 0.1 }
        );

        if (observerTarget.current) {
            observer.observe(observerTarget.current);
        }

        return () => observer.disconnect();
    }, [cursor, loadMore, isInitialized]);

    // Handlers for card mutations
    const handleQrUpdate = useCallback(
        (updatedQr: QrCodeResponseDto) => {
            updateQrCode(updatedQr.id, updatedQr);
        },
        [updateQrCode]
    );

    const handleQrDelete = useCallback(
        (id: string) => {
            removeQrCode(id);
        },
        [removeQrCode]
    );

    // Use cached data if initialized, otherwise use initialData for SSR
    const displayItems = isInitialized ? qrCodes : initialData.items;
    const displayUsageInfo = isInitialized ? usageInfo : initialUsageInfo;

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between gap-4">
                {displayUsageInfo && (
                    <QrUsageBadge
                        count={displayUsageInfo.count}
                        limit={displayUsageInfo.limit}
                    />
                )}
                <div className="flex-1 flex justify-end">
                    <DashboardSearch onSearch={search} />
                </div>
            </div>

            {displayItems.length === 0 && !isLoading ? (
                <div className="flex flex-col items-center justify-center p-12 text-center border-2 border-dashed rounded-lg bg-muted/10 h-[400px]">
                    <div className="bg-primary/10 p-4 rounded-full mb-4">
                        <span className="text-4xl">🚀</span>
                    </div>
                    <h3 className="text-xl font-semibold mb-2">
                        {searchQuery ? "No matching QR Codes" : "No QR Codes yet"}
                    </h3>
                    <p className="text-muted-foreground max-w-sm mb-6">
                        {searchQuery
                            ? "Try adjusting your search terms."
                            : "Create your first QR code to start tracking scans and engaging your audience."}
                    </p>
                    {!searchQuery && (
                        <Link href="/dashboard/create">
                            <Button>Create QR Code</Button>
                        </Link>
                    )}
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {displayItems.map((qr) => (
                        <QrCodeCard
                            key={qr.id}
                            qrcode={qr}
                            onUpdate={handleQrUpdate}
                            onDelete={handleQrDelete}
                        />
                    ))}
                </div>
            )}

            {(isInitialized ? cursor : initialData.nextCursor) && (
                <div ref={observerTarget} className="flex justify-center p-4">
                    {isLoading && (
                        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                    )}
                </div>
            )}
        </div>
    );
}
