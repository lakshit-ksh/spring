"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, BarChart2, Settings, Plus, User, LogOut, Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import clsx from "clsx";
import { useQrBuilderStore } from "@/features/qr-builder/stores/qr-builder-store";
import { signOut } from "next-auth/react";
import { useTheme } from "next-themes";

const navItems = [
	{ href: "/dashboard", label: "Dashboard", icon: Home },
	{ href: "/dashboard/analytics", label: "Analytics", icon: BarChart2 },
	{ href: "/dashboard/settings", label: "Settings", icon: Settings },
];

export function DashboardSidebar() {
	const pathname = usePathname();
	const resetQr = useQrBuilderStore((state) => state.reset);
	const { theme, setTheme } = useTheme();

	const handleSignOut = async () => {
		await signOut({ callbackUrl: '/' });
	};

	return (
		<div className="flex flex-col h-full border-r bg-muted/30">
			<div className="p-6 border-b">
				<Link href="/dashboard" className="flex items-center gap-2 font-bold text-xl">
					<div className="p-1.5 bg-primary rounded-md text-primary-foreground">
						<div className="w-5 h-5 flex items-center justify-center font-black">Q</div>
					</div>
					QR Generator
				</Link>
			</div>

			<div className="p-4">
				<Link href="/dashboard/create" onClick={resetQr}>
					<Button className="w-full justify-start gap-2" size="lg">
						<Plus className="h-4 w-4" />
						Create New QR
					</Button>
				</Link>
			</div>

			<nav className="flex-1 px-4 space-y-1">
				{navItems.map((item) => {
					const isActive = pathname === item.href;
					return (
						<Link
							key={item.href}
							href={item.href}
							className={clsx(
								"flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors",
								{
									"bg-primary/10 text-primary": isActive,
									"text-muted-foreground hover:bg-muted hover:text-foreground": !isActive,
								}
							)}
						>
							<item.icon className="h-4 w-4" />
							{item.label}
						</Link>
					);
				})}
			</nav>

			<div className="p-4 border-t space-y-2">
				<Button
					variant="ghost"
					className="w-full justify-start gap-3"
					onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
				>
					<Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
					<Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
					<span className="ml-2">Toggle Theme</span>
				</Button>

				<Button
					variant="ghost"
					className="w-full justify-start gap-3 text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/20"
					onClick={handleSignOut}
				>
					<LogOut className="h-4 w-4" />
					Sign Out
				</Button>
			</div>
		</div>
	);
}
