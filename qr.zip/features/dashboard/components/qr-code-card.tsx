"use client";

import { useState, useCallback, useEffect, useRef } from "react";
import { QrCodeResponseDto } from "@/types/qr-code";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { ExternalLink, Calendar, MoreVertical, Download, Pencil, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuItem,
	DropdownMenuSeparator,
	DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import Link from "next/link";
import QRCodeStyling from "qr-code-styling";
import { InlineEditInput } from "@/components/shared/inline-edit-input";
import { DeleteConfirmDialog } from "@/components/shared/delete-confirm-dialog";
import { updateQrCode, deleteQrCode } from "../actions/qr-code-actions";

interface QrCodeCardProps {
	qrcode: QrCodeResponseDto;
	onUpdate?: (qrcode: QrCodeResponseDto) => void;
	onDelete?: (id: string) => void;
}

export function QrCodeCard({ qrcode, onUpdate, onDelete }: QrCodeCardProps) {
	const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
	const [isDeleting, setIsDeleting] = useState(false);

	// Format date safely
	const formattedDate = new Date(qrcode.createdAt).toLocaleDateString("en-US", {
		month: "short",
		day: "numeric",
		year: "numeric",
	});

	const qrPreviewRef = useRef<HTMLDivElement>(null);
	const qrCodeInstance = useRef<QRCodeStyling | null>(null);

	useEffect(() => {
		if (qrcode.designConfig) {
			const options = {
				...qrcode.designConfig,
				width: 200,
				height: 200,
				data: qrcode.targetUrl,
			};
			if (!qrCodeInstance.current) {
				qrCodeInstance.current = new QRCodeStyling(options);
				if (qrPreviewRef.current) {
					qrCodeInstance.current.append(qrPreviewRef.current);
				}
			} else {
				qrCodeInstance.current.update(options);
			}
		}
	}, [qrcode]);

	const handleDownload = useCallback(() => {
		if (qrCodeInstance.current) {
			qrCodeInstance.current.download({
				name: qrcode.title || "qr-code",
				extension: "png",
			});
		}
	}, [qrcode.title]);

	const handleTitleSave = useCallback(
		async (newTitle: string) => {
			const response = await updateQrCode(qrcode.id, { title: newTitle });
			if (!response.success) {
				throw new Error(response.error || "Failed to update title");
			}
			if (response.data && onUpdate) {
				onUpdate(response.data);
			}
		},
		[qrcode.id, onUpdate]
	);

	const handleUrlSave = useCallback(
		async (newUrl: string) => {
			const response = await updateQrCode(qrcode.id, { targetUrl: newUrl });
			if (!response.success) {
				throw new Error(response.error || "Failed to update URL");
			}
			if (response.data && onUpdate) {
				onUpdate(response.data);
			}
		},
		[qrcode.id, onUpdate]
	);

	const handleDelete = useCallback(async () => {
		setIsDeleting(true);
		try {
			const response = await deleteQrCode(qrcode.id);
			if (!response.success) {
				throw new Error(response.error || "Failed to delete QR code");
			}
			setIsDeleteDialogOpen(false);
			if (onDelete) {
				onDelete(qrcode.id);
			}
		} catch (error) {
			console.error("Delete failed:", error);
			alert(error instanceof Error ? error.message : "Failed to delete QR code");
		} finally {
			setIsDeleting(false);
		}
	}, [qrcode.id, onDelete]);

	const validateUrl = useCallback((value: string): string | null => {
		try {
			new URL(value);
			return null;
		} catch {
			return "Please enter a valid URL";
		}
	}, []);

	const validateTitle = useCallback((value: string): string | null => {
		if (!value.trim()) {
			return "Title is required";
		}
		if (value.length > 255) {
			return "Title must be less than 255 characters";
		}
		return null;
	}, []);

	return (
		<>
			<Card className="overflow-hidden hover:shadow-md transition-shadow group">
				<CardContent className="p-0">
					<div className="aspect-square relative bg-muted/20 flex items-center justify-center border-b">
						<div ref={qrPreviewRef} className="bg-white p-2 rounded-md" />

						<div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
							<DropdownMenu>
								<DropdownMenuTrigger asChild>
									<Button
										variant="ghost"
										size="icon"
										className="h-8 w-8 bg-background/80 backdrop-blur-sm"
										suppressHydrationWarning
									>
										<MoreVertical className="h-4 w-4" />
									</Button>
								</DropdownMenuTrigger>
								<DropdownMenuContent align="end">
									<DropdownMenuItem onClick={handleDownload}>
										<Download className="mr-2 h-4 w-4" />
										Download
									</DropdownMenuItem>
									<DropdownMenuItem asChild>
										<Link href={`/dashboard/${qrcode.id}/edit`}>
											<Pencil className="mr-2 h-4 w-4" />
											Edit
										</Link>
									</DropdownMenuItem>
									<DropdownMenuSeparator />
									<DropdownMenuItem
										onClick={() => setIsDeleteDialogOpen(true)}
										className="text-destructive focus:text-destructive"
									>
										<Trash2 className="mr-2 h-4 w-4" />
										Delete
									</DropdownMenuItem>
								</DropdownMenuContent>
							</DropdownMenu>
						</div>
					</div>
				</CardContent>

				<CardFooter className="flex flex-col items-start p-4 gap-3">
					<div className="space-y-2 w-full">
						{/* Editable Title */}
						<InlineEditInput
							value={qrcode.title}
							onSave={handleTitleSave}
							validation={validateTitle}
							placeholder="Enter title..."
							displayClassName="font-semibold text-base"
						/>

						{/* Editable URL */}
						<div className="flex items-center gap-1.5 text-xs text-muted-foreground w-full">
							<ExternalLink className="h-3 w-3 shrink-0" />
							<InlineEditInput
								value={qrcode.targetUrl}
								onSave={handleUrlSave}
								validation={validateUrl}
								placeholder="Enter URL..."
								className="flex-1 min-w-0"
								displayClassName="truncate"
								renderDisplay={(value) => (
									<span
										className="truncate hover:underline"
										title={value}
										onClick={(e) => {
											// Allow clicking to edit, not open link
											e.stopPropagation();
										}}
									>
										{value}
									</span>
								)}
							/>
						</div>
					</div>

					<div className="w-full flex items-center justify-between pt-2 border-t">
						<div className="flex items-center gap-1.5 text-xs text-muted-foreground">
							<Calendar className="h-3 w-3" />
							{formattedDate}
						</div>
						<Link href={`/dashboard/${qrcode.id}/analytics`}>
							<Button variant="ghost" size="sm" className="h-7 text-xs">
								Analytics
							</Button>
						</Link>
					</div>
				</CardFooter>
			</Card>


			{/* Delete Confirm Dialog */}
			<DeleteConfirmDialog
				open={isDeleteDialogOpen}
				onOpenChange={setIsDeleteDialogOpen}
				title="Delete QR Code"
				description="Are you sure you want to delete this QR code? This action cannot be undone. All analytics data associated with this QR code will also be permanently deleted."
				onConfirm={handleDelete}
				isLoading={isDeleting}
			/>
		</>
	);
}
