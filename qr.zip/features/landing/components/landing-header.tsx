import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import logo from "@/public/logo.png"

export function LandingHeader() {
    return (
        <header className="fixed top-0 left-0 right-0 z-50 border-b bg-background/80 backdrop-blur-md">
            <div className="container mx-auto px-4 h-16 flex items-center justify-between">
                <Link href="/" className="flex items-center gap-2">
                    <Image
                        src={logo}
                        alt="QR Generator"
                        width={32}
                        height={32}
                        className="rounded-md"
                    />
                    <span className="font-bold text-lg">QR Generator</span>
                </Link>

                <nav className="hidden md:flex items-center gap-6">
                    <Link
                        href="#features"
                        className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                        Features
                    </Link>
                    <Link
                        href="#how-it-works"
                        className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                        How It Works
                    </Link>
                </nav>

                <div className="flex items-center gap-3">
                    <Button variant="ghost" size="sm" asChild>
                        <Link href="/auth/signin">Sign In</Link>
                    </Button>
                    <Button size="sm" asChild>
                        <Link href="/auth/signup">Get Started</Link>
                    </Button>
                </div>
            </div>
        </header>
    );
}
