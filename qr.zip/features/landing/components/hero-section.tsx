import Link from "next/link";
import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles } from "lucide-react";

export function HeroSection() {
    return (
        <section className="relative pt-32 pb-20 md:pt-40 md:pb-32 overflow-hidden">
            {/* Background gradient */}
            <div className="absolute inset-0 -z-10">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[600px] bg-gradient-to-br from-primary/20 via-purple-500/10 to-transparent rounded-full blur-3xl" />
            </div>

            <div className="container mx-auto px-4">
                <div className="max-w-4xl mx-auto text-center">
                    {/* Badge */}
                    <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-8">
                        <Sparkles className="w-4 h-4" />
                        <span>Create stunning QR codes in seconds</span>
                    </div>

                    {/* Headline */}
                    <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-6">
                        Beautiful QR Codes
                        <br />
                        <span className="bg-gradient-to-r from-primary via-purple-500 to-pink-500 bg-clip-text text-transparent">
                            That Get Scanned
                        </span>
                    </h1>

                    {/* Subheadline */}
                    <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10">
                        Design custom QR codes with your brand colors, unique patterns, and logos.
                        Track scans with built-in analytics. Free to start.
                    </p>

                    {/* CTA Buttons */}
                    <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                        <Button size="lg" className="text-base px-8 h-12" asChild>
                            <Link href="/auth/signup">
                                Create Your First QR
                                <ArrowRight className="ml-2 w-4 h-4" />
                            </Link>
                        </Button>
                        <Button variant="outline" size="lg" className="text-base px-8 h-12" asChild>
                            <Link href="/auth/signin">
                                Sign In
                            </Link>
                        </Button>
                    </div>

                    {/* Trust indicators */}
                    <p className="mt-8 text-lg text-muted-foreground">
                        No credit card required
                    </p>
                </div>

                {/* Hero Visual */}
                <div className="mt-16 relative max-w-5xl mx-auto">
                    <div className="relative rounded-2xl border bg-gradient-to-b from-muted/50 to-muted p-4 md:p-8 shadow-2xl">
                        {/* Mock QR code display */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            {[
                                { pattern: "rounded", color: "#7C3AED" },
                                { pattern: "dots", color: "#EC4899" },
                                { pattern: "classy", color: "#0EA5E9" },
                            ].map((style, i) => (
                                <div
                                    key={i}
                                    className="aspect-square rounded-xl bg-white p-6 flex items-center justify-center shadow-sm border"
                                >
                                    <div
                                        className="w-full h-full rounded-lg"
                                        style={{
                                            background: `linear-gradient(135deg, ${style.color}20 0%, ${style.color}40 100%)`,
                                        }}
                                    />
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Floating decorations */}
                    <div className="absolute -top-6 -right-6 w-24 h-24 bg-primary/10 rounded-2xl blur-2xl" />
                    <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-purple-500/10 rounded-full blur-2xl" />
                </div>
            </div>
        </section>
    );
}
