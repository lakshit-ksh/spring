import { Palette, BarChart3, Zap, Shield, Smartphone, Layers } from "lucide-react";

const features = [
    {
        icon: Palette,
        title: "Fully Customizable",
        description: "Choose colors, patterns, corner styles, and add your logo to match your brand.",
    },
    {
        icon: BarChart3,
        title: "Scan Analytics",
        description: "Track how many times your QR codes are scanned with detailed analytics.",
    },
    {
        icon: Zap,
        title: "Instant Generation",
        description: "Create QR codes in real-time with our live preview editor.",
    },
    {
        icon: Shield,
        title: "Always Scannable",
        description: "Our QR codes are optimized for maximum scannability across all devices.",
    },
    {
        icon: Smartphone,
        title: "Mobile Friendly",
        description: "Works perfectly on all smartphones and QR code readers.",
    },
    {
        icon: Layers,
        title: "Multiple Formats",
        description: "Download in PNG, SVG, or PDF for print and digital use.",
    },
];

export function FeaturesSection() {
    return (
        <section id="features" className="py-20 md:py-32 bg-muted/30">
            <div className="container mx-auto px-4">
                <div className="text-center mb-16">
                    <h2 className="text-3xl md:text-4xl font-bold mb-4">
                        Everything You Need
                    </h2>
                    <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                        Create professional QR codes with powerful features designed for businesses and individuals.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
                    {features.map((feature, i) => (
                        <div
                            key={i}
                            className="group p-6 rounded-2xl bg-background border hover:border-primary/50 hover:shadow-lg transition-all duration-300"
                        >
                            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                                <feature.icon className="w-6 h-6 text-primary" />
                            </div>
                            <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                            <p className="text-muted-foreground">{feature.description}</p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}
