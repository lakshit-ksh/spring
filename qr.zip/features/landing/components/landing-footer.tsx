import Link from "next/link";
import Image from "next/image";
import logo from "../../../public/logo.png"

export function LandingFooter() {
    return (
        <footer className="border-t bg-muted/20">
            <div className="container mx-auto px-4 py-12">
                <div className="flex flex-col md:flex-row items-center justify-between gap-6">
                    <div className="flex items-center gap-2">
                        <Image
                            src={logo}
                            alt="QR Generator"
                            width={24}
                            height={24}
                            className="rounded"
                        />
                        <span className="font-semibold">QR Generator</span>
                    </div>

                    <nav className="flex items-center gap-6 text-sm text-muted-foreground">
                        <Link href="#features" className="hover:text-foreground transition-colors">
                            Features
                        </Link>
                        <Link href="/auth/signin" className="hover:text-foreground transition-colors">
                            Sign In
                        </Link>
                        <Link href="/auth/signup" className="hover:text-foreground transition-colors">
                            Get Started
                        </Link>
                    </nav>

                    <p className="text-sm text-muted-foreground">
                        © {new Date().getFullYear()} QR Generator. All rights reserved.
                    </p>
                </div>
            </div>
        </footer>
    );
}
