import { GeoIPService } from "./geoip-service";
import { ScanRepository } from "@/repositories";
import { ScanDailyAnalyticsService } from "./scan-daily-analytics-service";
import { extractClientIP, parseUserAgent } from "@/utils";

export class ScanService {
    static async logScan(qrCodeId: string, headers: Record<string, string | string[] | undefined>) {
        try {
            const ip = extractClientIP(headers);

            if (!ip) {
                console.warn("Could not determine client IP. Scan not logged.");
                return;
            }

            const userAgent = headers["user-agent"] as string ?? "";
            const { browser, os, deviceType } = parseUserAgent(userAgent);

            const geo = await GeoIPService.lookup(ip);

            await ScanDailyAnalyticsService.upsertAnalytics({
                qrCodeId,
                ip,
                browser,
                os,
                deviceType,
                city: geo?.city,
                country: geo?.country
            });

            console.log("Updated daily analytics for QR code:", qrCodeId);

            const scan = await ScanRepository.create({
                qrCodeId,
                ip,
                deviceType,
                os,
                browser,
                city: geo?.city,
                country: geo?.country
            });

            console.log("Logged scan:", scan.id);

        } catch (error) {
            console.error("Failed to log scan:", error);
        }
    }

}   