import { LogoRepository } from "@/repositories/logo-repository";

export class LogoService {
    static async getUserLogos(userId: string) {
        // Fetch up to 100 logos (soft limit for listing)
        const { data, error } = await LogoRepository.list(userId, 100);

        if (error) throw new Error(error.message);

        const logos = data.map(file => {
            // Path is just userId/filename
            const path = `${userId}/${file.name}`;
            const { data: urlData } = LogoRepository.getPublicUrl(path);

            return {
                id: file.id,
                name: file.name,
                url: urlData.publicUrl,
                createdAt: file.created_at,
            };
        });

        return {
            logos,
            count: logos.length,
        };
    }

    static async uploadLogo(userId: string, file: File, fileNameOverride?: string) {
        // 1. Determine Filename (Hash or Timestamp)
        const ext = file.name.split(".").pop();
        const finalName = fileNameOverride || `${Date.now()}.${ext}`;

        // Path is directly under userId
        const path = `${userId}/${finalName}`;

        // 2. Check Deduplication (Does this file already exist?)
        const { data: existingData } = await LogoRepository.list(userId, 100);
        const existingLogo = existingData?.find(l => l.name === finalName);

        if (existingLogo) {
            const { data: urlData } = LogoRepository.getPublicUrl(path);
            return { url: urlData.publicUrl, fileName: finalName, isDuplicate: true };
        }

        // 3. Upload
        const { error } = await LogoRepository.upload(path, file);
        if (error) throw new Error(error.message);

        const { data } = LogoRepository.getPublicUrl(path);
        return { url: data.publicUrl, fileName: finalName };
    }

    static async deleteLogo(userId: string, fileName: string) {
        const path = `${userId}/${fileName}`;
        const { error } = await LogoRepository.delete(path);
        if (error) throw new Error(error.message);
        return true;
    }
}