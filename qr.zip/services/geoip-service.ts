// services/geoip-service.ts
import path from "path";
import { Reader } from "@maxmind/geoip2-node";
import { APP_CONFIG } from "@/config";

// Path to your MMDB
const dbPath = path.resolve(APP_CONFIG.GEOIP_DB_PATH);

let reader: Awaited<ReturnType<typeof Reader.open>> | null = null;
let initializationError: Error | null = null;

// Initialize once at cold start
async function initReader() {
    if (reader) return;

    try {
        reader = await Reader.open(dbPath);
        console.log("✓ GeoIP database initialized successfully");
    } catch (error) {
        initializationError = error as Error;
        console.error("✗ Failed to initialize GeoIP database:", error);
    }
}

export const GeoIPService = {
    async lookup(ip: string) {
        // Best Practice: Validate and handle special IPs
        if (!ip || ip === "0.0.0.0" || isPrivateIP(ip)) {
            console.log(`Using mock location for development IP: ${ip}`);
            return APP_CONFIG.DEV_MOCKED_GEOIP;
        }

        if (!reader) {
            await initReader();
        }

        if (!reader) {
            console.warn("GeoIP lookup skipped - database not available");
            return null;
        }

        try {
            const result = reader.city(ip);
            if (!result) return null;

            return {
                country: result.country?.isoCode,
                countryName: result.country?.names?.en,
                city: result.city?.names?.en
            };
        } catch (error) {
            // Best Practice: Don't log errors for expected failures
            if ((error as Error).message?.includes('not in the database')) {
                console.log(`IP ${ip} not found in GeoIP database (likely private/VPN)`);
            } else {
                console.error("GeoIP lookup error:", error);
            }
            return null;
        }
    },

    isReady(): boolean {
        return reader !== null;
    },

    getInitError(): Error | null {
        return initializationError;
    }
};

// Helper: Check if IP is private/local
function isPrivateIP(ip: string): boolean {
    // Remove IPv6 prefix if present
    const cleanIP = ip.replace(/^::ffff:/, '');

    // Check for localhost
    if (cleanIP === '127.0.0.1' || cleanIP === '::1' || cleanIP === 'localhost') {
        return true;
    }

    // Check for private IP ranges
    const privateRanges = [
        /^10\./,                    // 10.0.0.0/8
        /^172\.(1[6-9]|2\d|3[01])\./, // 172.16.0.0/12
        /^192\.168\./,              // 192.168.0.0/16
        /^fd[0-9a-f]{2}:/i,         // IPv6 ULA
        /^fe80:/i                   // IPv6 Link-local
    ];

    return privateRanges.some(range => range.test(cleanIP));
}