
import { APP_CONFIG } from "@/config";
import { EmailProvider, EmailPayload } from "@/types/email";
import { generateRandomToken } from "@/utils";

export class EmailService {
    private provider: EmailProvider;

    constructor(provider: EmailProvider) {
        this.provider = provider;
    }

    async send(payload: EmailPayload) {
        // optional: suppress emails in development
        // if (process.env.NODE_ENV !== "production") {
        //     console.log( "📧 Email suppressed:", payload.subject, payload.to);
        //     return;
        // }

        await this.provider.send(payload);
    }

    async sendVerificationEmail(to: string, token: string) {


        const verificationLink = `${APP_CONFIG.APP_BASE_URL}/${APP_CONFIG.EMAIL_VERIFICATION_ROUTE}?token=${token}`;

        const payload: EmailPayload = {
            to,
            subject: "Verify your email address",
            html: `<p>Please verify your email by clicking the link below:</p>
                   <a href="${verificationLink}">Verify Email</a>`
        };
        await this.send(payload);
    }

    async sendPasswordResetEmail(to: string, token: string) {

        const resetLink = `${APP_CONFIG.APP_BASE_URL}/${APP_CONFIG.PASSWORD_RESET_ROUTE}?token=${token}`;

        const payload: EmailPayload = {
            to,
            subject: "Reset your password",
            html: `<p>You can reset your password by clicking the link below:</p>
                   <a href="${resetLink}">Reset Password</a>`
        };
        await this.send(payload);
    }

}
