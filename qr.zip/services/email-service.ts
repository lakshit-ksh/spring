
import { EmailProvider, EmailPayload } from "@/types/email";

export class EmailService {
    private provider: EmailProvider;

    constructor(provider: EmailProvider) {
        this.provider = provider;
    }

    async send(payload: EmailPayload) {
        // optional: suppress emails in development
        // if (process.env.NODE_ENV !== "production") {
        //     console.log( "📧 Email suppressed:", payload.subject, payload.to);
        //     return;
        // }

        await this.provider.send(payload);
    }

}
