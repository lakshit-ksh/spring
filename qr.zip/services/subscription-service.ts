import { ActiveSubscriptionExistsError } from "@/error/subscription-error";
import { SubscriptionRepository } from "@/repositories/subscription-repository";
import { SubscriptionCreateDto } from "@/types";

export class SubscriptionService {
    static async create(subscription: SubscriptionCreateDto) {

        if (await this.hasActiveSubscription(subscription.userId)) {
            throw new ActiveSubscriptionExistsError();
        }

        return SubscriptionRepository.create(subscription);
    }

    static async getActiveSubscriptionByUserId(userId: string) {
        return SubscriptionRepository.findActiveByUserId(userId);
    }

    static async getSubscriptionById(id: string) {
        return SubscriptionRepository.findById(id);
    }

    static async getSubscriptionsByUserId(userId: string) {
        return SubscriptionRepository.findAllByUserId(userId);
    }

    static async hasActiveSubscription(userId: string): Promise<boolean> {
        const subscription = await SubscriptionRepository.findActiveByUserId(userId);
        return subscription ? true : false;
    }

}