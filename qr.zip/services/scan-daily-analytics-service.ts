import { APP_CONFIG } from "@/config";
import { ScanDailyAnalyticsRepository } from "@/repositories/scan-daily-analytics-repository";
import { AnalyticsQuery } from "@/schemas";
import { ScanDailyAnalyticsInsertDTO } from "@/types";
import { clampDatesToMaxAllowedRange, normalizeToUTCDate } from "@/utils";

export class ScanDailyAnalyticsService {
    /**
   * Increment daily analytics for a QR code.
   * All dates assumed to be UTC, time stripped (date-only).
   */
    static async upsertAnalytics(dto: ScanDailyAnalyticsInsertDTO): Promise<void> {
        const normalized: ScanDailyAnalyticsInsertDTO = {
            ...dto,
            ip: dto.ip?.trim(),
            // Optional fields trimmed, undefined if empty
            deviceType: dto.deviceType?.trim() || undefined,
            browser: dto.browser?.trim() || undefined,
            os: dto.os?.trim() || undefined,
            country: dto.country?.trim() || undefined,
            city: dto.city?.trim() || undefined,
        };

        // Call repository to upsert / increment counts
        await ScanDailyAnalyticsRepository.upsertAnalytics(normalized);
    }

    static async getDailyAnalytics(qrCodeId: string, query: AnalyticsQuery) {

        query = clampDatesToMaxAllowedRange(query.from, query.to, APP_CONFIG.MAX_ANALYTICS_DATE_RANGE_MS);

        return ScanDailyAnalyticsRepository.getDailyAnalyticsForRange(qrCodeId, query);

    }

    static async getJsonbAnalytics(qrCodeId: string, field: string, query: AnalyticsQuery) {
        query = clampDatesToMaxAllowedRange(query.from, query.to, APP_CONFIG.MAX_ANALYTICS_DATE_RANGE_MS);

        return ScanDailyAnalyticsRepository.getJsonbAnalytics(qrCodeId, field, query);
    }
    
    static async getAggregatedAnalytics(qrCodeId: string, query: AnalyticsQuery) {
        query = clampDatesToMaxAllowedRange(query.from, query.to, APP_CONFIG.MAX_ANALYTICS_DATE_RANGE_MS);

        return ScanDailyAnalyticsRepository.getAggregatedAnalytics(qrCodeId, query);
    }
}
