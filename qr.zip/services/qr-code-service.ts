import { APP_CONFIG } from "@/config/app-config";
import { ForbiddenError, UnauthorizedError } from "@/error";
import { QrCodeNotFoundError } from "@/error/qr-code-error";
import { QrCodeMapper } from "@/mapper/qr-code-mapper";
import { QrCodeRepository } from "@/repositories";
import { QrCodeInputDto, QrCodeUpdateDto } from "@/schemas";
import { CursorPaginatedResult, QrCodeResponseDto } from "@/types";

export class QrCodeService {

    static async create(qrcode: QrCodeInputDto, userId: string): Promise<QrCodeResponseDto> {
        const qrCodeRecord = await QrCodeRepository.create({
            title: qrcode.title,
            targetUrl: qrcode.targetUrl,
            ownerId: userId,
            designConfig: qrcode.designConfig,
        });

        return QrCodeMapper.toQrCodeResponseDto(qrCodeRecord);
    }

    static async update(qrCodeId: string, userId: string, updateDto: QrCodeUpdateDto): Promise<QrCodeResponseDto> {
        const qrCodeRecord = await QrCodeRepository.findById(qrCodeId);

        if (!qrCodeRecord) {
            throw new QrCodeNotFoundError(`QR Code with id '${qrCodeId}' not found`);
        }

        if (qrCodeRecord.ownerId !== userId) {
            throw new ForbiddenError("You are not authorized to update this QR Code");
        }

        const updatedQrCodeRecord = await QrCodeRepository.update(qrCodeId, updateDto);

        return QrCodeMapper.toQrCodeResponseDto(updatedQrCodeRecord);
    }

    static async hardDelete(qrCodeId: string, userId: string): Promise<QrCodeResponseDto> {
        const qrCodeRecord = await QrCodeRepository.findById(qrCodeId);

        if (!qrCodeRecord) {
            throw new QrCodeNotFoundError(`QR Code with id '${qrCodeId}' not found`);
        }

        if (qrCodeRecord.ownerId !== userId) {
            throw new ForbiddenError("You are not authorized to delete this QR Code");
        }

        const deletedQrCodeRecord = await QrCodeRepository.hardDelete(qrCodeId);

        return QrCodeMapper.toQrCodeResponseDto(deletedQrCodeRecord);
    }

    static async getById(qrCodeId: string, userId: string): Promise<QrCodeResponseDto> {
        const qrCode = await QrCodeRepository.findById(qrCodeId);

        if (!qrCode) {
            throw new QrCodeNotFoundError(`QR Code with id '${qrCodeId}' not found`);
        }

        if (qrCode.ownerId !== userId) {
            throw new ForbiddenError("You are not authorized to access this QR Code");
        }

        return QrCodeMapper.toQrCodeResponseDto(qrCode);
    }

    static async getAllByOwnerId(ownerId: string, cursor: string | null): Promise<CursorPaginatedResult<QrCodeResponseDto>> {
        const { items, nextCursor } = await QrCodeRepository.findAllByOwnerId(ownerId, cursor, APP_CONFIG.PAGINATION_LIMIT);

        const qrCodeResponseDtos = items.map(qrCode => QrCodeMapper.toQrCodeResponseDto(qrCode));

        return {
            items: qrCodeResponseDtos,
            nextCursor
        };

    }

    static async searchAllByOwnerId(ownerId: string, query: string, cursor: string | null): Promise<CursorPaginatedResult<QrCodeResponseDto>> {
        const { items, nextCursor } = await QrCodeRepository.searchAllByOwnerId(ownerId, query, cursor, APP_CONFIG.PAGINATION_LIMIT);

        const qrCodeResponseDtos = items.map(qrCode => QrCodeMapper.toQrCodeResponseDto(qrCode));

        return {
            items: qrCodeResponseDtos,
            nextCursor
        };

    }

    static async getUsageInfo(userId: string): Promise<{ count: number, limit: number }> {
        const qrCount = await QrCodeRepository.countByOwnerId(userId);
        return {
            count: qrCount,
            limit: APP_CONFIG.QR_CODE_CREATION_LIMIT
        };
    }

    static async creationLimitReached(userId: string): Promise<boolean> {
        const usageInfo = await this.getUsageInfo(userId);
        return usageInfo.count >= usageInfo.limit;
    }
}