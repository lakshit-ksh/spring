import { APP_CONFIG } from "@/config/app-config";
import { SUPABASE_CONFIG } from "@/config/supabase-config";
import { QrCodeUploadError, QrCodeNotFoundError, QrCodeGenerationError, QrCodeSignedUrlError } from "@/error/qr-code-error";
import { QrCodeMapper } from "@/mapper/qr-code-mapper";
import { QrCodeRepository, QrCodeStorageRepository } from "@/repositories";
import { QrCodeInputDto } from "@/schemas";
import { generateQrCode } from "@/utils/qrcode-utils";
import { User } from "next-auth";

export class QrCodeService {
    /**
     * @param qrcode 
     * @param user 
     * @returns The signed URL of the uploaded QR code image
     */
    static async generateAndUpload(qrcode: QrCodeInputDto, user: User): Promise<string> {
        const qrCodeRecord = await QrCodeRepository.create({
            title: qrcode.title,
            targetUrl: qrcode.targetUrl,
            ownerId: user.id,
            imagePath: "",
        });

        const qrCodeImagePath = `${SUPABASE_CONFIG.SUPABASE_STORAGE_BUCKET_NAME}/${user.id}/${qrCodeRecord.id}.png`;

        let buffer: Buffer;

        try {
            buffer = await generateQrCode(`${APP_CONFIG.REDIRECT_BASE_URL}/${APP_CONFIG.REDIRECT_ROUTE}/${qrCodeRecord.id}`);
        } catch (error) {
            console.error("Error generating QR code:", error);
            await QrCodeRepository.hardDelete(qrCodeRecord.id);
            throw new QrCodeGenerationError("Failed to generate QR code image");
        }

        try {
            await QrCodeStorageRepository.uploadQrCode(buffer, qrCodeImagePath);

        } catch (error) {
            console.error("Error uploading QR code to storage:", error);
            await QrCodeRepository.hardDelete(qrCodeRecord.id);
            throw new QrCodeUploadError("Failed to upload QR code image to storage");
        }

        let signedUrl: string;

        try {
            signedUrl = await QrCodeStorageRepository.getSignedUrl(qrCodeImagePath, SUPABASE_CONFIG.SIGNED_URL_EXPIRY_SECONDS);

        } catch (error) {
            console.error("Error generating signed URL for QR code:", error);
            throw new QrCodeSignedUrlError("Failed to generate signed URL for QR code image");
        }

        const updatedQrCodeRecord = await QrCodeRepository.update(qrCodeRecord.id, {
            imagePath: qrCodeImagePath,
        });

        return signedUrl;
    }

    static async getById(qrCodeId: string) {
        const qrCode = await QrCodeRepository.findById(qrCodeId);

        if (!qrCode) {
            throw new QrCodeNotFoundError(`QR Code with id '${qrCodeId}' not found`);
        }

        return qrCode;
    }

    static async getAllByOwnerId(ownerId: string, cursor: string | null) {
        const { items, nextCursor } = await QrCodeRepository.findAllByOwnerId(ownerId, cursor, APP_CONFIG.PAGINATION_LIMIT);

        const qrCodeResponseDtos = await Promise.all(
            items.map(async (qrCode) => {
                let signedUrl: string | null = null;
                try {
                    signedUrl = await QrCodeStorageRepository.getSignedUrl(
                        qrCode.imagePath,
                        SUPABASE_CONFIG.SIGNED_URL_EXPIRY_SECONDS
                    );
                } catch (error) {
                    console.error(`Error generating signed URL for QR code with id '${qrCode.id}':`, error);
                    signedUrl = null;
                }

                return QrCodeMapper.toQrCodeResponseDto({ ...qrCode, signedUrl });
            })
        )

        return {
            items: qrCodeResponseDtos,
            nextCursor
        };

    }

}