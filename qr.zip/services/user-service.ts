import { UserAlreadyExistsError, UserNotFoundError, BadRequestError } from "@/error";
import { UserRepository } from "@/repositories";
import { User } from "@/lib/prisma";
import { UserCreateDto, UserCreateSchema, UserUpdateDto } from "@/schemas";
import { hashPassword } from "@/utils/password-utils";

export class UserService {

    static async create(user: UserCreateDto): Promise<User> {
        
        const existingUser = await UserRepository.findByEmail(user.email);

        if (existingUser) {
            throw new UserAlreadyExistsError(`User with email '${user.email}' already exists`);
        }

        const hashedPassword = await hashPassword(user.password);
        user.password = hashedPassword;

        return await UserRepository.create(user);
    }

    static async update(id: string, user: UserUpdateDto): Promise<User | undefined> {
        const existingUser = await UserRepository.findById(id);
        if (!existingUser) {
            throw new UserNotFoundError(`User with id '${id}' not found`);
        }
        return await UserRepository.update(id, user);
    }

    static async getById(id: string): Promise<User> {
        const user: User | null = await UserRepository.findById(id);

        if (!user) {
            throw new UserNotFoundError(`User with id '${id}' not found`);
        }

        return user;
    }

    static async getByEmail(email: string | null): Promise<User> {

        if (!email) {
            throw new BadRequestError('Email query parameter is required');
        }

        const user: User | null = await UserRepository.findByEmail(email);

        if (!user) {
            throw new UserNotFoundError(`User with email '${email}' not found`);
        }
        return user;
    }
}