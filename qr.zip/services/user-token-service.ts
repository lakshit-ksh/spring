import { APP_CONFIG } from "@/config";
import { TokenType } from "@/lib/prisma";
import { UserTokenRepository } from "@/repositories";
import { generateRandomToken, hashToken } from "@/utils";

export class UserTokenService {

    static async createToken(userId: string, type: TokenType, expiresInMs: number): Promise<string> {

        const token = generateRandomToken(32);

        const tokenHash = hashToken(token);

        await UserTokenRepository.create({
            userId,
            tokenHash,
            type,
            expiresAt: new Date(Date.now() + expiresInMs)
        });

        return token;
    }

    static async createEmailVerificationToken(userId: string) {

        await UserTokenRepository.deleteByUserIdAndType(userId, TokenType.EMAIL_VERIFICATION);

        return this.createToken(
            userId,
            TokenType.EMAIL_VERIFICATION,
            APP_CONFIG.AUTH.TOKENS.EMAIL_VERIFICATION_EXPIRY_MS
        );

    }

    static async createPasswordResetToken(userId: string) {

        await UserTokenRepository.deleteByUserIdAndType(userId, TokenType.PASSWORD_RESET);

        return this.createToken(
            userId,
            TokenType.PASSWORD_RESET,
            APP_CONFIG.AUTH.TOKENS.PASSWORD_RESET_EXPIRY_MS
        );

    }
}