import { InternalServerError } from "./common-errors";

export class EmailProviderNotSupportedError extends InternalServerError {
    constructor(message: string = "The specified email provider is not supported.") {
        super(message);
        this.name = "ProviderNotSupportedError";
    }
}