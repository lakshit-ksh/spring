import { ConflictError, NotFoundError } from "@/error";

export class UserNotFoundError extends NotFoundError {
    constructor(message?: string) {
        super(message || "User not found");
        this.name = "UserNotFoundError";
    }
}

export class UserAlreadyExistsError extends ConflictError {
    constructor(message?: string) {
        super(message || "User already exists");
        this.name = "UserAlreadyExistsError";
    }
}