import { ConflictError } from "@/error";

export class ActiveSubscriptionExistsError extends ConflictError {

    public readonly userId?: string;

    constructor(userId?: string) {
        super("User already has an active subscription");
        this.userId = userId;
    }
}