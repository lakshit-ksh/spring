import { BadGatewayError, BadRequestError, InternalServerError, NotFoundError } from "./common-errors";

export class StorageProviderNotSupportedError extends InternalServerError {
    constructor(message = "Storage provider not supported") {
        super(message);
    }
}

export class StorageFileNotFoundError extends NotFoundError {
    constructor(message = "Storage file not found") {
        super(message);
    }
}

export class FileTooLargeError extends BadRequestError {
    constructor(message = "File too large") {
        super(message);
    }
}

export class InvalidFileTypeError extends BadRequestError {
    constructor(message = "Invalid file type") {
        super(message);
    }
}