import { AppError } from "@/error";
import { HttpStatus } from "@/constants/http";

export class BadRequestError extends AppError {
    constructor(message = "Bad Request") {
        super(message, HttpStatus.BAD_REQUEST, true);
    }
}

export class NotFoundError extends AppError {
    constructor(message = "Resource Not Found") {
        super(message, HttpStatus.NOT_FOUND, true);
    }
}

export class ConflictError extends AppError {
    constructor(message = "Conflict") {
        super(message, HttpStatus.CONFLICT, true);
    }
}

export class UnauthorizedError extends AppError {
    constructor(message = "Unauthorized") {
        super(message, HttpStatus.UNAUTHORIZED, true);
    }
}
export class ForbiddenError extends AppError {
    constructor(message = "Forbidden") {
        super(message, HttpStatus.FORBIDDEN, true);
    }
}

export class BadGatewayError extends AppError {
    constructor(message = "Bad Gateway") {
        super(message, HttpStatus.BAD_GATEWAY, false);
    }
}

export class InternalServerError extends AppError {
    constructor(message = "Internal Server Error") {
        super(message, HttpStatus.INTERNAL_SERVER_ERROR, false);
    }
}