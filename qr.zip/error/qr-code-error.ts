import { BadGatewayError, InternalServerError, NotFoundError } from "@/error";

export class QrCodeNotFoundError extends NotFoundError {
    constructor(message: string = "QR Code not found") {
        super(message);
        this.name = "QrCodeNotFoundError";
    }
}

export class QrCodeGenerationError extends InternalServerError {
    constructor(message: string = "Failed to generate QR Code") {
        super(message);
        this.name = "QrCodeGenerationError";
    }
}

export class QrCodeUploadError extends BadGatewayError {
    constructor(message: string = "Failed to upload QR Code image") {
        super(message);
        this.name = "QrCodeImageUploadError";
    }
}

export class QrCodeSignedUrlError extends BadGatewayError {
    constructor(message: string = "Failed to generate signed URL for QR Code image") {
        super(message);
        this.name = "QrCodeSignedUrlError";
    }
}