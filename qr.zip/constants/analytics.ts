export const ANALYTICS_FIELDS = {
    DEVICE_TYPE: "deviceType",
    BROWSER: "browser",
    OS: "os",
    COUNTRY: "country",
    CITY: "city",
} as const;

export type AnalyticsField = (typeof ANALYTICS_FIELDS)[keyof typeof ANALYTICS_FIELDS];