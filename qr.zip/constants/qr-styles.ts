export const QR_DOT_STYLES = ["rounded", "dots", "classy", "classy-rounded", "square", "extra-rounded"] as const;
export const QR_CORNER_SQUARE_STYLES = ["dot", "square", "extra-rounded"] as const;
export const QR_CORNER_DOT_STYLES = ["dot", "square"] as const;

export const QR_MODES = ["Numeric", "Alphanumeric", "Byte", "Kanji"] as const;
export const QR_ERROR_CORRECTION_LEVELS = ["L", "M", "Q", "H"] as const;

export type QrDotStyle = typeof QR_DOT_STYLES[number];
export type QrCornerSquareStyle = typeof QR_CORNER_SQUARE_STYLES[number];
export type QrCornerDotStyle = typeof QR_CORNER_DOT_STYLES[number];
export type QrMode = typeof QR_MODES[number];
export type QrErrorCorrectionLevel = typeof QR_ERROR_CORRECTION_LEVELS[number];
