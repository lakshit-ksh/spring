export const APP_CONFIG = {

    APP_BASE_URL: "http://192.168.0.102:3000",

    REDIRECT_BASE_URL: "http://qr-redirect-worker.lakshitbagul777.workers.dev",

    REDIRECT_ROUTE: "r", //  e.g., http://app.com/r/:id

    PAGINATION_LIMIT: 5,

    GEOIP_DB_PATH: "./data/GeoLite2-City.mmdb",

    DEV_MOCKED_GEOIP: process.env.NODE_ENV === 'development' ? {
        country: 'IN',
        countryName: 'India',
        city: 'Pune'
    } : null,

    MAX_ANALYTICS_DATE_RANGE_MS: 365 * 24 * 60 * 60 * 1000, // 1 year in milliseconds

    JSONB_FIELDS: {
        DEVICE_COUNTS: 'deviceCounts',
        OS_COUNTS: 'osCounts',
        BROWSER_COUNTS: 'browserCounts',
        COUNTRY_COUNTS: 'countryCounts',
        CITY_COUNTS: 'cityCounts'
    },

    AUTH: {
        TOKENS: {
            EMAIL_VERIFICATION_EXPIRY_MS: 30 * 60 * 1000, // 30 minutes
            PASSWORD_RESET_EXPIRY_MS: 15 * 60 * 1000, // 15 minutes
        },
    },
}