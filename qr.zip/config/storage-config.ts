export const STORAGE_CONFIG = {
    DEFAULT_PROVIDER: process.env.DEFAULT_STORAGE_PROVIDER ?? 'supabase',
    QRCODE_LOGOS_BUCKET_NAME: process.env.QRCODE_LOGOS_BUCKET_NAME ?? 'qr-code-logos',
    MAX_FILE_SIZE: 256 * 1024, // 256KB
}