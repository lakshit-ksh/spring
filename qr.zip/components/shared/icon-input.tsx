import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { LucideIcon } from "lucide-react";
import clsx from "clsx";

interface IconInputProps extends React.ComponentProps<typeof Input> {
    label: string;
    icon: LucideIcon;
    error?: string;
    id: string; // Enforce ID for Label association
}

export function IconInput({
    label,
    icon: Icon,
    error,
    className,
    id,
    ...props
}: IconInputProps) {
    return (
        <div className="space-y-2">
            <Label htmlFor={id}>{label}</Label>
            <div className="relative">
                <Icon className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                    id={id}
                    className={clsx("pl-10", className, {
                        "border-red-500 focus-visible:ring-red-500": error
                    })}
                    {...props}
                />
            </div>
            {error && (
                <p className="text-sm text-destructive font-medium">{error}</p>
            )}
        </div>
    );
}
