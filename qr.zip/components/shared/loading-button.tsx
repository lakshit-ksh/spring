import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";

interface LoadingButtonProps extends React.ComponentProps<typeof Button> {
    isLoading?: boolean;
    loadingText?: string;
}

export function LoadingButton({
    isLoading,
    loadingText,
    children,
    disabled,
    ...props
}: LoadingButtonProps) {
    return (
        <Button disabled={isLoading || disabled} {...props}>
            {isLoading ? (
                <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {loadingText || "Please wait..."}
                </>
            ) : (
                children
            )}
        </Button>
    );
}
