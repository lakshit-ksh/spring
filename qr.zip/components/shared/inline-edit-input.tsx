"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Pencil, Check, X, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface InlineEditInputProps {
    value: string;
    onSave: (newValue: string) => Promise<void>;
    onCancel?: () => void;
    placeholder?: string;
    className?: string;
    inputClassName?: string;
    displayClassName?: string;
    validation?: (value: string) => string | null;
    renderDisplay?: (value: string) => React.ReactNode;
}

export function InlineEditInput({
    value,
    onSave,
    onCancel,
    placeholder = "Enter value...",
    className,
    inputClassName,
    displayClassName,
    validation,
    renderDisplay,
}: InlineEditInputProps) {
    const [isEditing, setIsEditing] = useState(false);
    const [editValue, setEditValue] = useState(value);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const inputRef = useRef<HTMLInputElement>(null);

    // Sync with external value changes
    useEffect(() => {
        if (!isEditing) {
            setEditValue(value);
        }
    }, [value, isEditing]);

    // Focus input when entering edit mode
    useEffect(() => {
        if (isEditing && inputRef.current) {
            inputRef.current.focus();
            inputRef.current.select();
        }
    }, [isEditing]);

    const handleStartEdit = useCallback(() => {
        setIsEditing(true);
        setEditValue(value);
        setError(null);
    }, [value]);

    const handleCancel = useCallback(() => {
        setIsEditing(false);
        setEditValue(value);
        setError(null);
        onCancel?.();
    }, [value, onCancel]);

    const handleSave = useCallback(async () => {
        // Skip if unchanged
        if (editValue.trim() === value.trim()) {
            setIsEditing(false);
            return;
        }

        // Validate
        if (validation) {
            const validationError = validation(editValue);
            if (validationError) {
                setError(validationError);
                return;
            }
        }

        setIsLoading(true);
        setError(null);

        try {
            await onSave(editValue.trim());
            setIsEditing(false);
        } catch (err) {
            setError(err instanceof Error ? err.message : "Failed to save");
        } finally {
            setIsLoading(false);
        }
    }, [editValue, value, validation, onSave]);

    const handleKeyDown = useCallback(
        (e: React.KeyboardEvent) => {
            if (e.key === "Escape") {
                handleCancel();
            } else if (e.key === "Enter") {
                handleSave();
            }
        },
        [handleCancel, handleSave]
    );

    if (isEditing) {
        return (
            <div className={cn("space-y-1", className)}>
                <div className="flex items-center gap-1">
                    <Input
                        ref={inputRef}
                        value={editValue}
                        onChange={(e) => {
                            setEditValue(e.target.value);
                            setError(null);
                        }}
                        onKeyDown={handleKeyDown}
                        placeholder={placeholder}
                        disabled={isLoading}
                        className={cn(
                            "h-7 text-xs",
                            error && "border-destructive focus-visible:ring-destructive",
                            inputClassName
                        )}
                    />
                    <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 shrink-0"
                        onClick={handleSave}
                        disabled={isLoading}
                        aria-label="Save"
                    >
                        {isLoading ? (
                            <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        ) : (
                            <Check className="h-3.5 w-3.5 text-green-600" />
                        )}
                    </Button>
                    <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 shrink-0"
                        onClick={handleCancel}
                        disabled={isLoading}
                        aria-label="Cancel"
                    >
                        <X className="h-3.5 w-3.5 text-muted-foreground" />
                    </Button>
                </div>
                {error && (
                    <p className="text-xs text-destructive">{error}</p>
                )}
            </div>
        );
    }

    return (
        <div
            className={cn(
                "group flex items-center gap-1.5 cursor-pointer",
                className
            )}
            onClick={handleStartEdit}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                    handleStartEdit();
                }
            }}
        >
            {renderDisplay ? (
                renderDisplay(value)
            ) : (
                <span className={cn("truncate", displayClassName)}>
                    {value || placeholder}
                </span>
            )}
            <Pencil className="h-3 w-3 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
        </div>
    );
}
